const init = require('colorajs');

init()